import crypto from 'node:crypto';

const secretKey=(process.env.PAYMONGO_SECRET_KEY||'').trim();
const webhookSecret=(process.env.PAYMONGO_WEBHOOK_SECRET||'').trim();
const successUrl=(process.env.PAYMONGO_SUCCESS_URL||'').trim();

function validHttpsUrl(value){
  try{
    const url=new URL(value);
    const host=url.hostname.toLowerCase();
    return url.protocol==='https:'&&host.includes('.')&&
      !/(^localhost$|\.localhost$|\.local$|\.test$|\.invalid$|\.example$|example\.com$|your[-_]|placeholder)/i.test(host)&&
      !/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host);
  }catch{return false;}
}

function paymentConfigError(){
  const missing=[];
  if(!/^sk_test_[A-Za-z0-9]+$/.test(secretKey))missing.push('PAYMONGO_SECRET_KEY (test-mode sk_test_ key)');
  if(!validHttpsUrl(successUrl))missing.push('PAYMONGO_SUCCESS_URL (real public HTTPS URL)');
  return Object.assign(
    Error(`PayMongo is not configured. Missing or invalid server .env setting(s): ${missing.join(', ')}. Restart the backend after updating .env.`),
    {status:503}
  );
}

function validateTestSecret(){
  if(!/^sk_test_[A-Za-z0-9]+$/.test(secretKey))
    throw paymentConfigError();
}

async function paymongoRequest(path,payload){
  const response=await fetch(`https://api.paymongo.com${path}`,{
    method:'POST',
    headers:{
      Authorization:`Basic ${Buffer.from(`${secretKey}:`).toString('base64')}`,
      Accept:'application/json',
      'Content-Type':'application/json'
    },
    body:JSON.stringify({data:{attributes:payload}})
  });
  let result;
  try{result=await response.json();}
  catch{throw Object.assign(Error('PayMongo returned an invalid response.'),{status:502});}
  if(!response.ok){
    const details=Array.isArray(result?.errors)
      ?result.errors.map(error=>[error.code,error.detail||error.title].filter(Boolean).join(': ')).filter(Boolean).join('; ')
      :'';
    throw Object.assign(Error(
      details
        ?`PayMongo could not start GCash payment: ${details}`
        :'PayMongo could not start GCash payment. Check the server payment configuration and test-mode account.'
    ),{status:502});
  }
  return result?.data;
}

export async function createPayMongoPaymentIntent({orderId,total,customer}){
  validateTestSecret();
  if(!validHttpsUrl(successUrl))throw paymentConfigError();
  const billingEmail=typeof customer.email==='string'?customer.email.trim():'';
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(billingEmail))
    throw Object.assign(Error('A verified customer email is required for GCash payment.'),{status:400});
  const amount=Math.round(total*100);
  if(!Number.isSafeInteger(amount)||amount<100){
    throw Object.assign(Error('The order total is invalid for PayMongo.'),{status:400});
  }

  const intent=await paymongoRequest('/v1/payment_intents',{
    amount,
    currency:'PHP',
    payment_method_allowed:['gcash'],
    capture_type:'automatic',
    description:`FYI-KANTO delivery order ${orderId}`,
    metadata:{order_id:orderId}
  });
  const intentId=intent?.id;
  if(typeof intentId!=='string'||!/^pi_[A-Za-z0-9]+$/.test(intentId)){
    throw Object.assign(Error('PayMongo returned an invalid payment intent.'),{status:502});
  }

  const billing={name:customer.name,phone:customer.phone,email:billingEmail};
  const paymentMethod=await paymongoRequest('/v1/payment_methods',{
    type:'gcash',
    billing
  });
  const paymentMethodId=paymentMethod?.id;
  if(typeof paymentMethodId!=='string'||!/^pm_[A-Za-z0-9]+$/.test(paymentMethodId)){
    throw Object.assign(Error('PayMongo returned an invalid GCash payment method.'),{status:502});
  }

  const returnUrl=new URL(successUrl);
  returnUrl.searchParams.set('order_id',orderId);
  returnUrl.searchParams.set('payment_intent_id',intentId);
  const attached=await paymongoRequest(
    `/v1/payment_intents/${encodeURIComponent(intentId)}/attach`,
    {payment_method:paymentMethodId,return_url:returnUrl.toString()}
  );
  const paymentUrl=attached?.attributes?.next_action?.redirect?.url;
  let parsedUrl;
  try{parsedUrl=new URL(paymentUrl);}catch{throw Object.assign(Error('PayMongo did not return a valid GCash redirect URL.'),{status:502});}
  if(parsedUrl.protocol!=='https:'){
    throw Object.assign(Error('PayMongo returned an untrusted GCash redirect URL.'),{status:502});
  }
  return {id:intentId,paymentUrl};
}

export async function getPayMongoPaymentIntent(intentId){
  validateTestSecret();
  if(typeof intentId!=='string'||!/^pi_[A-Za-z0-9]+$/.test(intentId))
    throw Object.assign(Error('Invalid PayMongo payment intent reference.'),{status:400});
  let response;
  try{
    response=await fetch(`https://api.paymongo.com/v1/payment_intents/${encodeURIComponent(intentId)}`,{
      headers:{
        Authorization:`Basic ${Buffer.from(`${secretKey}:`).toString('base64')}`,
        Accept:'application/json'
      },
      signal:AbortSignal.timeout(12000)
    });
  }catch{
    throw Object.assign(Error('Unable to verify payment with PayMongo. Please try again.'),{status:502});
  }
  let result;
  try{result=await response.json();}
  catch{throw Object.assign(Error('PayMongo returned an invalid payment status response.'),{status:502});}
  if(!response.ok){
    const details=Array.isArray(result?.errors)
      ?result.errors.map(error=>[error.code,error.detail||error.title].filter(Boolean).join(': ')).filter(Boolean).join('; ')
      :'';
    throw Object.assign(Error(details?`PayMongo payment check failed: ${details}`:'PayMongo payment check failed.'),{status:502});
  }
  if(result?.data?.id!==intentId)
    throw Object.assign(Error('PayMongo returned a different payment intent.'),{status:502});
  return result.data;
}

export function verifyPayMongoWebhook(signatureHeader,rawBody){
  if(!webhookSecret||!/^sk_test_[A-Za-z0-9]+$/.test(secretKey)||typeof signatureHeader!=='string')return false;
  const fields=Object.fromEntries(signatureHeader.split(',').map(part=>{
    const [key,...value]=part.trim().split('=');
    return [key,value.join('=')];
  }));
  const timestamp=Number(fields.t);
  if(!Number.isFinite(timestamp)||Math.abs(Date.now()/1000-timestamp)>300)return false;
  const mode='te';
  const received=fields[mode];
  if(!received||!/^[a-f0-9]{64}$/i.test(received))return false;
  const expected=crypto.createHmac('sha256',webhookSecret).update(`${fields.t}.${rawBody}`).digest();
  const actual=Buffer.from(received,'hex');
  return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected);
}
