// Offline checks only. Live connectivity requires your own Supabase account and credentials.
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';

const src=['server.mjs','db.mjs','paymongo.mjs','setup.mjs','scripts/migrate-json.mjs','public/staff.js','public/customer.js','Customer_Expo/config/backend.js'];
for(const f of src){const r=spawnSync(process.execPath,['--check',f],{encoding:'utf8'});assert.equal(r.status,0,`Syntax ${f}: ${r.stderr}`);console.log('PASS syntax',f);}
const code=fs.readFileSync('server.mjs','utf8'),schema=fs.readFileSync('supabase/schema.sql','utf8'),db=fs.readFileSync('db.mjs','utf8');
const staff=fs.readFileSync('public/staff.js','utf8'),appContext=fs.readFileSync('Customer_Expo/context/AppContext.jsx','utf8');
const staffHtml=fs.readFileSync('public/staff.html','utf8'),staffCss=fs.readFileSync('public/staff.css','utf8');
const staffMigration=fs.readFileSync('supabase/staff-website-enhancements.sql','utf8');
const auth=fs.readFileSync('Customer_Expo/context/AuthContext.jsx','utf8'),login=fs.readFileSync('Customer_Expo/app/index.jsx','utf8');
const resetScreen=fs.readFileSync('Customer_Expo/app/reset-password.jsx','utf8');
const checkout=fs.readFileSync('Customer_Expo/app/customer-info.jsx','utf8');
const productReviews=fs.readFileSync('Customer_Expo/app/(tabs)/reviews.jsx','utf8');
const customerReviewMigration=fs.readFileSync('supabase/customer-reviews.sql','utf8');
const customerEnhancementMigration=fs.readFileSync('supabase/customer-app-enhancements.sql','utf8');
const feedbackModal=fs.readFileSync('Customer_Expo/components/OrderFeedbackModal.jsx','utf8');
const catalog=JSON.parse(fs.readFileSync('catalog.json','utf8'));
assert.equal(catalog.products.length,46);
assert(schema.includes('enable row level security')&&schema.includes('public=false')&&schema.includes('fyi_staff')&&schema.includes('fyi_orders')&&schema.includes('public.profiles'));
assert(schema.includes('paymentfyi_list')&&schema.includes('security_invoker = true'));
assert(schema.includes('fyi_payment_transactions')&&schema.includes('customerfyi_list'));
assert(customerEnhancementMigration.includes('fyi_customer_favorites')&&
  customerEnhancementMigration.includes('fyi_product_popularity')&&
  customerEnhancementMigration.includes('(select auth.uid())::text'),
  'Customer feature migration must include server-managed favorites, popularity, and user-scoped photos');
assert(code.includes("p==='/api/public/favorites'")&&code.includes("p==='/api/public/order-feedback'")&&
  code.includes("p==='/api/public/product-popularity'"));
assert(db.includes('export async function submitOrderFeedback')&&db.includes('order.paymentStatus!==\'paid\''));
assert(feedbackModal.includes('Rate each item')&&feedbackModal.includes('Customer service'));
assert(fs.existsSync('Customer_Expo/app/category/[id].jsx'));
const migration=fs.readFileSync('supabase/customer-payment-admin.sql','utf8');
assert(migration.includes('fyi_payment_transactions')&&migration.includes('paymentfyi_list')&&migration.includes('customerfyi_list'));
const profileFix=fs.readFileSync('supabase/customer-profile-fix.sql','utf8');
assert(profileFix.indexOf('add column if not exists email text')<profileFix.indexOf('create or replace function public.handle_new_customer()'),
  'Profile email column must exist before installing the auth trigger');
assert(profileFix.includes('new.email')&&profileFix.includes('new.raw_user_meta_data')&&profileFix.includes('create view public.customerfyi_list'));
assert(profileFix.includes('grant select on public.customerfyi_list to service_role'));
assert(migration.indexOf('add column if not exists customer_id')<migration.indexOf('insert into public.fyi_payment_transactions'),'Migration must add customer_id before payment backfill');
assert(migration.includes("orders.customer->>'phone'"),'Migration should link existing orders to matching customer profiles');
assert(schema.includes('email TEXT')&&migration.includes('email text'),'Customer email must be stored for staff recovery and reporting');
assert(db.includes("sb_secret_")&&db.includes('tracking_hash')&&db.includes("'fyi-payment-proofs'"));
for(const x of ['/api/public/orders','/api/public/order-status','/api/public/review','/api/public/route','/webhooks/paymongo','/api/staff/overview','/api/staff/settings','/api/staff/orders/','/api/login'])assert(code.includes(x),`API missing ${x}`);
assert(code.includes('/api/staff/customers')&&code.includes('/api/staff/payment-transactions'));
assert(staffMigration.includes('menu_categories jsonb')&&staffMigration.includes('menu_addons jsonb')&&
  staffMigration.includes('fyi_staff_sales_hourly')&&staffMigration.includes('fyi_staff_product_sales'));
assert(staffMigration.includes("lower(role) in ('admin2','admin_2','admin 2')")&&
  staffMigration.includes('cashier_count > 0'),'Admin 2 conversion must not replace an existing cashier account');
assert(code.includes("p==='/api/staff/category-save'")&&code.includes("p==='/api/staff/addon-save'")&&
  code.includes('async function customerCatalog')&&code.includes('currentCatalog.addOns[p.addOns]'));
assert(staff.includes('＋ Add Category')&&staff.includes('＋ Add Add-ons')&&
  staff.includes('delete-product-confirm')&&staff.includes('productAddonIds'));
assert(staff.includes('function requestConfirmation')&&staff.includes("requestConfirmation('Sign out?'")&&
  staffHtml.includes('id="action-confirm-modal"')&&!staffHtml.includes('action-confirm-close')&&
  !staff.includes('delete-product-close')&&!staff.includes('✕ Close')&&
  !staff.includes('id="close-product-editor"')&&!staff.includes('id="close-category-editor"')&&
  !staff.includes('id="close-addon-editor"')&&staffCss.includes('.danger-action')&&
  staffCss.includes('.modal-layer')&&staffCss.includes('.modal-actions{display:grid;'),
  'Staff delete, close, and sign-out actions must use the centered confirmation modal and red buttons');
assert(staff.includes("requestConfirmation('Save changes?'")&&
  staffCss.includes('#product-editor-form .menu-editor-footer button[type="submit"]{grid-column:2;'),
  'Editing products and add-ons must confirm before saving, with product save centered between footer actions');
assert(staff.includes('<h3>Optional Add-ons</h3>')&&!staff.includes('<select name="addOns">')&&
  staff.includes('productAddonChoices(f.elements.namedItem(\'category\').value,item)')&&
  staff.includes('addon.categoryIds')&&staff.includes('categoryIds'),
  'Product optional add-ons must use saved add-ons connected to category/product applicability');
assert(appContext.includes("backendRequest('/api/public/catalog')")&&code.includes("p === '/api/public/catalog'"),
  'Customer app and staff website must share the backend catalog API');
assert(db.includes("from('customerfyi_list')")&&db.includes("from('paymentfyi_list')"));
assert(auth.includes('@accounts.fyi-kanto.invalid')&&auth.includes('signInWithPassword'));
assert(auth.includes("import {createURL} from 'expo-linking'")&&auth.includes("createURL(path,{scheme:'fyikanto'})"));
assert(!auth.includes('makeRedirectUri'),'Use an Expo Linking API supported by the installed SDK');
assert(db.includes('requestCustomerPasswordReset')&&auth.includes("authRedirect('reset-password')"));
assert(login.includes('signUp({email, password, username, phone, address})')&&login.includes('Field label="Email address"'));
assert(auth.includes('requestPasswordReset')&&login.includes("router.push('/forgot-password')"));
assert(!login.includes('password.length!==20')&&!resetScreen.includes('newPassword.length!==20'));
assert(!login.includes('maxLength={mode===\'signup\'?20:undefined}')&&!resetScreen.includes('maxLength={20}'));
assert(!auth.includes('supabase.auth.signUp('),'Customer signup must use the backend to confirm test accounts');
assert(auth.includes("'/api/public/customer-signup'")&&auth.includes('signInWithPassword'));
assert(/error\?\.code\s*===\s*['"]23505['"]/.test(login),'Signup error handler must tolerate undefined error objects');
assert(resetScreen.includes('updatePassword')&&resetScreen.includes('recoveryMode'));
assert(code.includes('/api/public/customer-recovery')&&code.includes('validatedCustomerRecoveryRedirect'));
assert(code.includes('/api/public/customer-signup')&&db.includes('email_confirm:true'));
assert(code.includes('CUSTOMER_SIGNUP_AUTO_CONFIRM'));
assert(code.includes("'19000', '19006'"),'Expo web dev origins must be allowed to reach the signup API');
assert(db.includes('auth.admin.createUser')&&db.includes('auth.admin.deleteUser'));
assert(db.includes('auth.admin.listUsers')&&db.includes("from('customerfyi_list')"));
assert(db.includes("from('profiles').upsert")&&db.includes('phone:phone.trim()')&&db.includes('address:address.trim()'));
assert(code.includes('customerUser.email_confirmed_at'),'Unverified customers must not place orders');
assert(code.includes('database.customerProfile(customerUser.id)')&&code.includes('customerId:customerUser.id'),
  'Orders must use the authenticated customer profile and link the order to that customer');
assert(checkout.includes('ReadOnlyDetail label="Username"')&&checkout.includes('ReadOnlyDetail label="Phone number"')&&checkout.includes('ReadOnlyDetail label="Complete delivery address"'),
  'Checkout must show account name, phone, and address as read-only details');
assert(checkout.includes('FormField label="Landmark (optional)"')&&checkout.includes('FormField label="Order notes (optional)"'),
  'Checkout must keep landmark and order notes editable');
assert(code.includes("p === '/api/public/review'")&&code.includes('database.addCustomerReview({name,productName,rating,message})'),
  'Review submission must be public and must not require a completed order or order token');
assert(db.includes("from('fyi_reviews').insert")&&db.includes('export async function addCustomerReview'),
  'Open customer reviews must use the existing Supabase reviews table');
assert(schema.includes('public.fyi_reviews')&&schema.includes('alter column order_id drop not null'));
assert(customerReviewMigration.includes('alter table public.fyi_reviews')&&customerReviewMigration.includes('drop constraint')&&customerReviewMigration.includes('add column if not exists product_name'));
assert(productReviews.includes('Anyone can share feedback')&&productReviews.includes('submitCustomerReview'),
  'Mobile review form must allow customers to review without ordering');
assert(productReviews.includes('review.productName'));
assert(staff.includes('Feedback shared by customers in the mobile app.'));
assert(login.includes('Email verification is not required.'));
assert(staff.includes('Total Purchased')&&staff.includes('PayMongo Transactions')&&staff.includes('<th>Email</th>'));
assert(code.includes("event?.type!=='payment.paid'")&&code.includes('payment_intent_id'),'PayMongo Payment Intent webhook must be supported');
assert(code.includes('createPayMongoPaymentIntent'),'Orders must create a PayMongo Payment Intent server-side');
assert(code.includes('getPayMongoPaymentIntent')&&code.includes("attributes.status==='succeeded'"),
  'Pending orders must be verified directly with PayMongo while customers track them');
assert(code.includes("p==='/api/public/payment-return'")&&code.includes('payment_intent_id'),
  'PayMongo return screen must verify the server-side transaction');
assert(code.includes("p==='/payment/success'")&&fs.existsSync('public/payment-success.html'),
  'Configured PayMongo return URL must be served by the backend');
assert(staff.includes('Payment confirmed:')&&staff.includes('New customer order:'),'Owner and cashier should see in-app order/payment notifications');
assert(code.includes('isOpen: isOpen(settings)')&&code.includes("if (!isOpen(s))"),'Store status must be returned and checked before creating orders');
assert(code.includes('/api/public/store-status/live')&&code.includes('broadcastStoreStatus(settings)'),'Store status changes must be pushed from the backend');
assert(staff.includes('data-store-override="open"')&&staff.includes('data-store-override="closed"')&&staff.includes('data-store-override="auto"'),'Staff must be able to open, close, or follow the schedule');
assert(appContext.includes('/api/public/store-status/live')&&appContext.includes('new WebSocket('),'Customer app must receive live store status updates');
assert(staff.includes('new WebSocket('),'Staff website must receive live store status updates');
for(const x of ['verify','reject','accept','start','ready','dispatch','delivered'])assert(code.includes(`${x}:`),`missing order action ${x}`);
assert(fs.readFileSync('.gitignore','utf8').includes('**/.env'),'Local .env files must be ignored');
assert(!fs.existsSync('private/database.json'),'Legacy private database must NOT be included in ZIP');
assert(fs.readFileSync('Customer_Expo/app/index.jsx','utf8').includes('Create account'));
assert(fs.readFileSync('Customer_Expo/app/profile.jsx','utf8').includes('created_at'));
assert(fs.readFileSync('Customer_Expo/context/AuthContext.jsx','utf8').includes('EXPO_PUBLIC_SUPABASE_URL'));
assert(fs.readFileSync('Customer_Expo/context/AuthContext.jsx','utf8').includes('@accounts.fyi-kanto.invalid'));
assert(fs.readFileSync('Customer_Expo/config/backend.js','utf8').includes("'19006'"));
assert(fs.readFileSync('Customer_Expo/app/index.jsx','utf8').includes('Forgot password?'));
assert(fs.readFileSync('paymongo.mjs','utf8').includes('/v1/payment_intents'));
assert(code.includes("p==='/api/staff/dine-in-orders'")&&code.includes("staffRole(req,res,['cashier'])")&&code.includes("type:'dine-in'")&&code.includes("status:'accepted',paymentStatus:'paid'"), 'Dine-in creation must be cashier-only and paid/accepted before Kitchen receipt');
assert(code.includes("b.type!=='delivery'")&&staff.includes("['dinein','🍽','Dine-In POS']")&&staff.includes("section==='dinein'&&user.role==='cashier'"), 'Customer ordering must stay delivery-only and Dine-In POS must only render for Cashier');
assert(staff.includes('function alertOnce(kind,id)')&&staff.includes("alertOnce('kitchen',o.id)")&&staff.includes("alertOnce('cashier',order.id)"), 'Cashier and Kitchen alert IDs must be deduplicated across polling and reloads');
assert(staff.includes('cashier-sound-upload')&&staff.includes('kitchen-sound-upload')&&staff.includes('ringtoneAdminPanel')&&staff.includes('uploadSharedSound')&&staff.includes('previewAlertSound'), 'Admin shared ringtone upload and preview controls must exist');
assert(code.includes('api\\/staff\\/sounds')&&code.includes('3.5*1024*1024')&&code.includes('staff-sounds'), 'Shared ringtone upload API must be Admin-only, file-size limited, and server stored');
assert(staff.includes('data-chart-period')&&staff.includes('periodPicker')&&staff.includes('loadDashboardMetrics(true)'), 'Dashboard must offer period controls and refresh selected period');
assert(db.includes('staffDashboardAnalyticsFallback')&&db.includes('using direct order data fallback'), 'Sales analytics must fallback to source order data if Supabase analytics views fail');
assert(staff.includes("if(paidOrders.length){")&&staff.includes('await loadDashboardMetrics(true)'), 'Dashboard sales analytics must force refresh when payment transitions to paid');
console.log('PASS cashier-only dine-in POS, paid ticket workflow, alert deduplication, and analytics refresh safeguards');
console.log('PASS catalog, RLS, server-only secret configuration, APIs, order workflow, and distribution safeguards');

process.env.PAYMONGO_SECRET_KEY='sk_test_unittestkey';
process.env.PAYMONGO_WEBHOOK_SECRET='webhook-test-secret';
process.env.PAYMONGO_SUCCESS_URL='https://shop.example.org/payment/success';
const paymongo=await import('./paymongo.mjs?tests');
const originalFetch=globalThis.fetch;
const requests=[];
const responses=[
 {data:{id:'pi_test123',attributes:{}}},
 {data:{id:'pm_test123',attributes:{}}},
 {data:{id:'pi_test123',attributes:{next_action:{redirect:{url:'https://pay.paymongo.com/gcash/test'}}}}}
];
globalThis.fetch=async(url,options)=>{
 requests.push({url:String(url),options});
 return {ok:true,json:async()=>responses.shift()};
};
try{
 const payment=await paymongo.createPayMongoPaymentIntent({
  orderId:'FYI-TEST-1',total:50,
  customer:{name:'Test Customer',phone:'09123456789',email:'customer@example.com'}
 });
 assert.deepEqual(payment,{id:'pi_test123',paymentUrl:'https://pay.paymongo.com/gcash/test'});
 assert.equal(requests.length,3);
 assert(requests[0].url.endsWith('/v1/payment_intents'));
 assert(requests[1].url.endsWith('/v1/payment_methods'));
 assert(requests[2].url.endsWith('/v1/payment_intents/pi_test123/attach'));
 const intentBody=JSON.parse(requests[0].options.body).data.attributes;
 assert.equal(intentBody.amount,5000);
 assert.deepEqual(intentBody.payment_method_allowed,['gcash']);
 assert.equal(intentBody.metadata.order_id,'FYI-TEST-1');
 const methodBody=JSON.parse(requests[1].options.body).data.attributes;
 assert.equal(methodBody.type,'gcash');
 const attachBody=JSON.parse(requests[2].options.body).data.attributes;
 assert.equal(attachBody.payment_method,'pm_test123');
 assert.equal(new URL(attachBody.return_url).searchParams.get('order_id'),'FYI-TEST-1');
 assert.equal(new URL(attachBody.return_url).searchParams.get('payment_intent_id'),'pi_test123');
 await assert.rejects(
  paymongo.createPayMongoPaymentIntent({
   orderId:'FYI-TEST-NO-EMAIL',total:50,customer:{name:'Test',phone:'09123456789'}
  }),
  /verified customer email is required/
 );
 const body='{"data":{"type":"payment.paid"}}';
 const timestamp=String(Math.floor(Date.now()/1000));
 const signature=(await import('node:crypto')).default.createHmac('sha256','webhook-test-secret').update(`${timestamp}.${body}`).digest('hex');
 assert.equal(paymongo.verifyPayMongoWebhook(`t=${timestamp},te=${signature}`,body),true);
 assert.equal(paymongo.verifyPayMongoWebhook(`t=${timestamp},te=${'0'.repeat(64)}`,body),false);
 console.log('PASS mocked PayMongo Payment Intent, GCash attach, and signed webhook checks');
 globalThis.fetch=async(url,options)=>{
  assert(String(url).endsWith('/v1/payment_intents/pi_test123'));
  assert.equal(options.method,undefined);
  return {ok:true,json:async()=>({data:{id:'pi_test123',attributes:{status:'succeeded',amount:5000,currency:'PHP',metadata:{order_id:'FYI-TEST-1'}}}})};
 };
 const paidIntent=await paymongo.getPayMongoPaymentIntent('pi_test123');
 assert.equal(paidIntent.attributes.status,'succeeded');
 globalThis.fetch=async()=>({ok:false,json:async()=>({errors:[{code:'payment_method_not_allowed',detail:'GCash is unavailable for this account.'}]})});
 await assert.rejects(
  paymongo.createPayMongoPaymentIntent({
   orderId:'FYI-TEST-ERROR',total:50,customer:{name:'Test',phone:'09123456789',email:'test@example.com'}
  }),
  /payment_method_not_allowed: GCash is unavailable for this account/
 );
 process.env.PAYMONGO_WEBHOOK_SECRET='';
 process.env.PAYMONGO_SUCCESS_URL='https://shop.example.org/payment/success';
 const unconfiguredPayMongo=await import(`./paymongo.mjs?missing-config=${Date.now()}`);
 const noWebhookResponses=[
  {data:{id:'pi_test456',attributes:{}}},
  {data:{id:'pm_test456',attributes:{}}},
  {data:{id:'pi_test456',attributes:{next_action:{redirect:{url:'https://pay.paymongo.com/gcash/test'}}}}}
 ];
 globalThis.fetch=async()=>({ok:true,json:async()=>noWebhookResponses.shift()});
 const withoutWebhook=await unconfiguredPayMongo.createPayMongoPaymentIntent({
  orderId:'FYI-TEST-3',total:50,customer:{name:'Test',phone:'09123456789',email:'test@example.com'}
 });
 assert.equal(withoutWebhook.id,'pi_test456','Payment initiation should not require webhook setup when API status checks are available');
 process.env.PAYMONGO_SUCCESS_URL='';
 const missingReturnUrl=await import(`./paymongo.mjs?missing-return=${Date.now()}`);
 await assert.rejects(
  missingReturnUrl.createPayMongoPaymentIntent({
   orderId:'FYI-TEST-2',total:50,customer:{name:'Test',phone:'09123456789'}
  }),
  /PAYMONGO_SUCCESS_URL/
 );
 process.env.PAYMONGO_SUCCESS_URL='https://your-real-website.com/payment/success';
 const placeholderReturnUrl=await import(`./paymongo.mjs?placeholder-return=${Date.now()}`);
 await assert.rejects(
  placeholderReturnUrl.createPayMongoPaymentIntent({
   orderId:'FYI-TEST-PLACEHOLDER',total:50,
   customer:{name:'Test',phone:'09123456789',email:'test@example.com'}
  }),
  /PAYMONGO_SUCCESS_URL/
 );
 }finally{
 globalThis.fetch=originalFetch;
}
console.log('Offline tests passed. Live Supabase, Wi-Fi, and Expo device behavior NOT tested.');
