// FYI-KANTO safe offline integration checks; no cloud access or secrets needed.
import assert from 'node:assert/strict';
import fs from 'node:fs';
// Requires root npm install to test actual hashing; mock-modelled below when unavailable.
import crypto from 'node:crypto';
const r=f=>fs.readFileSync(f,'utf8');
const catalog=JSON.parse(r('catalog.json'));
const app=r('Customer_Expo/context/AppContext.jsx');
const checkout=r('Customer_Expo/app/order-summary.jsx');
const reviews=r('Customer_Expo/app/(tabs)/reviews.jsx');
const gcash=r('Customer_Expo/components/GCashPayment.jsx');
const network=r('Customer_Expo/config/backend.js');
const schema=r('supabase/schema.sql');
const server=r('server.mjs');
assert.equal(catalog.products.length,46);
// Ensure server staff login compares the exact nested shape returned by staffFromRow.
const dbsrc=r('db.mjs');
assert(dbsrc.includes('staff?.secret?.salt')&&dbsrc.includes('staff?.secret?.hash'), 'PIN/password lookup must read the stored hash fields');

for (const part of ["backendRequest('/api/public/orders'",'trackingToken','/api/public/order-status','/api/public/reviews','/api/public/review']) assert(app.includes(part),`Missing ${part}`);
assert(checkout.includes('await createOrder()')&&checkout.includes('submitting'));
assert(gcash.includes('base64:true')&&gcash.includes('Attach Payment Proof'));
assert(reviews.includes('CONNECTED_MODE'));
assert(network.includes('EXPO_PUBLIC_API_URL')&&!network.includes('SUPABASE_SECRET_KEY='));
assert(server.includes('database.insertOrder')&&server.includes('database.downloadProof')&&server.includes('roadDistance'));
assert(schema.includes('row level security')&&schema.includes('public=false'));
assert(fs.readFileSync('.gitignore','utf8').includes('**/.env'),
  'Local Supabase configuration files must be excluded from distribution');
console.log('PASS: 46 products, API integration, server-side prices, GCash proof, orders, tracking, reviews, and secret separation.');
console.log('NOTE: These are offline checks only; connect your own Supabase account to test live.');
