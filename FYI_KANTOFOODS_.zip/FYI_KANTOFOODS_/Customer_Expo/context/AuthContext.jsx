import 'react-native-url-polyfill/auto';
import React, {createContext, useCallback, useContext, useEffect, useMemo, useRef, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Platform} from 'react-native';
import * as Linking from 'expo-linking';
import {createURL} from 'expo-linking';
import {createClient} from '@supabase/supabase-js';
import {backendRequest} from '../config/backend';

const supabaseUrl = (process.env.EXPO_PUBLIC_SUPABASE_URL || '').trim();
const supabaseAnonKey = (
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY || ''
).trim();
const usernameEmail = username => `${username.trim().toLowerCase()}@accounts.fyi-kanto.invalid`;
const authRedirect = path => createURL(path,{scheme:'fyikanto'});

// Supabase email redirects contain tokens in a URL hash or query string.
function getRecoveryParameters(url) {
  const [beforeHash, hash = ''] = String(url).split('#');
  const query = beforeHash.includes('?') ? beforeHash.slice(beforeHash.indexOf('?') + 1) : '';
  const params = new URLSearchParams(query);
  const fragment = new URLSearchParams(hash);
  fragment.forEach((value, key) => params.set(key, value));
  return params;
}

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        storage: Platform.OS === 'web' ? undefined : AsyncStorage,
        autoRefreshToken: true,
        persistSession: true,
        // We handle recovery links ourselves on both mobile and web.
        detectSessionInUrl: false,
      },
    })
  : null;

const AuthContext = createContext(null);

export function AuthProvider({children}) {
  const [session, setSession] = useState(null);
  const [recoveryMode, setRecoveryMode] = useState(false);
  const [recoveryPending, setRecoveryPending] = useState(false);
  const [recoveryError, setRecoveryError] = useState('');
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState('');
  const lastRecoveryUrl = useRef('');

  useEffect(() => {
    if (!supabase) {
      setAuthReady(true);
      return;
    }
    let active = true;
    const {data: {subscription}} = supabase.auth.onAuthStateChange((event, next) => {
      if (!active) return;
      setSession(next);
      if (event === 'PASSWORD_RECOVERY') setRecoveryMode(true);
      if (event === 'SIGNED_OUT') setRecoveryMode(false);
    });

    async function handleRecoveryUrl(url) {
      if (!url || !String(url).includes('reset-password') || lastRecoveryUrl.current === url) return;
      lastRecoveryUrl.current = url;
      const params = getRecoveryParameters(url);
      const errorText = params.get('error_description') || params.get('error');
      if (errorText) {
        if (active) setRecoveryError(errorText);
        return;
      }
      if (params.get('type') !== 'recovery') return;

      if (active) {
        setRecoveryPending(true);
        setRecoveryError('');
      }
      try {
        const accessToken = params.get('access_token');
        const refreshToken = params.get('refresh_token');
        const tokenHash = params.get('token_hash');
        let verifiedSession = null;
        if (accessToken && refreshToken) {
          const {data, error} = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken,
          });
          if (error) throw error;
          verifiedSession = data.session;
        } else if (tokenHash) {
          const {data, error} = await supabase.auth.verifyOtp({
            token_hash: tokenHash,
            type: 'recovery',
          });
          if (error) throw error;
          verifiedSession = data.session;
        } else {
          throw Error('The reset link is incomplete. Request a new password reset email.');
        }
        if (!verifiedSession) throw Error('The recovery session could not be created.');
        if (active) {
          setSession(verifiedSession);
          setRecoveryMode(true);
          setRecoveryError('');
        }
      } catch (error) {
        if (active) {
          setRecoveryMode(false);
          setRecoveryError(error?.message || 'This reset link is invalid or expired.');
        }
      } finally {
        if (active) setRecoveryPending(false);
      }
    }

    const linkSubscription = Linking.addEventListener('url', ({url}) => {
      void handleRecoveryUrl(url);
    });
    Linking.getInitialURL()
      .then(url => { if (active) return handleRecoveryUrl(url); })
      .catch(() => { if (active) setRecoveryError('Could not read the password reset link.'); });

    supabase.auth.getSession()
      .then(({data, error}) => {
        if (!active) return;
        if (error) {
          setProfileError(error.message);
          console.error('Unable to restore customer session:', error.message);
        }
        // onAuthStateChange also updates the session after password recovery.
        setSession(current => current || data.session);
        setAuthReady(true);
      })
      .catch(error => {
        if (!active) return;
        setProfileError(error?.message || 'Unable to restore customer session.');
        setAuthReady(true);
      });

    return () => {
      active = false;
      linkSubscription.remove();
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    let active = true;
    if (!session?.user?.id || !supabase) {
      setProfile(null);
      setProfileLoading(false);
      setProfileError('');
      return () => { active = false; };
    }
    setProfileLoading(true);
    setProfileError('');
    supabase.from('profiles')
      .select('id,username,full_name,phone,address,avatar_path,created_at,updated_at')
      .eq('id', session.user.id).maybeSingle()
      .then(({data, error}) => {
        if (!active) return;
        if (error) {
          setProfileError(error.message);
          console.error('Unable to load customer profile:', error.message);
        } else setProfile(data);
      })
      .catch(error => {
        if (!active) return;
        setProfileError(error?.message || 'Unable to load customer profile.');
      })
      .finally(() => { if (active) setProfileLoading(false); });
    return () => { active = false; };
  }, [session?.user?.id]);

  const signIn = useCallback(async (identifier, password) => {
    if (!supabase) throw Error('Connect Supabase first. Check your Customer_Expo/.env.');
    const login = identifier.trim();
    const email = login.includes('@') ? login : usernameEmail(login);
    const {data, error} = await supabase.auth.signInWithPassword({email, password});
    if (error) throw error;
    return data;
  }, []);

  const signUp = useCallback(async ({email, password, username, phone, address}) => {
    if (!supabase) throw Error('Connect Supabase first. Check your Customer_Expo/.env.');
    const normalizedEmail = email.trim().toLowerCase();
    await backendRequest('/api/public/customer-signup', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({email: normalizedEmail, password, username, phone, address}),
    });
    const {data, error} = await supabase.auth.signInWithPassword({email: normalizedEmail, password});
    if (error) throw Error(`Your account was created, but automatic sign-in failed: ${error.message}. Please log in with your new account.`);
    return data;
  }, []);

  // Email RECOVERY code (not the passwordless sign-in OTP flow).
  // Supabase sends the mail and validates the one-time code on its server.
  const requestPasswordReset = useCallback(async emailAddress => {
    if (!supabase) throw Error('Customer authentication is not configured.');
    const email = String(emailAddress || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw Error('Enter a valid email address.');
    }
    const {error} = await supabase.auth.resetPasswordForEmail(email,{
      redirectTo:authRedirect('reset-password'),
    });
    if (error) {
      // Avoid giving away whether a particular email has an account.
      if (/user not found|email not found|unknown user/i.test(error.message || '')) {
        return {message: 'If this email has an account, check its inbox for a verification code.'};
      }
      throw Error(error.message || 'Unable to send the code. Check SMTP settings.');
    }
    return {message: 'If this email has an account, check its inbox for a verification code.'};
  }, []);

  const verifyPasswordResetCode = useCallback(async (emailAddress, token) => {
    if (!supabase) throw Error('Customer authentication is not configured.');
    const email = String(emailAddress || '').trim().toLowerCase();
    const code = String(token || '').trim();
    if (!/^\d{6,10}$/.test(code)) throw Error('Enter the full email verification code (6–10 digits).');
    const {data, error} = await supabase.auth.verifyOtp({
      email,
      token: code,
      type: 'recovery',
    });
    if (error) throw Error(error.message || 'Invalid or expired code.');
    if (!data?.session?.user) throw Error('Supabase did not create a recovery session.');
    setSession(data.session);
    setRecoveryMode(true);
    setRecoveryError('');
    return data;
  }, []);

  const updatePassword = useCallback(async newPassword => {
    if (!supabase || !recoveryMode) {
      throw Error('Verify the password recovery code from your email first.');
    }
    const {data: {session: currentSession}, error: sessionError} = await supabase.auth.getSession();
    if (sessionError || !currentSession?.user) {
      throw Error('Your reset session expired. Please request a new verification code.');
    }
    const {error} = await supabase.auth.updateUser({password: newPassword});
    if (error) throw error;
    const {error: signOutError} = await supabase.auth.signOut({scope: 'local'});
    setRecoveryMode(false);
    if (signOutError) throw Error('Your password was updated, but automatic sign-out failed. Please sign out manually.');
  }, [recoveryMode]);

  const updateProfile = useCallback(async ({fullName,username,email,phone,address,avatarAsset}) => {
    if (!supabase || !session?.user?.id) throw Error('Please sign in again before editing your profile.');
    if (!/^[a-z0-9._-]{3,30}$/i.test(username.trim())) {
      throw Error('Username must be 3–30 letters, numbers, dots, underscores or hyphens.');
    }
    if (String(fullName||'').trim().length<2||String(fullName||'').trim().length>70) {
      throw Error('Full name must be between 2 and 70 characters.');
    }
    if (!/^09\d{9}$/.test(phone.trim())) throw Error('Enter an 11-digit Philippine phone number starting with 09.');
    if (address.trim().length<5) throw Error('Enter your complete delivery address.');
    const normalizedUsername = username.trim().toLowerCase();
    const normalizedEmail=String(email||'').trim().toLowerCase();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail))
      throw Error('Enter a valid email address.');
    const currentEmail = session.user.email || '';
    let emailChangeRequested=false;
    let emailChangeError='';
    const oldAvatarPath=profile?.avatar_path||null;
    let newAvatarPath=oldAvatarPath;
    if(avatarAsset){
      const mime=avatarAsset.mimeType||'image/jpeg';
      if(!['image/jpeg','image/png','image/webp'].includes(mime))
        throw Error('Choose a JPEG, PNG, or WebP profile picture.');
      const response=await fetch(avatarAsset.uri);
      if(!response.ok)throw Error('The selected profile picture could not be read.');
      const imageBlob=await response.blob();
      if(!imageBlob.size||imageBlob.size>5*1024*1024)
        throw Error('Choose an image smaller than 5 MB.');
      const extension=mime==='image/png'?'png':mime==='image/webp'?'webp':'jpg';
      newAvatarPath=`${session.user.id}/${Date.now()}-${Math.random().toString(36).slice(2,10)}.${extension}`;
      const {error:uploadError}=await supabase.storage.from('fyi-customer-photos')
        .upload(newAvatarPath,imageBlob,{contentType:mime,upsert:false,cacheControl:'3600'});
      if(uploadError)throw Error(`Unable to upload profile picture: ${uploadError.message}`);
    }
    try {
      const values = {
        id: session.user.id, username: normalizedUsername, full_name: String(fullName).trim(),
        phone: phone.trim(), address: address.trim(), avatar_path:newAvatarPath,
        updated_at: new Date().toISOString(),
      };
      const {data,error} = await supabase.from('profiles')
        .upsert(values,{onConflict:'id'})
        .select('id,username,full_name,phone,address,avatar_path,created_at,updated_at').single();
      if(error)throw error;
      setProfile(data);
      setProfileError('');
      if(avatarAsset&&oldAvatarPath&&oldAvatarPath!==newAvatarPath){
        const {error:removeError}=await supabase.storage.from('fyi-customer-photos').remove([oldAvatarPath]);
        if(removeError)console.warn('Old profile photo cleanup failed:',removeError.message);
      }
      if(normalizedEmail!==currentEmail.toLowerCase()){
        const {error:authError}=await supabase.auth.updateUser({email:normalizedEmail});
        if(authError)emailChangeError=authError.message||'Unable to request the email change.';
        else emailChangeRequested=true;
      }
      return {profile:data,emailChangeRequested,emailChangeError};
    } catch(error) {
      if(avatarAsset&&newAvatarPath&&newAvatarPath!==oldAvatarPath){
        const {error:cleanupError}=await supabase.storage.from('fyi-customer-photos').remove([newAvatarPath]);
        if(cleanupError)console.warn('Unable to clean up an unsaved profile photo:',cleanupError.message);
      }
      throw error;
    }
  }, [session?.user?.id, session?.user?.email, profile?.avatar_path]);

  const signOut = useCallback(async () => {
    if (!supabase) throw Error('Supabase is not configured.');
    const {error} = await supabase.auth.signOut();
    if (error) throw error;
  }, []);

  const value = useMemo(() => ({
    supabase, supabaseConfigured: Boolean(supabase), session, user: session?.user || null,
    profile, authReady, profileLoading, profileError, recoveryMode,
    recoveryPending, recoveryError, signIn, signUp, requestPasswordReset,
    verifyPasswordResetCode, updatePassword, updateProfile, signOut,
  }), [session, profile, authReady, profileLoading, profileError, recoveryMode,
      recoveryPending, recoveryError, signIn, signUp, requestPasswordReset,
      verifyPasswordResetCode, updatePassword, updateProfile, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useCustomerAuth() {
  const value = useContext(AuthContext);
  if (!value) throw Error('useCustomerAuth must be used inside AuthProvider');
  return value;
}
