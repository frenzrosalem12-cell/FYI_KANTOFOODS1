import React, {createContext, useCallback, useContext, useEffect, useMemo, useState} from 'react';
import {AppState} from 'react-native';
import {getStoreStatus} from '../config/storeHours';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ADD_ONS, getProduct, applyServerCatalog} from '../data/products';
import {calculateDeliveryFee} from '../config/delivery';
import {BACKEND_BASE_URL, CONNECTED_MODE, backendRequest} from '../config/backend';
import {useCustomerAuth} from './AuthContext';

const STORAGE_KEY = CONNECTED_MODE ? 'fyikanto-customer-supabase-v1' : 'fyikanto-customer-demo-v1';
const Ctx = createContext(null);
const emptyInfo = {name:'',phone:'',address:'',landmark:'',facebook:'',tableNumber:'',notes:''};
const pickAddOns = item => (ADD_ONS[getProduct(item.productId)?.addOns] || []).filter(a=>item.addOnIds?.includes(a.id));
export const cartItemPrice = item => {
  const p=getProduct(item.productId);
  if(!p) return 0;
  const base=p.sizes.find(s=>s.label===item.size)?.price ?? p.sizes[0].price;
  return base + pickAddOns(item).reduce((n,a)=>n+a.price,0);
};
export const cartItemTotal = item=>cartItemPrice(item)*item.qty;
export function AppProvider({children}) {
  const {authReady,session,profile}=useCustomerAuth();
  const storageKey=`${STORAGE_KEY}:${session?.user?.id||'signed-out'}`;
  const [hydrated,setHydrated] = useState(false);
  const [storeStatus,setStoreStatus] = useState(()=>CONNECTED_MODE
    ? {isOpen:false,label:'Checking Store Status',todayHours:'—',message:'Checking store availability'}
    : getStoreStatus());
  useEffect(()=>{
    if(!CONNECTED_MODE)return undefined;
    let active=true;
    let appState=AppState.currentState;
    let socket=null;
    let reconnectTimer=null;
    let reconnectAttempts=0;
    const applyStatus=remote=>{
      if(typeof remote?.isOpen!=='boolean')return;
      setStoreStatus({
        isOpen:remote.isOpen,
        label:remote.isOpen?'Open Now':'Closed Now',
        todayHours:`${remote.open} – ${remote.close}`,
        message:remote.isOpen?'Accepting orders':'Store is closed'
      });
    };
    const refresh=async()=>{
      try {
        const remote=await backendRequest('/api/public/config');
        if(active)applyStatus(remote);
      } catch(error) {
        if(active) {
          console.warn('Cannot check store status from server:',error.message);
          setStoreStatus({isOpen:false,label:'Temporarily Unavailable',todayHours:'—',message:'Cannot reach the store server. Please try again.'});
        }
      }
    };
    const connect=()=>{
      if(!active||appState!=='active'||socket?.readyState===WebSocket.OPEN||socket?.readyState===WebSocket.CONNECTING)return;
      socket=new WebSocket(BACKEND_BASE_URL.replace(/^http/,'ws')+'/api/public/store-status/live');
      const currentSocket=socket;
      currentSocket.onopen=()=>{reconnectAttempts=0;};
      currentSocket.onmessage=event=>{
        try {
          const message=JSON.parse(event.data);
          if(message.type==='store-status')applyStatus(message);
        } catch(error) {
          console.warn('Invalid store status update:',error.message);
        }
      };
      currentSocket.onclose=()=>{
        if(!active||appState!=='active')return;
        const delay=Math.min(1000*2**reconnectAttempts,15000);
        reconnectAttempts+=1;
        reconnectTimer=setTimeout(connect,delay);
      };
    };
    const refreshAndConnect=()=>{
      refresh();
      if(socket&&socket.readyState!==WebSocket.CLOSED)socket.close();
      connect();
    };
    refresh();
    connect();
    const subscription=AppState.addEventListener('change',next=>{
      appState=next;
      if(next==='active')refreshAndConnect();
      else {
        clearTimeout(reconnectTimer);
        socket?.close();
      }
    });
    return ()=>{
      active=false;
      clearTimeout(reconnectTimer);
      subscription.remove();
      socket?.close();
    };
  },[]);
  const [productCatalogVersion,setProductCatalogVersion] = useState(0);
  useEffect(()=>{
    if(!CONNECTED_MODE)return;
    let mounted=true;
    const load=async()=>{try{
      const response=await backendRequest('/api/public/catalog');
      if(mounted && applyServerCatalog(response))setProductCatalogVersion(x=>x+1);
    }catch(e){console.warn('Catalog sync failed:',e.message);}};
    load();
    const timer=setInterval(load,30000);
    const listener=AppState.addEventListener('change',s=>{if(s==='active')load();});
    return ()=>{mounted=false;clearInterval(timer);listener.remove();};
  },[]);
  const [productImages,setProductImages] = useState({});
  useEffect(()=>{
    if(!CONNECTED_MODE)return;
    let active=true;
    const update=async()=>{
      try {
        const result=await backendRequest('/api/public/product-images');
        if(active && result.images && typeof result.images==='object')setProductImages(result.images);
      }catch(error){console.warn('Product photos unavailable; using bundled photos:',error.message);}
    };
    update();
    const interval=setInterval(update,30*1000);
    const subscription=AppState.addEventListener('change',next=>{if(next==='active')update();});
    return ()=>{active=false;clearInterval(interval);subscription.remove();};
  },[]);
  const [cart,setCart] = useState([]);
  const [orderType,setOrderType] = useState('delivery');
  const [customer,setCustomer] = useState(emptyInfo);
  const [paymentMethod,setPaymentMethodState] = useState('paymongo');
  const [paymentProof,setPaymentProof] = useState(null);
  const [gcashReference,setGcashReference] = useState('');
  const [deliveryLocation,setDeliveryLocationState] = useState(null);
  const setDeliveryLocation=useCallback(location=>{
    setDeliveryLocationState(location);
    // If the delivery location/total changes, old payment proof is no longer valid.
    setPaymentProof(null);
    setGcashReference('');
  },[]);
  const setOrderTypeSafe=useCallback((type)=>{
    setOrderType('delivery');
    setPaymentMethodState('paymongo');
    setPaymentProof(null);
    setGcashReference('');
    if(type!=='delivery')setDeliveryLocationState(null);
  },[]);
  const setPaymentMethod=useCallback(()=>{
    setPaymentMethodState('paymongo');
    setPaymentProof(null);
    setGcashReference('');
  },[]);
  const [orders,setOrders] = useState([]);
  const [reviews,setReviews] = useState([]);
  const [reviewRefresh,setReviewRefresh] = useState(0);
  const [favorites,setFavorites] = useState([]);
  const [productPopularity,setProductPopularity] = useState([]);
  const refreshProductPopularity=useCallback(async()=>{
    if(!CONNECTED_MODE)return;
    try{
      const result=await backendRequest('/api/public/product-popularity');
      if(Array.isArray(result.products))setProductPopularity(result.products);
    }catch(error){console.warn('Product popularity unavailable:',error.message);}
  },[]);

  useEffect(()=>{
    if(!authReady)return;
    let mounted=true;
    setHydrated(false);
    setCart([]);
    setOrders([]);
    setReviews([]);
    setFavorites([]);
    setCustomer(emptyInfo);
    setOrderType('delivery');
    setPaymentMethodState('paymongo');
    setPaymentProof(null);
    setGcashReference('');
    setDeliveryLocationState(null);
    (async()=>{
      try {
        const text=session?.user?.id?await AsyncStorage.getItem(storageKey):null;
        if(text && mounted){
          const data=JSON.parse(text);
          if(Array.isArray(data.cart)) setCart(data.cart.filter(it=>!!getProduct(it.productId)));
          if(Array.isArray(data.orders)) setOrders(data.orders);
          if(!CONNECTED_MODE && Array.isArray(data.reviews)) setReviews(data.reviews);
          if(Array.isArray(data.favorites)) setFavorites(data.favorites);
        }
      } catch(e) { console.warn('Unable to restore customer app data:',e.message); }
      finally {if(mounted) setHydrated(true);}
    })();
    return ()=>{mounted=false;};
  },[authReady,session?.user?.id,storageKey]);
  useEffect(()=>{
    if(!profile)return;
    setCustomer(previous=>({...previous,name:profile.full_name||profile.username||'',phone:profile.phone||'',address:profile.address||''}));
  },[profile]);
  useEffect(()=>{
    if(!hydrated||!session?.user?.id)return;
    AsyncStorage.setItem(storageKey,JSON.stringify({cart,orders,reviews,favorites,orderType:'delivery',paymentMethod:'paymongo'}))
      .catch(e=>console.warn('Unable to save demo data:',e.message));
  },[hydrated,cart,orders,reviews,favorites,storageKey,session?.user?.id]);

  const addToCart=useCallback(({productId,size,variant,addOnIds=[],qty=1})=>{
    if(!storeStatus.isOpen)return false;
    const ids=[...addOnIds].sort();
    const key=[productId,size,variant||'',ids.join('|')].join('::');
    setCart(items=>{
      const existing=items.find(x=>x.key===key);
      if(existing) return items.map(x=>x.key===key?{...x,qty:x.qty+qty}:x);
      return [...items,{key,productId,size,variant:variant||'',addOnIds:ids,qty}];
    });
  },[storeStatus.isOpen]);
  const changeQuantity=useCallback((key,delta)=>setCart(items=>items.map(it=>it.key===key?{...it,qty:Math.max(1,Math.min(99,it.qty+delta))}:it)),[]);
  const removeFromCart=useCallback(key=>setCart(items=>items.filter(it=>it.key!==key)),[]);
  const toggleFavorite=useCallback(async id=>{
    const adding=!favorites.includes(id);
    setFavorites(items=>adding
      ?(items.includes(id)?items:[...items,id])
      :items.filter(item=>item!==id));
    if(!CONNECTED_MODE)return adding;
    if(!session?.access_token){
      setFavorites(items=>adding?items.filter(item=>item!==id):(items.includes(id)?items:[...items,id]));
      throw Error('Please sign in again before updating favorites.');
    }
    try{
      await backendRequest('/api/public/favorites',{
        method:'POST',
        headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},
        body:JSON.stringify({productId:id,favorite:adding}),
      });
      void refreshProductPopularity();
      return adding;
    }catch(error){
      setFavorites(items=>adding?items.filter(item=>item!==id):(items.includes(id)?items:[...items,id]));
      throw error;
    }
  },[favorites,session?.access_token,refreshProductPopularity]);

  const subtotal=useMemo(()=>cart.reduce((total,item)=>total+cartItemTotal(item),0),[cart,productCatalogVersion]);
  const cartCount=useMemo(()=>cart.reduce((total,item)=>total+item.qty,0),[cart]);
  // No delivery fee is quoted until a drivable route is calculated.
  const hasDeliveryRoute=!!(deliveryLocation && deliveryLocation.source==='backend_route' &&
    Number.isFinite(deliveryLocation.storeLatitude) && Number.isFinite(deliveryLocation.storeLongitude) &&
    Number.isFinite(deliveryLocation.distanceKm) && Number.isFinite(deliveryLocation.fee) &&
    deliveryLocation.fee===calculateDeliveryFee(deliveryLocation.distanceKm));
  const deliveryFee=orderType==='delivery'?(hasDeliveryRoute?deliveryLocation.fee:null):0;
  const total=deliveryFee===null?null:subtotal+deliveryFee;
  const latestOrder=orders[0]||null;
  const createOrder=useCallback(async()=>{
    if(cart.length===0 || !storeStatus.isOpen) return null;
    if(!session?.access_token)throw Error('Please sign in again before placing your order.');
    if(orderType==='delivery' && (!hasDeliveryRoute || total===null)) return null;
    const id='FYI'+Date.now().toString().slice(-8);
    const newOrder={id,type:'delivery',customer:{...customer},paymentMethod:'paymongo',
      paymentStatus:'pending_payment',paymentProof:null,gcashReference:'',
      items:cart.map(it=>({...it})),subtotal,
      deliveryLocation:orderType==='delivery'?{...deliveryLocation}:null,
      deliveryFee,total,
      status:'pending_payment',createdAt:new Date().toISOString(),reviewed:false};
    if(!CONNECTED_MODE)throw Error('Connect the customer app to the backend before placing an order.');
    const result=await backendRequest('/api/public/orders',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},body:JSON.stringify({
        type:'delivery',customer,items:cart.map(({productId,size,variant,addOnIds,qty})=>({productId,size,variant,addOnIds,qty})),
        paymentMethod:'paymongo',
        delivery:orderType==='delivery'?{lat:deliveryLocation.latitude,lng:deliveryLocation.longitude}:null,
      })});
    newOrder.id=result.id;
    newOrder.trackingToken=result.trackingToken;
    newOrder.status=result.status;
    newOrder.paymentStatus=result.paymentStatus;
    newOrder.paymentUrl=result.paymentUrl;
    newOrder.total=result.total;
    setOrders(prev=>[newOrder,...prev]);
    setCart([]);
    setPaymentProof(null);
    setGcashReference('');
    setDeliveryLocationState(null);
    return newOrder;
  },[cart,orderType,customer,subtotal,total,deliveryLocation,deliveryFee,hasDeliveryRoute,storeStatus.isOpen,session?.access_token]);
  const advanceOrder=useCallback(id=>{if(CONNECTED_MODE)return;setOrders(all=>all.map(order=>{
    if(order.id!==id || order.status==='pending_verification') return order;
    const stages=['confirmed','preparing','out','delivered'];
    const index=stages.indexOf(order.status);
    return {...order,status:stages[Math.min(index+1,stages.length-1)]};
  }));},[]);
  const submitCustomerReview=useCallback(async({name,productName,rating,message})=>{
    const reviewName=String(name||'').trim();
    const reviewProduct=String(productName||'').trim();
    const reviewMessage=String(message||'').trim();
    if(reviewName.length<2)throw Error('Please enter a name with at least 2 characters.');
    if(!Number.isInteger(rating)||rating<1||rating>5)throw Error('Choose a rating from 1 to 5 stars.');
    if(reviewMessage.length<5)throw Error('Please write at least 5 characters.');
    if(CONNECTED_MODE){
      const result=await backendRequest('/api/public/review',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({name:reviewName,productName:reviewProduct,rating,message:reviewMessage})
      });
      if(result.review)setReviews(previous=>[{...result.review,date:result.review.at},...previous]);
      setReviewRefresh(value=>value+1);
      return true;
    }
    setReviews(previous=>[{
      id:`review-${Date.now()}`,name:reviewName,productName:reviewProduct||null,
      rating,message:reviewMessage,date:new Date().toISOString()
    },...previous]);
    return true;
  },[]);
  const submitOrderFeedback=useCallback(async(orderId,feedback)=>{
    if(!CONNECTED_MODE||!session?.access_token)
      throw Error('Please reconnect and sign in before submitting an order review.');
    await backendRequest('/api/public/order-feedback',{
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},
      body:JSON.stringify({orderId,reviews:feedback}),
    });
    setOrders(previous=>previous.map(order=>order.id===orderId?{...order,reviewed:true}:order));
    return true;
  },[session?.access_token]);
  useEffect(()=>{
    if(!CONNECTED_MODE||!authReady||!session?.access_token)return;
    let active=true;
    backendRequest('/api/public/favorites',{
      headers:{'Authorization':`Bearer ${session.access_token}`},
    }).then(result=>{
      if(active&&Array.isArray(result.favorites))setFavorites(result.favorites);
    }).catch(error=>console.warn('Customer favorites unavailable:',error.message));
    return ()=>{active=false;};
  },[authReady,session?.access_token]);
  useEffect(()=>{
    if(!CONNECTED_MODE)return;
    let active=true;
    const refresh=()=>{if(active)void refreshProductPopularity();};
    refresh();
    const subscription=AppState.addEventListener('change',next=>{if(next==='active')refresh();});
    return ()=>{active=false;subscription.remove();};
  },[refreshProductPopularity]);
  useEffect(()=>{
    if(!CONNECTED_MODE)return;
    let active=true;
    const tick=async()=>{
      const tracked=orders.filter(o=>o.trackingToken).slice(0,15);
      await Promise.all(tracked.map(async o=>{
        try{const result=await backendRequest(`/api/public/order-status?id=${encodeURIComponent(o.id)}&token=${encodeURIComponent(o.trackingToken)}`);
          if(active)setOrders(old=>old.map(x=>x.id===o.id&&
            (x.status!==result.order.status||x.paymentStatus!==result.order.paymentStatus||x.reviewed!==result.order.reviewed)?
            {...x,status:result.order.status,paymentStatus:result.order.paymentStatus,history:result.order.history,reviewed:result.order.reviewed}:x));
        }catch(err){console.warn('Tracking unavailable',err.message);}
      }));
    };
    tick();const timer=setInterval(tick,7000);return ()=>{active=false;clearInterval(timer);};
  },[orders.map(o=>o.id+':'+o.status).join('|')]);
  useEffect(()=>{
    if(orders.some(order=>order.paymentStatus==='paid'))void refreshProductPopularity();
  },[orders.map(order=>`${order.id}:${order.paymentStatus}`).join('|'),refreshProductPopularity]);
  // Fetch approved reviews from PostgreSQL; the backend exposes only public reviews.
  useEffect(()=>{
    if(!CONNECTED_MODE)return;
    let active=true;
    const refresh=async()=>{
      try {const response=await backendRequest('/api/public/reviews');
        if(active)setReviews((response.reviews||[]).map(r=>({...r,date:r.at})));
      } catch(e){console.warn('Reviews unavailable:',e.message);}
    };
    refresh();
    const interval=setInterval(refresh,30000);
    return ()=>{active=false;clearInterval(interval);};
  },[reviewRefresh]);
  const resetDemo=useCallback(()=>{setCart([]);setOrders([]);setReviews([]);setFavorites([]);setProductPopularity([]);setCustomer(emptyInfo);setOrderType('delivery');setPaymentMethodState('paymongo');setPaymentProof(null);setGcashReference('');setDeliveryLocationState(null);},[]);
  const value={hydrated,storeStatus,productImages,productCatalogVersion,cart,subtotal,cartCount,orderType,setOrderType:setOrderTypeSafe,customer,setCustomer,
    paymentMethod,setPaymentMethod,paymentProof,setPaymentProof,gcashReference,setGcashReference,orders,latestOrder,reviews,favorites,productPopularity,total,deliveryFee,deliveryLocation,setDeliveryLocation,hasDeliveryRoute,
    addToCart,changeQuantity,removeFromCart,toggleFavorite,createOrder,advanceOrder,submitCustomerReview,submitOrderFeedback,resetDemo};
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useApp(){ const value=useContext(Ctx); if(!value) throw Error('useApp must be used inside AppProvider'); return value; }
