import React, {useEffect,useState} from 'react';
import {Alert, Image, Pressable, StyleSheet, Text, TextInput, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {SafeAreaView} from 'react-native-safe-area-context';
import {C, money, shadow} from '../constants/theme';
import {getCategory} from '../data/products';
import {photos} from '../data/images';
import {useApp} from '../context/AppContext';

export const Txt=({children,style,...rest})=><Text {...rest} style={[{color:C.ink,fontSize:14},style]}>{children}</Text>;
export const Page=({children,style,edges=['top','bottom']})=><SafeAreaView edges={edges} style={[{flex:1,backgroundColor:C.cream},style]}>{children}</SafeAreaView>;
export function Logo({small=false}){
  return <View style={{flexDirection:'row',alignItems:'center',gap:8}}>
    <Image source={require('../assets/fyi-original-logo.png')} resizeMode="contain"
      style={{width:small?52:83,height:small?40:64}} accessibilityLabel="Original FYI green orange blue logo" />
    <View><Txt style={{fontSize:small?14:18,fontWeight:'900',color:C.forest,letterSpacing:-0.6}}>FYI KANTO</Txt><Txt style={{fontSize:small?8:9,fontWeight:'700',color:C.green,letterSpacing:1}}>SMART MENU</Txt></View>
  </View>;
}
// Header inspired by the user-provided reference. Status is read from
// the Philippine-time schedule in config/storeHours.js.
export function StoreBrandHeader(){
 const {storeStatus}=useApp();
 return <View style={{backgroundColor:C.cream,paddingTop:12,paddingBottom:11}}>
   <View style={{flexDirection:'row',alignItems:'center',gap:9}}>
     <Image source={require('../assets/fyi-original-logo.png')} resizeMode="contain"
       style={{width:84,height:52}} accessibilityLabel="FYI original logo"/>
     <View style={{flex:1,minWidth:0}}>
       <View style={{flexDirection:'row',alignItems:'center',gap:6}}>
         <View style={{width:8,height:8,borderRadius:5,backgroundColor:storeStatus.isOpen?C.green:C.red}}/>
         <Txt style={{fontSize:14,color:storeStatus.isOpen?C.green:C.red,fontWeight:'700'}}>{storeStatus.label}</Txt>
       </View>
       <Txt numberOfLines={1} adjustsFontSizeToFit style={{fontSize:17,fontWeight:'900',color:C.green,marginTop:2}}>FEED YOUR INTESTINE</Txt>
     </View>
   </View>
   <Txt style={{color:C.green,fontSize:11,marginTop:1}}>Beside USTP – Jasaan Campus · Delivery 15–30 min (est.)</Txt>
   {!storeStatus.isOpen?<View style={{marginTop:10,backgroundColor:'#FFF1EF',borderWidth:1,borderColor:'#F6C3C2',borderRadius:10,padding:9,flexDirection:'row',gap:8,alignItems:'center'}}>
     <Ionicons name="moon-outline" size={17} color={C.red}/>
     <Txt style={{color:'#9D3434',fontSize:12,flex:1,fontWeight:'700'}}>Store closed · Orders unavailable right now. Today's hours: {storeStatus.todayHours}</Txt>
   </View>:null}
 </View>;
}
export function ClosedNotice(){
 const {storeStatus}=useApp();
 if(storeStatus.isOpen)return null;
 return <View style={{backgroundColor:'#FFF1EF',padding:13,borderRadius:13,borderWidth:1,borderColor:'#F6C3C2',marginBottom:12,flexDirection:'row',alignItems:'center',gap:9}}>
   <Ionicons name="time-outline" size={20} color={C.red}/>
   <Txt style={{color:'#9D3434',flex:1,fontSize:12,fontWeight:'700'}}>Closed Now — ordering resumes during business hours ({storeStatus.todayHours}). You may still browse the menu.</Txt>
 </View>;
}
export function Header({title,subtitle,onBack,right}){
  return <View style={styles.header}>
    {onBack?<Pressable onPress={onBack} hitSlop={10} style={styles.iconButton}><Ionicons name="chevron-back" size={23} color={C.forest}/></Pressable>:null}
    <View style={{flex:1}}><Txt style={{fontSize:19,fontWeight:'900'}}>{title}</Txt>{subtitle?<Txt style={{fontSize:12,color:C.muted,marginTop:2}}>{subtitle}</Txt>:null}</View>
    {right}
  </View>;
}
export function IconButton({name,onPress,color=C.forest,style}){return <Pressable delayPressIn={0} onPress={onPress} style={[styles.iconButton,style]}><Ionicons name={name} size={22} color={color}/></Pressable>}
export function Button({children,onPress,disabled=false,secondary=false,outline=false,icon='arrow-forward',style,textStyle}){
  return <Pressable accessibilityRole="button" delayPressIn={0} disabled={disabled} onPress={onPress} style={({pressed})=>[
    styles.primary,secondary&&{backgroundColor:C.mint},outline&&{backgroundColor:C.white,borderColor:C.green,borderWidth:1.3},disabled&&{opacity:0.5},pressed&&!disabled&&{opacity:0.86,transform:[{scale:0.99}]},style]}>
    <Txt style={[styles.primaryText,(secondary||outline)&&{color:C.forest},textStyle]}>{children}</Txt>
    {icon?<Ionicons name={icon} size={19} color={secondary||outline?C.green:C.white}/>:null}
  </Pressable>;
}
export function Chip({text,active,onPress,icon}){
  return <Pressable delayPressIn={0} onPress={onPress} style={[styles.chip,active&&styles.chipActive]}>
    {icon?<Ionicons name={icon} size={14} color={active?C.white:C.forest}/>:null}
    <Txt style={{color:active?C.white:C.forest,fontWeight:'800',fontSize:12}}>{text}</Txt>
  </Pressable>;
}
export function Photo({productId,image,category,style,resizeMode='cover',emojiSize=55}){
  const {productImages}=useApp();
  const remoteUrl=productId?productImages?.[productId]:null;
  const [failed,setFailed]=useState(false);
  useEffect(()=>setFailed(false),[remoteUrl]);
  if(remoteUrl && !failed)return <Image source={{uri:remoteUrl}} resizeMode={resizeMode}
    onError={()=>setFailed(true)} style={[{width:'100%',height:'100%'},style]}/>;
  if(image&&photos[image])return <Image source={photos[image]} resizeMode={resizeMode}
    style={[{width:'100%',height:'100%'},style]}/>;
  const cat=getCategory(category);
  return <View style={[{width:'100%',height:'100%',backgroundColor:cat.color,justifyContent:'center',alignItems:'center'},style]}>
    <Txt style={{fontSize:emojiSize}}>{cat.emoji}</Txt>
    <Txt style={{fontSize:10,color:C.forest,opacity:.55,fontWeight:'800'}}>FYI KANTO</Txt>
  </View>;
}

export function ProductCard({product,onPress,onAdd,width,isFavorite=false,onToggleFavorite,favoriteCount=0,orderCount=0}){
  const toggle=async()=>{
    try{await onToggleFavorite?.();}
    catch(error){Alert.alert('Favorite not saved',error.message||'Please try again.');}
  };
  return <View style={[styles.productCard,{width}]}>
    <Pressable delayPressIn={0} onPress={onPress}>
      <View style={{height:160,backgroundColor:C.mint,overflow:'hidden',borderTopLeftRadius:15,borderTopRightRadius:15}}>
        <Photo productId={product.id} image={product.image} category={product.category}/>
      </View>
      <View style={{padding:10,minHeight:126,justifyContent:'space-between'}}>
        <View>
          <Txt numberOfLines={2} style={{fontWeight:'900',fontSize:13,lineHeight:17,minHeight:34}}>{product.name}</Txt>
          <Txt numberOfLines={1} style={{fontSize:11,color:C.muted,marginTop:4}}>{getCategory(product.category).label}</Txt>
        </View>
        <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:12}}>
          <Txt style={{fontWeight:'900',fontSize:16,color:C.green}}>{money(product.sizes[0].price)}{product.sizes.length>1?'+':''}</Txt>
          <Pressable accessibilityLabel={'Choose '+product.name} onPress={onAdd||onPress} style={styles.plus}>
            <Ionicons name="add" color="white" size={20}/>
          </Pressable>
        </View>
        <View style={styles.productStats}>
          <View style={styles.productStat}><Ionicons name="heart" size={13} color={C.red}/><Txt style={styles.productStatText}>{favoriteCount}</Txt></View>
          <View style={styles.productStat}><Ionicons name="bag-handle-outline" size={13} color={C.green}/><Txt style={styles.productStatText}>{orderCount}</Txt></View>
        </View>
      </View>
    </Pressable>
    {onToggleFavorite?<Pressable accessibilityRole="button"
      accessibilityLabel={isFavorite?'Remove from favorites':'Add to favorites'}
      onPress={toggle} style={styles.favoriteButton}>
      <Ionicons name={isFavorite?'heart':'heart-outline'} size={19} color={isFavorite?C.red:C.forest}/>
    </Pressable>:null}
  </View>;
}
export function FormField({label,value,onChangeText,placeholder,multiline=false,keyboardType='default',maxLength,required=false,autoCapitalize='sentences',editable=true,style}){
  return <View style={[{marginBottom:15},style]}><Txt style={{fontSize:13,fontWeight:'800',marginBottom:7}}>{label}{required?<Text style={{color:C.red}}> *</Text>:null}</Txt>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#A4AEA8"
      multiline={multiline} numberOfLines={multiline?3:1} maxLength={maxLength} keyboardType={keyboardType} autoCapitalize={autoCapitalize} editable={editable}
      style={[styles.textField,multiline&&{height:92,textAlignVertical:'top'}]} />
  </View>;
}
export function SummaryLine({label,value,bold=false,color}){
  return <View style={{flexDirection:'row',justifyContent:'space-between',paddingVertical:7}}><Txt style={{fontSize:bold?15:13,color:bold?C.forest:C.muted,fontWeight:bold?'900':'500'}}>{label}</Txt><Txt style={{fontSize:bold?17:13,fontWeight:bold?'900':'700',color:color||C.forest}}>{value}</Txt></View>;
}
export const Line=()=> <View style={{height:1,backgroundColor:C.border,marginVertical:7}}/>;
export const Card=({children,style})=><View style={[styles.card,style]}>{children}</View>;
const styles=StyleSheet.create({
 logoSquare:{height:38,width:38,backgroundColor:C.green,borderRadius:11,alignItems:'center',justifyContent:'center'},
 header:{flexDirection:'row',alignItems:'center',paddingHorizontal:18,paddingTop:10,paddingBottom:14,gap:12,backgroundColor:C.cream},
 iconButton:{width:39,height:39,borderRadius:12,borderWidth:1,borderColor:C.border,backgroundColor:C.white,alignItems:'center',justifyContent:'center'},
 primary:{backgroundColor:C.green,paddingHorizontal:18,minHeight:52,borderRadius:15,flexDirection:'row',gap:10,alignItems:'center',justifyContent:'center'},
 primaryText:{fontWeight:'900',color:C.white,fontSize:14},
 chip:{paddingHorizontal:15,paddingVertical:9,backgroundColor:C.white,borderColor:C.border,borderWidth:1,borderRadius:22,flexDirection:'row',gap:5,alignItems:'center'},
 chipActive:{backgroundColor:C.green,borderColor:C.green},
 productCard:{backgroundColor:C.white,borderRadius:15,borderWidth:1,borderColor:C.border,overflow:'hidden',...shadow,marginBottom:12},
 favoriteButton:{position:'absolute',top:9,right:9,width:37,height:37,borderRadius:20,alignItems:'center',justifyContent:'center',backgroundColor:'rgba(255,255,255,.96)',borderWidth:1,borderColor:C.border},
 productStats:{flexDirection:'row',gap:13,marginTop:9},
 productStat:{flexDirection:'row',alignItems:'center',gap:4},
 productStatText:{fontSize:10,color:C.muted,fontWeight:'800'},
 plus:{width:30,height:30,backgroundColor:C.green,borderRadius:15,alignItems:'center',justifyContent:'center'},
 textField:{height:49,borderRadius:12,borderColor:'#DFE8E1',borderWidth:1,backgroundColor:C.white,paddingHorizontal:14,paddingVertical:11,fontSize:14,color:C.forest},
 card:{padding:16,borderWidth:1,borderColor:C.border,backgroundColor:C.white,borderRadius:17,...shadow},
});
