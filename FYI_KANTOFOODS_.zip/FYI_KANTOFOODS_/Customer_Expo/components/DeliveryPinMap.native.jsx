import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {ActivityIndicator, StyleSheet, Text, View} from 'react-native';
import {WebView} from 'react-native-webview';
import {STORE} from '../config/delivery';

// Leaflet renders OpenStreetMap tiles inside a WebView, avoiding the black
// native-Google-Maps canvas some Expo Go users see on Android.
// It needs internet to load Leaflet and the OSM tiles.
const MAP_HTML = String.raw`<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css" />
<style>
html,body,#map{width:100%;height:100%;margin:0;padding:0;overflow:hidden;background:#f0ede7;font-family:Arial,sans-serif}
.leaflet-container{background:#efece4;font-family:Arial,sans-serif}
.leaflet-control-zoom{border:1px solid #dedbd6!important;box-shadow:0 2px 8px rgba(0,0,0,.16)!important;overflow:hidden;border-radius:9px!important}
.leaflet-control-zoom a{height:36px!important;line-height:36px!important;width:36px!important;color:#183e30!important;font-size:22px!important}
.leaflet-control-attribution{background:rgba(255,255,255,.87)!important;font-size:10px!important}
.pin{width:24px;height:24px;border:3px solid white;box-sizing:border-box;background:#ed5b37;border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 2px 5px #0005;position:relative}
.pin:after{content:'';position:absolute;width:7px;height:7px;background:#fff;border-radius:50%;left:6px;top:6px}
.store{background:#087452;border:2px solid white;border-radius:100%;width:20px;height:20px;box-shadow:0 0 0 2px #087452,0 2px 6px #0004}
#failure{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:#f5f3ed;text-align:center;padding:20px;z-index:1000;color:#2d493c;font-weight:bold}
</style></head><body>
<div id="map"></div><div id="failure">Could not load OpenStreetMap. Check your internet connection and reopen the map.</div>
<script>
function notify(type,data){try{window.ReactNativeWebView.postMessage(JSON.stringify(Object.assign({type:type},data||{})));}catch(e){}}
function fail(){document.getElementById('failure').style.display='flex';notify('error',{message:'Map tiles/library unavailable. Check internet connection.'});}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js" onerror="fail()"></script>
<script>
(function(){
 if(typeof L==='undefined'){fail();return;}
 var store=__STORE__;
 var initial=__INITIAL_PIN__;
 var map=L.map('map',{zoomControl:true,attributionControl:true}).setView([store.latitude,store.longitude],15);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
   maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',crossOrigin:true
 }).addTo(map);
 var storeMarker=L.marker([store.latitude,store.longitude],{
   icon:L.divIcon({className:'',html:'<div class="store"></div>',iconSize:[22,22],iconAnchor:[11,11]})
 }).addTo(map).bindPopup('FYI-KANTO store (demo position)');
 var customer=null;
 var line=null;
 var pinIcon=L.divIcon({className:'',html:'<div class="pin"></div>',iconSize:[28,32],iconAnchor:[12,30]});
 function setPin(coords,center){
   if(!coords||!Number.isFinite(coords.latitude)||!Number.isFinite(coords.longitude))return;
   var at=[coords.latitude,coords.longitude];
   if(!customer){
     customer=L.marker(at,{icon:pinIcon,draggable:true,autoPan:true}).addTo(map);
     customer.bindTooltip('Your delivery location',{direction:'top'});
     customer.on('dragend',function(ev){
        var point=ev.target.getLatLng();notify('pick',{latitude:point.lat,longitude:point.lng});
     });
   }else{customer.setLatLng(at);}
   if(center)map.setView(at,Math.max(map.getZoom(),16));
 }
 map.on('click',function(ev){
   var p={latitude:ev.latlng.lat,longitude:ev.latlng.lng};
   setPin(p,false);notify('pick',p);
 });
 window.setDestinationPin=function(coords){setPin(coords,true);};
 window.setRoute=function(coords){
    if(line){map.removeLayer(line);line=null;}
    if(Array.isArray(coords)&&coords.length>1){
      var points=coords.filter(function(p){return p&&Number.isFinite(p.latitude)&&Number.isFinite(p.longitude)}).map(function(p){return [p.latitude,p.longitude]});
      if(points.length>1)line=L.polyline(points,{color:'#087452',weight:5,opacity:.85}).addTo(map);
    }
 };
 if(initial)setPin(initial,false);
 setTimeout(function(){map.invalidateSize();notify('ready');},200);
})();
</script></body></html>`;

export default function DeliveryPinMap({pin, onPick, routeCoordinates = [],storeLocation=null}) {
  const ref = useRef(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const routeData = JSON.stringify(routeCoordinates);
  const pinData = pin ? JSON.stringify(pin) : null;
  const store=storeLocation||{latitude:STORE.latitude,longitude:STORE.longitude};
  const html = useMemo(() => MAP_HTML
    .replace('__STORE__', JSON.stringify(store))
    .replace('__INITIAL_PIN__', pinData || 'null'), [store.latitude,store.longitude]);

  const runJS = useCallback((code)=>{
    if(ref.current)ref.current.injectJavaScript(code + ';true;');
  }, []);
  useEffect(()=>{if(ready && pinData)runJS('window.setDestinationPin(' + pinData + ')');},[ready,pinData,runJS]);
  useEffect(()=>{if(ready)runJS('window.setRoute(' + routeData + ')');},[ready,routeData,runJS]);
  const receive = useCallback((event)=>{
    try {
      const msg = JSON.parse(event.nativeEvent.data);
      if(msg.type==='ready')setReady(true);
      if(msg.type==='error')setFailed(true);
      if(msg.type==='pick' && Number.isFinite(msg.latitude) && Number.isFinite(msg.longitude)
          && Math.abs(msg.latitude)<=90 && Math.abs(msg.longitude)<=180){
        onPick({latitude:msg.latitude,longitude:msg.longitude});
      }
    } catch(e){console.warn('Map message ignored:',e.message);}
  },[onPick]);
  return <View style={styles.box}>
    <WebView
      ref={ref} source={{html,baseUrl:'https://www.openstreetmap.org/'}}
      originWhitelist={['*']} onMessage={receive}
      javaScriptEnabled domStorageEnabled mixedContentMode="never"
      onError={()=>setFailed(true)}
      startInLoadingState renderLoading={()=> <View style={styles.loading}><ActivityIndicator size="large" color="#087452"/><Text style={styles.loadingText}>Loading Jasaan map…</Text></View>}
      scrollEnabled={false}
      setSupportMultipleWindows={false}
      style={styles.webview}
    />
    {failed ? <View style={styles.warning}><Text style={styles.warningText}>The map could not load. Connect to the internet, then leave this screen and open it again.</Text></View> : null}
  </View>;
}
const styles=StyleSheet.create({
 box:{flex:1,minHeight:225,backgroundColor:'#eeeae1'},
 webview:{flex:1,backgroundColor:'#eeeae1'},
 loading:{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'#f2f0e9'},
 loadingText:{fontSize:12,marginTop:10,color:'#416052'},
 warning:{position:'absolute',bottom:6,left:9,right:9,backgroundColor:'#fff2e5',padding:8,borderRadius:8},
 warningText:{fontSize:11,color:'#975828',textAlign:'center'},
});
