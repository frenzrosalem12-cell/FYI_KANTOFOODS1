import React, {useEffect, useMemo, useState} from 'react';
import {ActivityIndicator, Alert, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, TextInput, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {Button, Txt} from './UI';
import {C} from '../constants/theme';

function Stars({value,onChange,label}){
  return <View style={styles.stars}>
    {[1,2,3,4,5].map(star=><Pressable key={star} accessibilityRole="button"
      accessibilityLabel={`${label}: ${star} star${star===1?'':'s'}`}
      onPress={()=>onChange(star)} hitSlop={5}>
      <Ionicons name={star<=value?'star':'star-outline'} size={31} color={star<=value?C.yellow:'#C8D0CB'}/>
    </Pressable>)}
  </View>;
}

function ReviewSection({title,question,rating,onRatingChange,comment,onCommentChange,placeholder}){
  return <View style={styles.section}>
    <Txt style={styles.sectionTitle}>{title}</Txt>
    <Txt style={styles.question}>{question}</Txt>
    <Stars value={rating} onChange={onRatingChange} label={title}/>
    <TextInput value={comment} onChangeText={onCommentChange} multiline maxLength={500}
      placeholder={placeholder} placeholderTextColor="#96A99C" style={styles.comment}/>
  </View>;
}

export default function OrderFeedbackModal({visible,order,onClose,onSubmit}){
  const items=useMemo(()=>{
    const distinct=new Map();
    for(const item of order?.items||[]){
      if(item?.productId&&!distinct.has(item.productId))
        distinct.set(item.productId,{productId:item.productId,name:item.name||item.productName||item.productId});
    }
    return [...distinct.values()];
  },[order?.id]);
  const [productRatings,setProductRatings]=useState({});
  const [productComments,setProductComments]=useState({});
  const [deliveryRating,setDeliveryRating]=useState(0);
  const [deliveryComment,setDeliveryComment]=useState('');
  const [serviceRating,setServiceRating]=useState(0);
  const [serviceComment,setServiceComment]=useState('');
  const [overallComment,setOverallComment]=useState('');
  const [submitting,setSubmitting]=useState(false);

  useEffect(()=>{
    if(!visible)return;
    setProductRatings({});
    setProductComments({});
    setDeliveryRating(0);
    setDeliveryComment('');
    setServiceRating(0);
    setServiceComment('');
    setOverallComment('');
  },[visible,order?.id]);

  const submit=async()=>{
    if(items.some(item=>!productRatings[item.productId]))
      return Alert.alert('Rate each item','Please choose a star rating for each product in your order.');
    if(!deliveryRating||!serviceRating)
      return Alert.alert('Complete your ratings','Please rate delivery and customer service before submitting.');
    const reviews=[
      ...items.map(item=>({
        reviewType:'product',productId:item.productId,
        rating:productRatings[item.productId],
        message:productComments[item.productId]||'',
      })),
      {reviewType:'delivery',rating:deliveryRating,message:deliveryComment},
      {reviewType:'service',rating:serviceRating,message:serviceComment},
    ];
    if(overallComment.trim())reviews.push({reviewType:'overall',rating:null,message:overallComment.trim()});
    setSubmitting(true);
    try{
      await onSubmit(order.id,reviews);
      Alert.alert('Thank you!','Your feedback has been saved.');
      onClose();
    }catch(error){
      Alert.alert('Could not save your review',error.message||'Check your connection and try again.');
    }finally{
      setSubmitting(false);
    }
  };

  return <Modal transparent animationType="slide" visible={visible} onRequestClose={onClose}>
    <View style={styles.scrim}>
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={styles.panel}>
        <View style={styles.header}>
          <View style={{flex:1}}>
            <Txt style={styles.title}>How Was Your FYI-KANTO Experience?</Txt>
            <Txt style={styles.subtitle}>Thank you for ordering with us! Your feedback helps us improve.</Txt>
          </View>
          <Pressable accessibilityLabel="Close feedback" onPress={onClose} disabled={submitting} hitSlop={10}>
            <Ionicons name="close" size={24} color={C.muted}/>
          </Pressable>
        </View>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}
          contentContainerStyle={{paddingBottom:18}}>
          <Txt style={styles.orderRef}>Order #{order?.id}</Txt>
          {items.map(item=><ReviewSection key={item.productId}
            title={item.name} question="How was your food or drink?"
            rating={productRatings[item.productId]||0}
            onRatingChange={rating=>setProductRatings(previous=>({...previous,[item.productId]:rating}))}
            comment={productComments[item.productId]||''}
            onCommentChange={comment=>setProductComments(previous=>({...previous,[item.productId]:comment}))}
            placeholder="Taste, quality, freshness, or presentation (optional)"/>)}
          <ReviewSection title="Delivery experience" question="How was your delivery?"
            rating={deliveryRating} onRatingChange={setDeliveryRating}
            comment={deliveryComment} onCommentChange={setDeliveryComment}
            placeholder="Speed, order condition, or handling (optional)"/>
          <ReviewSection title="Customer service" question="How was our customer service?"
            rating={serviceRating} onRatingChange={setServiceRating}
            comment={serviceComment} onCommentChange={setServiceComment}
            placeholder="Staff friendliness or assistance (optional)"/>
          <View style={styles.section}>
            <Txt style={styles.sectionTitle}>Overall feedback</Txt>
            <TextInput value={overallComment} onChangeText={setOverallComment} multiline maxLength={500}
              placeholder="Tell us more about your overall FYI-KANTO experience..."
              placeholderTextColor="#96A99C" style={styles.comment}/>
          </View>
          <Pressable onPress={submit} disabled={submitting||!items.length}
            style={[styles.submitButton,(submitting||!items.length)&&{opacity:.55}]}>
            {submitting?<ActivityIndicator color={C.white}/>:<Ionicons name="checkmark-circle-outline" size={19} color={C.white}/>}
            <Txt style={styles.submitText}>{submitting?'Submitting…':'SUBMIT REVIEW'}</Txt>
          </Pressable>
          <Button secondary onPress={onClose} disabled={submitting} icon={null} style={{marginTop:9}}>
            MAYBE LATER
          </Button>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  </Modal>;
}

const styles=StyleSheet.create({
  scrim:{flex:1,backgroundColor:'rgba(11,42,32,.58)',justifyContent:'flex-end',alignItems:'center'},
  panel:{width:'100%',maxWidth:520,maxHeight:'92%',backgroundColor:C.cream,borderTopLeftRadius:22,borderTopRightRadius:22,paddingHorizontal:18,paddingTop:19,paddingBottom:16},
  header:{flexDirection:'row',alignItems:'flex-start',gap:12,paddingBottom:11},
  title:{fontSize:19,lineHeight:24,fontWeight:'900',color:C.forest},
  subtitle:{fontSize:12,lineHeight:18,color:C.muted,marginTop:6},
  orderRef:{fontSize:11,color:C.green,fontWeight:'900',marginBottom:7},
  section:{backgroundColor:C.white,borderRadius:15,borderWidth:1,borderColor:C.border,padding:13,marginBottom:10},
  sectionTitle:{fontSize:14,fontWeight:'900',color:C.forest},
  question:{fontSize:12,color:C.muted,marginTop:5},
  stars:{flexDirection:'row',justifyContent:'center',gap:12,marginVertical:12},
  comment:{minHeight:70,maxHeight:120,textAlignVertical:'top',borderRadius:11,backgroundColor:C.cream,borderWidth:1,borderColor:C.border,padding:11,fontSize:12,color:C.forest},
  submitButton:{marginTop:8,minHeight:52,borderRadius:15,backgroundColor:C.green,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:9},
  submitText:{fontSize:14,fontWeight:'900',color:C.white},
});
