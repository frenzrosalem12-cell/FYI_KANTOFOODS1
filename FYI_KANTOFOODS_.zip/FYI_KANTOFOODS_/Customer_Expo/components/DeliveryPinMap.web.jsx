import React, {useEffect, useRef, useState} from 'react';
import {View, Text} from 'react-native';
import {C} from '../constants/theme';
import {STORE} from '../config/delivery';

// Browser map for the same Expo customer interface used by the QR link.
// Loads Leaflet only on the WEB platform; native keeps DeliveryPinMap.native.jsx.
// Requires internet for OpenStreetMap tiles and OSRM demo road routing.
let leafletPromise;
function loadLeaflet() {
  if (typeof window === 'undefined') return Promise.reject(Error('Browser unavailable'));
  if (window.L) return Promise.resolve(window.L);
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise((resolve, reject) => {
    if (!document.querySelector('#fyi-leaflet-css')) {
      const link = document.createElement('link');
      link.id = 'fyi-leaflet-css'; link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.async = true;
    script.onload = () => window.L ? resolve(window.L) : reject(Error('Map library did not load'));
    script.onerror = () => reject(Error('Map library blocked. Check your internet.'));
    document.head.appendChild(script);
  }).catch(err => {leafletPromise=undefined; throw err;});
  return leafletPromise;
}

const pickupMarkerHtml = '<div style="height:20px;width:20px;background:#e04743;border:3px solid white;border-radius:50%;box-shadow:0 2px 8px #0006;"></div>';
const storeMarkerHtml = '<div style="height:18px;width:18px;background:#058652;border:3px solid white;border-radius:50%;box-shadow:0 2px 8px #0006;"></div>';

export default function DeliveryPinMap({pin, onPick, routeCoordinates=[],storeLocation=null}) {
  const container = useRef(null);
  const mapRef = useRef(null);
  const pinMarkerRef = useRef(null);
  const routeRef = useRef(null);
  const storeMarkerRef=useRef(null);
  const pickRef = useRef(onPick);
  const [error,setError] = useState('');
  pickRef.current=onPick;

  useEffect(() => {
    let disposed = false;
    loadLeaflet().then(L => {
      if(disposed || !container.current)return;
      const store=storeLocation||{latitude:STORE.latitude,longitude:STORE.longitude};
      const map = L.map(container.current, {zoomControl:true,scrollWheelZoom:false})
        .setView([store.latitude, store.longitude], 15);
      mapRef.current=map;
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom:19,
        attribution:'© OpenStreetMap contributors'
      }).addTo(map);
      storeMarkerRef.current=L.marker([store.latitude, store.longitude], {interactive:false,
        icon:L.divIcon({className:'',html:storeMarkerHtml,iconSize:[24,24],iconAnchor:[12,12]})
      }).addTo(map).bindPopup('FYI KANTO store');
      map.on('click', e => {
        pickRef.current?.({latitude:e.latlng.lat, longitude:e.latlng.lng});
      });
      if(pin && Number.isFinite(pin.latitude) && Number.isFinite(pin.longitude)){
        pinMarkerRef.current = L.marker([pin.latitude, pin.longitude], {
          draggable:true,
          icon:L.divIcon({className:'',html:pickupMarkerHtml,iconSize:[26,26],iconAnchor:[13,13]})
        }).addTo(map);
        pinMarkerRef.current.on('dragend',e=>{
          const coords=e.target.getLatLng();
          pickRef.current?.({latitude:coords.lat,longitude:coords.lng});
        });
      }
      // Let the flex layout settle before Leaflet measures its width.
      requestAnimationFrame(() => {if(!disposed)map.invalidateSize();});
    }).catch(e=>{if(!disposed)setError(e.message||'Map is not available.');});
    return () => {
      disposed=true;
      if(mapRef.current){mapRef.current.remove(); mapRef.current=null;}
      pinMarkerRef.current=null;routeRef.current=null;storeMarkerRef.current=null;
    };
  },[]);

  useEffect(()=>{
    const map=mapRef.current;
    const L=typeof window!=='undefined'?window.L:null;
    if(!L||!map||!storeLocation||!Number.isFinite(storeLocation.latitude)||!Number.isFinite(storeLocation.longitude))return;
    if(storeMarkerRef.current)map.removeLayer(storeMarkerRef.current);
    storeMarkerRef.current=L.marker([storeLocation.latitude,storeLocation.longitude],{interactive:false,
      icon:L.divIcon({className:'',html:storeMarkerHtml,iconSize:[24,24],iconAnchor:[12,12]})
    }).addTo(map).bindPopup('FYI KANTO store');
    map.setView([storeLocation.latitude,storeLocation.longitude],15);
  },[storeLocation?.latitude,storeLocation?.longitude]);

  useEffect(()=>{
    const L=typeof window!=='undefined'?window.L:null;
    const map=mapRef.current;
    if(!L||!map)return;
    if(!pin){if(pinMarkerRef.current){map.removeLayer(pinMarkerRef.current);pinMarkerRef.current=null;}return;}
    if(!pinMarkerRef.current){
      const marker=L.marker([pin.latitude,pin.longitude],{
        draggable:true,
        icon:L.divIcon({className:'',html:pickupMarkerHtml,iconSize:[26,26],iconAnchor:[13,13]})
      }).addTo(map);
      marker.on('dragend',e=>{const pos=e.target.getLatLng();pickRef.current?.({latitude:pos.lat,longitude:pos.lng});});
      pinMarkerRef.current=marker;
    }else pinMarkerRef.current.setLatLng([pin.latitude,pin.longitude]);
  },[pin?.latitude,pin?.longitude]);

  useEffect(()=>{
    const L=typeof window!=='undefined'?window.L:null;
    const map=mapRef.current;
    if(!L||!map)return;
    if(routeRef.current){map.removeLayer(routeRef.current);routeRef.current=null;}
    if(routeCoordinates.length>1){
      routeRef.current=L.polyline(routeCoordinates.map(pt=>[pt.latitude,pt.longitude]),
        {color:'#138957',weight:4,opacity:0.9}).addTo(map);
      map.fitBounds(routeRef.current.getBounds().pad(0.16),{maxZoom:16});
    }
  },[routeCoordinates]);

  return <View style={{flex:1,minHeight:280,backgroundColor:'#e7f5ef',overflow:'hidden'}}>
    <View ref={container} style={{flex:1,width:'100%',minHeight:280}} />
    {error ? <View style={{position:'absolute',left:10,right:10,bottom:8,
      backgroundColor:'#fff7e5',padding:12,borderRadius:8}}>
      <Text style={{color:C.forest,fontSize:12}}>{error} Refresh after connecting to the internet.</Text>
    </View>:null}
  </View>;
}
