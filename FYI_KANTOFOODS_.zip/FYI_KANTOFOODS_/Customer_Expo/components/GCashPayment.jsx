import React, {useState} from 'react';
import {Alert, Image, Pressable, StyleSheet, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import {Card, FormField, Txt} from './UI';
import {C, money} from '../constants/theme';

// Supplied by FYI-KANTO. Keep this image uncropped: cropping the QR can make it unreadable.
const GCASH_QR = require('../assets/payments/gcash-qr-closeup.png');
const GCASH_FULL = require('../assets/payments/gcash-qr.jpg');

export default function GCashPayment({amount, proof, onSetProof, reference, onSetReference, readOnly=false}) {
  const [choosing,setChoosing]=useState(false);
  const [showFull,setShowFull]=useState(false);
  const pickProof=async()=>{
    if(choosing||readOnly)return;
    setChoosing(true);
    try {
      // Uses the phone's system photo picker; selecting an image isn't a real upload.
      const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:false,quality:0.55,base64:true,selectionLimit:1});
      if(!result.canceled && result.assets?.[0]) {
        const image=result.assets[0];
        // File upload limits will need enforcing again on your server when you add a backend.
        if(image.fileSize && image.fileSize>2.5*1024*1024){
          Alert.alert('Image too large','Please choose a screenshot smaller than 2.5 MB.');
          return;
        }
        onSetProof({uri:image.uri,name:image.fileName||'GCash payment screenshot',mimeType:image.mimeType||'image/jpeg',base64:image.base64||null});
      }
    } catch(err){Alert.alert('Unable to select photo','Please try another image or check your photo permissions.');}
    finally {setChoosing(false);}
  };

  return <Card style={styles.container}>
    <View style={styles.titleRow}>
      <View style={styles.walletIcon}><Ionicons name="wallet-outline" size={24} color={C.white}/></View>
      <View style={{flex:1}}><Txt style={styles.title}>Pay through GCash</Txt><Txt style={styles.subtitle}>Delivery requires GCash prepayment</Txt></View>
    </View>
    <View style={styles.amountBox}><Txt style={styles.amountLabel}>Order total to pay</Txt><Txt style={styles.amount}>{money(amount)}</Txt></View>
    <Txt style={styles.instructions}>1. Scan the official FYI-KANTO GCash QR below using your GCash app or another device.</Txt>
    <View style={styles.qrWrap}><Image source={GCASH_QR} style={styles.qr} resizeMode="contain" accessibilityLabel="GCash payment QR supplied by the store" /></View>
    <Pressable accessibilityRole="button" onPress={()=>setShowFull(v=>!v)} style={styles.fullToggle}><Ionicons name={showFull?'chevron-up':'eye-outline'} size={17} color={C.green}/><Txt style={{fontSize:12,fontWeight:'800',color:C.green}}>{showFull?'Hide full GCash image':'View original GCash QR and recipient details'}</Txt></Pressable>
    {showFull?<Image source={GCASH_FULL} resizeMode="contain" style={styles.fullImage}/>:null}
    <Txt style={styles.instructions}>2. Check the recipient details and amount carefully in GCash before approving your transfer.</Txt>
    <Txt style={styles.instructions}>3. After paying, choose your transaction screenshot as payment proof.</Txt>
    {!readOnly && <>
      <FormField label="GCash Reference Number (optional)" placeholder="Paste the transaction reference" value={reference} onChangeText={onSetReference} />
      <Pressable onPress={pickProof} disabled={choosing} style={[styles.upload,proof&&styles.uploaded]} accessibilityRole="button">
        <Ionicons name={proof?'checkmark-circle-outline':'cloud-upload-outline'} size={23} color={C.green}/>
        <View style={{flex:1}}><Txt style={{fontWeight:'900',color:C.green}}>{proof?'Change Payment Proof':'Attach Payment Proof *'}</Txt><Txt style={styles.helper}>{proof?'Screenshot selected':'Select a GCash receipt screenshot from your gallery'}</Txt></View>
        <Ionicons name="chevron-forward" size={18} color={C.green}/>
      </Pressable>
      {proof?.uri && <View style={styles.previewWrap}><Image source={{uri:proof.uri}} resizeMode="contain" style={styles.preview}/><Pressable style={styles.remove} onPress={()=>onSetProof(null)}><Ionicons name="trash-outline" size={16} color="#B43D3D"/><Txt style={{color:'#B43D3D',fontWeight:'700'}}>Remove proof</Txt></Pressable></View>}
    </>}
    <View style={styles.warning}><Ionicons name="shield-checkmark-outline" size={20} color="#946000"/><Txt style={{flex:1,color:'#705100',fontSize:12,lineHeight:19}}>A screenshot is not confirmation of payment. Your order will be marked <Txt style={{fontWeight:'900'}}>Pending Verification</Txt> until the store checks the payment in its GCash transaction history. Do not send money in this demo unless the store has officially launched payment collection.</Txt></View>
  </Card>;
}
const styles=StyleSheet.create({
  container:{marginTop:14,padding:15}, titleRow:{flexDirection:'row',alignItems:'center',gap:10,marginBottom:12},walletIcon:{width:44,height:44,backgroundColor:'#0066E0',borderRadius:13,alignItems:'center',justifyContent:'center'},title:{fontSize:17,fontWeight:'900',color:C.forest},subtitle:{color:C.muted,fontSize:11,marginTop:3},
  amountBox:{backgroundColor:'#EAF3FF',borderColor:'#C7DFFF',borderWidth:1,borderRadius:13,padding:14,alignItems:'center',marginBottom:14},amountLabel:{fontSize:12,color:'#254F8F',fontWeight:'700'},amount:{fontSize:26,color:'#0359CA',fontWeight:'900',marginTop:3},
  instructions:{color:C.forest,fontSize:12,lineHeight:19,marginTop:5,marginBottom:6},qrWrap:{backgroundColor:'#F7FAFF',borderRadius:13,borderWidth:1,borderColor:C.border,padding:8,alignItems:'center',overflow:'hidden',marginVertical:8},qr:{width:'100%',height:280},fullToggle:{flexDirection:'row',gap:7,alignItems:'center',justifyContent:'center',padding:10},fullImage:{height:465,width:'100%'},
  upload:{marginTop:10,padding:14,borderWidth:1.5,borderColor:C.green,borderStyle:'dashed',borderRadius:13,backgroundColor:C.paleMint,flexDirection:'row',alignItems:'center',gap:11},uploaded:{borderStyle:'solid'},helper:{fontSize:11,color:C.muted,marginTop:3},previewWrap:{alignItems:'center',marginTop:12},preview:{height:170,width:'100%',backgroundColor:'#F4F7F4',borderRadius:12},remove:{flexDirection:'row',alignItems:'center',gap:5,marginTop:8},warning:{flexDirection:'row',gap:9,backgroundColor:'#FFF6DE',padding:12,borderRadius:12,marginTop:14},
});
