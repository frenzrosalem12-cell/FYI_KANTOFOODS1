import React, {useEffect, useState} from 'react';
import {KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, TextInput, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Button, Logo, Page, Txt} from '../components/UI';
import {C} from '../constants/theme';
import {useCustomerAuth} from '../context/AuthContext';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ForgotPassword() {
  const {supabaseConfigured, requestPasswordReset, verifyPasswordResetCode,
    recoveryMode, updatePassword, signOut} = useCustomerAuth();

  const [step, setStep] = useState('email'); // email, verify, change, done
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [note, setNote] = useState('');
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setTimeout(() => setCooldown(value => Math.max(0, value - 1)), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);

  const sendCode = async (resend = false) => {
    setErrorText('');
    const normalizedEmail = email.trim().toLowerCase();
    if (!EMAIL_PATTERN.test(normalizedEmail)) {
      setErrorText('Enter your registered email address.');
      return;
    }
    if (!supabaseConfigured) {
      setErrorText('Supabase is not configured. Check Customer_Expo/.env.');
      return;
    }
    if (resend && cooldown > 0) return;
    setBusy(true);
    try {
      const result = await requestPasswordReset(normalizedEmail);
      setEmail(normalizedEmail);
      setNote(result?.message || 'If this email has an account, check your inbox for a code.');
      setCooldown(60);
      setCode(''); // New request can invalidate an earlier OTP.
      setStep('verify');
    } catch (error) {
      setErrorText(error?.message || 'Could not request a code. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const verifyCode = async () => {
    setErrorText('');
    if (!/^\d{6,10}$/.test(code)) {
      setErrorText('Enter the complete verification code from your email (6–10 digits).');
      return;
    }
    setBusy(true);
    try {
      await verifyPasswordResetCode(email, code);
      setCode('');
      setNote('');
      setStep('change');
    } catch (error) {
      setErrorText(error?.message || 'Incorrect or expired code.');
    } finally {
      setBusy(false);
    }
  };

  const savePassword = async () => {
    setErrorText('');
    if (!recoveryMode) {
      setErrorText('Please request a new code and verify it again.');
      return;
    }
    if (newPassword.length < 8) {
      setErrorText('Use a password with at least 8 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorText('Your new passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await updatePassword(newPassword);
      setNewPassword('');
      setConfirmPassword('');
      setStep('done');
    } catch (error) {
      setErrorText(error?.message || 'Unable to save the new password.');
    } finally {
      setBusy(false);
    }
  };

  const goBack = async () => {
    if (busy) return;
    // If an OTP created a short-lived session, end it before returning to login.
    if (recoveryMode) {
      try { await signOut(); }
      catch (error) {
        setErrorText(error?.message || 'Could not sign out. Please try again.');
        return;
      }
    }
    router.replace('/');
  };

  const heading = {
    email: 'Forgot your password?',
    verify: 'Verify your email',
    change: 'Create new password',
    done: 'Password updated!',
  }[step];

  return <Page>
    <KeyboardAvoidingView style={{flex: 1}} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.brand}>
          <Logo/>
          <View style={styles.badge}>
            <Ionicons name="shield-checkmark-outline" size={16} color={C.green}/>
            <Txt style={styles.badgeText}>Secure password recovery</Txt>
          </View>
        </View>
        <Txt style={styles.heading}>{heading}</Txt>

        {step === 'email' ? <>
          <Txt style={styles.description}>Enter the email used when you created your FYI-KANTO customer account.</Txt>
          <Field label="Registered email address" value={email} onChangeText={setEmail} placeholder="you@gmail.com"
            keyboardType="email-address" autoCapitalize="none" maxLength={254}/>
          <Button onPress={() => sendCode(false)} disabled={busy} style={styles.button} icon={busy ? null : 'arrow-forward'}>
            {busy ? 'Sending code…' : 'Send verification code'}
          </Button>
        </> : null}

        {step === 'verify' ? <>
          <Txt style={styles.description}>Check your Gmail inbox or Spam for the verification code sent to:</Txt>
          <Txt style={styles.emailLabel}>{email}</Txt>
          {note ? <View style={styles.tip}><Txt style={styles.tipText}>{note}</Txt></View> : null}
          <Field label="Verification code" value={code}
            onChangeText={value => setCode(value.replace(/\D/g, '').slice(0, 10))}
            placeholder="Enter email code" keyboardType="number-pad" maxLength={10}/>
          <Button onPress={verifyCode} disabled={busy} style={styles.button} icon={busy ? null : 'arrow-forward'}>
            {busy ? 'Verifying…' : 'Verify code'}
          </Button>
          <Pressable disabled={busy || cooldown > 0} onPress={() => sendCode(true)} style={styles.switch}>
            <Txt style={[styles.switchLink, cooldown > 0 && styles.muted]}>
              {cooldown > 0 ? `Resend code in ${cooldown}s` : 'Resend code'}
            </Txt>
          </Pressable>
          <Pressable disabled={busy} onPress={() => {setStep('email'); setNote(''); setErrorText('');}}
            style={styles.switch}><Txt style={styles.switchLink}>Use a different email</Txt></Pressable>
        </> : null}

        {step === 'change' ? <>
          <Txt style={styles.description}>Your code is verified. Choose a new password for this account.</Txt>
          <Field label="New password" value={newPassword} onChangeText={setNewPassword}
            secureTextEntry autoCapitalize="none" placeholder="At least 8 characters" maxLength={128}/>
          <Field label="Confirm new password" value={confirmPassword} onChangeText={setConfirmPassword}
            secureTextEntry autoCapitalize="none" placeholder="Re-enter new password" maxLength={128}/>
          <Button onPress={savePassword} disabled={busy} style={styles.button} icon={busy ? null : 'arrow-forward'}>
            {busy ? 'Saving password…' : 'Save new password'}
          </Button>
        </> : null}

        {step === 'done' ? <>
          <Txt style={styles.description}>Your password has been changed. You can log in using your existing email and your new password.</Txt>
          <Button onPress={goBack} style={styles.button} icon="arrow-forward">Back to login</Button>
        </> : null}

        {errorText ? <View style={styles.error}><Txt style={styles.errorText}>{errorText}</Txt></View> : null}
        {step !== 'done' ? <Pressable onPress={goBack} style={styles.switch} disabled={busy}>
          <Txt style={styles.switchLink}>Back to login</Txt>
        </Pressable> : null}
      </ScrollView>
    </KeyboardAvoidingView>
  </Page>;
}

function Field({label, value, onChangeText, placeholder, keyboardType = 'default',
  autoCapitalize = 'sentences', secureTextEntry = false, maxLength}) {
  return <View style={styles.field}>
    <Txt style={styles.label}>{label}</Txt>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#9AA79E"
      keyboardType={keyboardType} autoCapitalize={autoCapitalize} secureTextEntry={secureTextEntry}
      maxLength={maxLength} autoCorrect={false} style={styles.input}/>
  </View>;
}

const styles = StyleSheet.create({
  content: {paddingHorizontal: 24, paddingTop: 36, paddingBottom: 40},
  brand: {alignItems: 'center', marginBottom: 35},
  badge: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.mint,
    borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, marginTop: 16},
  badgeText: {fontSize: 12, color: C.green, fontWeight: '800'},
  heading: {fontSize: 27, fontWeight: '900', color: C.forest},
  description: {fontSize: 13, color: C.muted, lineHeight: 20, marginTop: 8, marginBottom: 22},
  field: {marginBottom: 16},
  label: {fontSize: 13, fontWeight: '800', marginBottom: 7},
  input: {backgroundColor: C.white, borderWidth: 1, borderColor: C.border,
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: C.ink},
  button: {marginTop: 6, minHeight: 52},
  switch: {alignItems: 'center', paddingVertical: 15},
  switchLink: {fontSize: 13, fontWeight: '900', color: C.green},
  muted: {color: C.muted},
  emailLabel: {fontSize: 13, fontWeight: '800', color: C.forest, marginBottom: 14},
  tip: {backgroundColor: C.mint, borderRadius: 11, padding: 12, marginBottom: 16},
  tipText: {fontSize: 12, lineHeight: 18, color: C.forest},
  error: {backgroundColor: '#FFF0F0', borderRadius: 11, padding: 12, marginTop: 14},
  errorText: {fontSize: 12, lineHeight: 18, color: C.forest},
});
