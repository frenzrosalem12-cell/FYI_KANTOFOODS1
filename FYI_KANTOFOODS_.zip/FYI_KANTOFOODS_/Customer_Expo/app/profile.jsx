import React, {useEffect, useState} from 'react';
import {ActivityIndicator, Alert, Image, Modal, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import {Button, FormField, Header, Page, Txt} from '../components/UI';
import {C} from '../constants/theme';
import {useCustomerAuth} from '../context/AuthContext';
import {useApp} from '../context/AppContext';

export default function Profile(){
  const {user,profile,profileLoading,profileError,updateProfile,signOut,supabase}=useCustomerAuth();
  const {resetDemo}=useApp();
  const [fullName,setFullName]=useState('');
  const [username,setUsername]=useState('');
  const [email,setEmail]=useState('');
  const [phone,setPhone]=useState('');
  const [address,setAddress]=useState('');
  const [avatarAsset,setAvatarAsset]=useState(null);
  const [avatarUrl,setAvatarUrl]=useState('');
  const [editing,setEditing]=useState(false);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');
  const [saved,setSaved]=useState('');
  const [confirmLogout,setConfirmLogout]=useState(false);
  const [loggingOut,setLoggingOut]=useState(false);

  useEffect(()=>{
    setFullName(profile?.full_name||profile?.username||'');
    setUsername(profile?.username||'');
    setEmail(user?.email||'');
    setPhone(profile?.phone||'');
    setAddress(profile?.address||'');
  },[profile,user?.email]);

  useEffect(()=>{
    let active=true;
    setAvatarUrl('');
    if(!profile?.avatar_path||!supabase)return ()=>{active=false;};
    supabase.storage.from('fyi-customer-photos')
      .createSignedUrl(profile.avatar_path,3600)
      .then(({data,error:signError})=>{
        if(!active)return;
        if(signError){
          console.warn('Unable to load customer profile picture:',signError.message);
          return;
        }
        setAvatarUrl(data?.signedUrl||'');
      }).catch(signError=>{
        if(active)console.warn('Unable to load customer profile picture:',signError.message);
      });
    return ()=>{active=false;};
  },[profile?.avatar_path,supabase]);

  const chooseAvatar=async()=>{
    setError('');setSaved('');
    try{
      const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();
      if(!permission.granted){
        setError('Allow photo library access to choose a profile picture.');
        return;
      }
      const result=await ImagePicker.launchImageLibraryAsync({
        mediaTypes:['images'],
        allowsEditing:true,
        aspect:[1,1],
        quality:.75,
        exif:false,
      });
      if(result.canceled)return;
      const asset=result.assets?.[0];
      if(!asset?.uri){
        setError('The selected image could not be opened.');
        return;
      }
      if(asset.fileSize>5*1024*1024){
        setError('Choose an image smaller than 5 MB.');
        return;
      }
      setAvatarAsset(asset);
    }catch(pickerError){
      setError(pickerError.message||'Unable to open your photo library.');
    }
  };

  const save=async()=>{
    setError('');setSaved('');
    if(!/^[a-z0-9._-]{3,30}$/i.test(username.trim())){
      setError('Username must be 3–30 letters, numbers, dots, underscores or hyphens.');
      return;
    }
    if(fullName.trim().length<2||fullName.trim().length>70){
      setError('Full name must be between 2 and 70 characters.');
      return;
    }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){
      setError('Enter a valid email address.');
      return;
    }
    if(!/^09\d{9}$/.test(phone)){
      setError('Enter an 11-digit Philippine phone number starting with 09.');
      return;
    }
    if(address.trim().length<5){
      setError('Enter your complete delivery address.');
      return;
    }
    setSaving(true);
    try{
      const result=await updateProfile({fullName,username,email,phone,address,avatarAsset});
      setAvatarAsset(null);
      setEditing(false);
      if(result.emailChangeError){
        setError(`Profile details saved, but the email change could not be requested: ${result.emailChangeError}`);
      }else{
        setSaved(result.emailChangeRequested
          ?'Profile saved. Check your email and confirm the address change to finish updating your account.'
          :'Your profile has been updated.');
      }
    }catch(saveError){
      setError(saveError.message||'Unable to save profile changes.');
    }finally{
      setSaving(false);
    }
  };

  const cancelEdit=()=>{
    setFullName(profile?.full_name||profile?.username||'');
    setUsername(profile?.username||'');
    setEmail(user?.email||'');
    setPhone(profile?.phone||'');
    setAddress(profile?.address||'');
    setAvatarAsset(null);
    setError('');
    setSaved('');
    setEditing(false);
  };

  const logout=async()=>{
    setLoggingOut(true);
    try{
      await signOut();
      resetDemo();
      setConfirmLogout(false);
      router.replace('/');
    }catch(logoutError){
      setError(logoutError.message||'Unable to log out. Please try again.');
      setConfirmLogout(false);
    }finally{
      setLoggingOut(false);
    }
  };

  return <Page>
    <Header title="My Profile" subtitle="Your customer account" onBack={()=>router.replace('/(tabs)/menu')}/>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
      <View style={styles.avatar}>
        {avatarAsset?.uri||avatarUrl
          ?<Image source={{uri:avatarAsset?.uri||avatarUrl}} style={styles.avatarImage} accessibilityLabel="Customer profile picture"/>
          :<Ionicons name="person" size={38} color={C.green}/>}
      </View>
      {editing?      <Button outline icon="camera-outline" onPress={chooseAvatar} style={styles.photoButton}>
        {avatarAsset?'Replace Selected Picture':'Change Profile Picture'}
      </Button>:null}
      {profileLoading?<ActivityIndicator color={C.green} style={{margin:16}}/>:null}
      {profileError?<Txt style={styles.error}>{profileError} Check your Supabase profile table and connection.</Txt>:null}
      <FormField required label="Full name" value={fullName} onChangeText={setFullName}
        placeholder="Your full name" maxLength={70} editable={editing}/>
      <FormField required label="Username" value={username} onChangeText={setUsername}
        placeholder="Your username" maxLength={30} autoCapitalize="none" editable={editing}/>
      <FormField required label="Email address" value={email} onChangeText={setEmail}
        placeholder="name@example.com" keyboardType="email-address" maxLength={254}
        autoCapitalize="none" editable={editing}/>
      {editing?<Txt style={styles.emailHint}>Changing your email may require confirmation from your inbox before it takes effect.</Txt>:null}
      <FormField required label="Contact number" value={phone}
        onChangeText={value=>setPhone(value.replace(/\D/g,'').slice(0,11))}
        placeholder="09XXXXXXXXX" keyboardType="phone-pad" maxLength={11} editable={editing}/>
      <FormField required label="Delivery address" value={address} onChangeText={setAddress}
        placeholder="House, street, barangay, municipality" multiline editable={editing}/>
      <View style={styles.created}>
        <Ionicons name="calendar-outline" size={19} color={C.green}/>
        <View><Txt style={styles.createdLabel}>Account created</Txt>
          <Txt style={styles.createdDate}>{user?.created_at?new Date(user.created_at).toLocaleDateString():'—'}</Txt>
        </View>
      </View>
      {error?<Txt style={styles.error}>{error}</Txt>:null}
      {saved?<Txt style={styles.saved}>{saved}</Txt>:null}
      {editing?<>
        <Button onPress={save} disabled={saving||profileLoading} style={{marginTop:8}} icon={saving?null:'checkmark-circle-outline'}>
          {saving?'Saving…':'SAVE CHANGES'}
        </Button>
        <Button secondary onPress={cancelEdit} disabled={saving} style={{marginTop:10}} icon="close-outline">Cancel editing</Button>
      </>:<Button onPress={()=>{setEditing(true);setError('');setSaved('');}} style={{marginTop:8}} icon="create-outline">
        EDIT PROFILE
      </Button>}
      <Button onPress={()=>setConfirmLogout(true)} style={styles.logout}
        textStyle={{color:C.white}} icon="log-out-outline">Log Out</Button>
    </ScrollView>
    <Modal transparent animationType="fade" visible={confirmLogout} onRequestClose={()=>setConfirmLogout(false)}>
      <View style={styles.scrim}><View style={styles.dialog}>
        <View style={styles.dialogIcon}><Ionicons name="log-out-outline" size={25} color={C.red}/></View>
        <Txt style={styles.dialogTitle}>Log Out?</Txt>
        <Txt style={styles.dialogBody}>Are you sure you want to log out of your FYI-KANTO account?</Txt>
        <View style={styles.dialogActions}>
          <Pressable onPress={()=>setConfirmLogout(false)} disabled={loggingOut} style={styles.cancel}>
            <Txt style={styles.cancelText}>CANCEL</Txt>
          </Pressable>
          <Pressable onPress={logout} disabled={loggingOut} style={styles.confirm}>
            <Txt style={styles.confirmText}>{loggingOut?'Logging out…':'YES, LOG OUT'}</Txt>
          </Pressable>
        </View>
      </View></View>
    </Modal>
  </Page>;
}

const styles=StyleSheet.create({
  content:{paddingHorizontal:20,paddingTop:12,paddingBottom:35},
  avatar:{height:96,width:96,borderRadius:50,alignSelf:'center',alignItems:'center',justifyContent:'center',backgroundColor:C.mint,marginBottom:12,overflow:'hidden'},
  avatarImage:{height:'100%',width:'100%'},
  photoButton:{alignSelf:'center',marginBottom:20,minHeight:42},
  emailHint:{fontSize:11,color:C.muted,lineHeight:17,marginTop:-8,marginBottom:12},
  created:{flexDirection:'row',alignItems:'center',gap:11,backgroundColor:C.paleMint,padding:14,borderRadius:12,marginBottom:16},
  createdLabel:{fontSize:11,color:C.muted,fontWeight:'700'},
  createdDate:{fontSize:14,color:C.forest,fontWeight:'900',marginTop:2},
  error:{color:'#A63B3B',backgroundColor:'#FFF0F0',padding:11,borderRadius:10,marginBottom:12,fontSize:12},
  saved:{color:C.green,backgroundColor:C.mint,padding:11,borderRadius:10,marginBottom:12,fontSize:12,fontWeight:'700'},
  logout:{marginTop:14,backgroundColor:C.red},
  scrim:{flex:1,backgroundColor:'rgba(11,42,32,.48)',alignItems:'center',justifyContent:'center',padding:24},
  dialog:{width:'100%',maxWidth:360,backgroundColor:C.white,borderRadius:20,padding:23,alignItems:'center'},
  dialogIcon:{width:52,height:52,borderRadius:27,backgroundColor:'#FFF0F0',alignItems:'center',justifyContent:'center',marginBottom:12},
  dialogTitle:{fontSize:20,fontWeight:'900',color:C.forest},
  dialogBody:{fontSize:13,lineHeight:19,color:C.muted,textAlign:'center',marginTop:7},
  dialogActions:{flexDirection:'row',gap:10,width:'100%',marginTop:22},
  cancel:{flex:1,alignItems:'center',justifyContent:'center',minHeight:45,backgroundColor:C.paleMint,borderRadius:11},
  cancelText:{fontSize:12,color:C.forest,fontWeight:'800'},
  confirm:{flex:1,alignItems:'center',justifyContent:'center',minHeight:45,backgroundColor:C.red,borderRadius:11},
  confirmText:{fontSize:12,color:C.white,fontWeight:'900'},
});
