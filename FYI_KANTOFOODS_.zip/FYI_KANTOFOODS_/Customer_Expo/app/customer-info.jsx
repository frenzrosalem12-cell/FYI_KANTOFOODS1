import React, {useState} from 'react';
import {KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, FormField, Txt, ClosedNotice} from '../components/UI';
import {C, money} from '../constants/theme';
import {useApp} from '../context/AppContext';
import {useCustomerAuth} from '../context/AuthContext';
import {CONNECTED_MODE} from '../config/backend';

export default function CustomerInfo(){
  const {customer,setCustomer,cart,storeStatus,deliveryFee,deliveryLocation,hasDeliveryRoute}=useApp();
  const {profile,profileLoading,profileError}=useCustomerAuth();
  const [error,setError]=useState('');
  const update=(field,value)=>{setError('');setCustomer(previous=>({...previous,[field]:value}));};
  const proceed=()=>{
    if(!storeStatus.isOpen)return setError('Ordering is paused until the store opens.');
    if(!cart.length)return setError('Please add menu items first.');
    if(!profile)return setError('Your saved customer profile is unavailable. Please return to your account and try again.');
    if(!(profile.username||profile.full_name)?.trim())return setError('Please add a username to your customer profile.');
    if(!/^09\d{9}$/.test(profile.phone||''))return setError('Add a valid 11-digit Philippine phone number to your profile.');
    if((profile.address||'').trim().length<5)return setError('Add a complete delivery address to your profile.');
    if(!hasDeliveryRoute)return setError('Please select and confirm your delivery pin to calculate the road distance and fee.');
    setError('');
    router.push('/order-summary');
  };
  return <Page>
    <Header title="Delivery details" subtitle="Where should we bring your order?" onBack={()=>router.back()}/>
    <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1}}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:18,paddingBottom:32}} showsVerticalScrollIndicator={false}>
        <ClosedNotice/>
        <View style={styles.deliveryBanner}>
          <Ionicons name="bicycle" color={C.green} size={25}/>
          <View style={{flex:1}}>
            <Txt style={{fontWeight:'900'}}>Delivery order</Txt>
            <Txt style={{color:C.muted,fontSize:12,marginTop:4}}>Delivery only · No cash on delivery</Txt>
          </View>
        </View>
        <Txt style={styles.title}>Saved account details</Txt>
        {profileLoading?<Txt style={styles.profileNotice}>Loading your saved account details…</Txt>:null}
        {profileError?<Txt style={styles.error}>Could not load your account details: {profileError}</Txt>:null}
        <ReadOnlyDetail label="Username" value={profile?.username||profile?.full_name||''}/>
        <ReadOnlyDetail label="Phone number" value={profile?.phone||''}/>
        <ReadOnlyDetail label="Complete delivery address" value={profile?.address||''} multiline/>
        <Txt style={styles.profileNotice}>These details come from your account and cannot be changed during checkout. Update your profile separately if needed.</Txt>
        <Pressable onPress={()=>router.push('/delivery-map')} style={styles.mapAction}>
          <Ionicons name="map-outline" color={C.green} size={24}/>
          <View style={{flex:1}}>
            <Txt style={{fontWeight:'900',color:C.forest}}>{hasDeliveryRoute?'Change delivery map pin':'Pin your delivery location *'}</Txt>
            <Txt style={{color:C.muted,fontSize:11,marginTop:4}}>{hasDeliveryRoute?`${deliveryLocation.distanceKm.toFixed(2)} km by road · Fee ${money(deliveryFee)}`:'Choose a drop-off point to calculate your delivery fee'}</Txt>
          </View>
          <Ionicons name="chevron-forward" color={C.green} size={20}/>
        </Pressable>
        <FormField label="Landmark (optional)" value={customer.landmark} onChangeText={value=>update('landmark',value)} placeholder="Near the barangay hall..."/>
        <FormField label="Order notes (optional)" multiline value={customer.notes} onChangeText={value=>update('notes',value)} placeholder="No onions, less ice, special requests..."/>
        <Txt style={[styles.title,{marginTop:8}]}>Secure payment</Txt>
        <View style={styles.paymentCard}>
          <Ionicons name="shield-checkmark" size={24} color={C.green}/>
          <View style={{flex:1}}>
            <Txt style={{fontWeight:'900',color:C.forest}}>GCash payment by PayMongo</Txt>
            <Txt style={{fontSize:12,color:C.muted,marginTop:5,lineHeight:18}}>After reviewing your order, you will securely authorize GCash through PayMongo. Your order is sent to staff after the server verifies payment.</Txt>
          </View>
        </View>
        {!hasDeliveryRoute?<View style={styles.routeNotice}><Ionicons name="information-circle-outline" color="#936A1A" size={22}/><Txt style={{fontSize:12,color:'#795D2F',flex:1}}>Pin your delivery location first. The server calculates the road distance and confirms the fee.</Txt></View>:null}
        {error?<Txt style={styles.error}>{error}</Txt>:null}
        <Button disabled={!storeStatus.isOpen||!hasDeliveryRoute||profileLoading||!profile} onPress={proceed} style={{marginTop:22}}>Review delivery order</Button>
        <Txt style={styles.note}>{CONNECTED_MODE?'Your delivery route, price and payment are processed by the shared backend for customer and staff.':'Connect the customer app to the server before placing an order.'}</Txt>
      </ScrollView>
    </KeyboardAvoidingView>
  </Page>;
}

function ReadOnlyDetail({label,value,multiline=false}){
  return <View style={styles.readOnlyField}>
    <Txt style={styles.readOnlyLabel}>{label}</Txt>
    <View style={[styles.readOnlyValue,multiline&&{minHeight:70,alignItems:'flex-start',paddingTop:13}]}>
      <Txt style={{color:value?C.ink:C.muted}}>{value||'Not set in your profile'}</Txt>
    </View>
  </View>;
}

const styles=StyleSheet.create({
  title:{fontWeight:'900',fontSize:17,marginBottom:14},
  deliveryBanner:{backgroundColor:C.mint,padding:15,borderRadius:15,flexDirection:'row',gap:12,alignItems:'center',marginBottom:18},
  mapAction:{flexDirection:'row',alignItems:'center',gap:11,backgroundColor:C.white,borderWidth:1.5,borderColor:C.green,padding:14,borderRadius:14,marginBottom:15},
  readOnlyField:{marginBottom:15},
  readOnlyLabel:{fontSize:13,fontWeight:'800',marginBottom:7},
  readOnlyValue:{minHeight:48,backgroundColor:C.paleMint,borderWidth:1,borderColor:C.border,borderRadius:12,paddingHorizontal:13,flexDirection:'row',alignItems:'center'},
  profileNotice:{fontSize:11,lineHeight:17,color:C.muted,marginBottom:14},
  paymentCard:{padding:14,borderRadius:13,backgroundColor:C.paleMint,borderWidth:1.5,borderColor:C.green,flexDirection:'row',alignItems:'center',gap:11},
  routeNotice:{flexDirection:'row',gap:9,padding:13,marginTop:14,borderRadius:12,backgroundColor:'#FFF6DE'},
  error:{color:'#A63B3B',backgroundColor:'#FFF0F0',padding:11,borderRadius:10,marginTop:16,fontSize:12,fontWeight:'700'},
  note:{color:C.muted,textAlign:'center',fontSize:11,marginTop:14}
});
