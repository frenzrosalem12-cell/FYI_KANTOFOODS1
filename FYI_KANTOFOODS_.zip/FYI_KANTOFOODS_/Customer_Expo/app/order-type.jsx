import React, {useState} from 'react';
import {Alert, Modal, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, Card, Txt, Photo, SummaryLine, ClosedNotice} from '../components/UI';
import {C, money} from '../constants/theme';
import {useApp,cartItemTotal} from '../context/AppContext';
import {getProduct} from '../data/products';
export default function OrderType(){
 const {cart,subtotal,deliveryFee,total,deliveryLocation,changeQuantity,removeFromCart,storeStatus}=useApp();
 const [itemToRemove,setItemToRemove]=useState(null);
 const deleteItem=()=>{
  if(!itemToRemove)return;
  const name=getProduct(itemToRemove.productId)?.name||'This item';
  removeFromCart(itemToRemove.key);
  setItemToRemove(null);
  Alert.alert('Item removed',`${name} has been removed from your order.`);
 };
 return <Page><Header title="Your Order" subtitle="Delivery checkout" onBack={()=>router.back()}/>
 <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingHorizontal:18,paddingBottom:35}}>
  <ClosedNotice/>
  <Txt style={styles.heading}>Delivery to your door</Txt>
  <View style={[styles.choice,styles.chosen]}><View style={[styles.choiceIcon,{backgroundColor:C.mint}]}><Ionicons name="bicycle-outline" size={26} color={C.green}/></View><View style={{flex:1}}><Txt style={{fontSize:15,fontWeight:'900'}}>Delivery only</Txt><Txt style={{color:C.muted,fontSize:12,marginTop:4}}>Secure GCash checkout powered by PayMongo</Txt></View><Ionicons name="checkmark-circle" size={23} color={C.green}/></View>
  <View style={styles.headingRow}><Txt style={{fontSize:17,fontWeight:'900'}}>Your items</Txt><Pressable onPress={()=>router.push('/(tabs)/menu')}><Txt style={{fontSize:12,color:C.green,fontWeight:'900'}}>+ Add more</Txt></Pressable></View>
  {cart.length===0?<Card><Txt style={{color:C.muted,textAlign:'center'}}>Your order is empty. Browse our menu to add something delicious.</Txt></Card>:cart.map(item=>{const p=getProduct(item.productId);if(!p)return null;return <Card key={item.key} style={styles.item}>
   <View style={styles.itemTop}>
    <View style={styles.itemPhoto}><Photo productId={p.id} image={p.image} category={p.category}/></View>
    <View style={{flex:1}}>
     <Txt style={{fontWeight:'900',fontSize:15}} numberOfLines={2}>{p.name}</Txt>
     <Txt style={{fontSize:12,color:C.muted,marginTop:4}}>{item.size}{item.variant?' · '+item.variant:''}{item.addOnIds?.length?' · '+item.addOnIds.join(', '):''}</Txt>
     <Txt style={styles.unitPrice}>Price: {money(cartItemTotal(item)/item.qty)} each</Txt>
    </View>
   </View>
   <Pressable accessibilityRole="button" onPress={()=>setItemToRemove(item)} style={styles.deleteButton}>
    <Ionicons name="trash-outline" size={20} color={C.white}/>
    <Txt style={styles.deleteText}>Delete</Txt>
   </Pressable>
   <View style={styles.quantityRow}>
    <Txt style={{fontWeight:'800',color:C.forest}}>Quantity</Txt>
    <View style={styles.quantityControls}>
     <Pressable accessibilityLabel={`Decrease ${p.name} quantity`} onPress={()=>changeQuantity(item.key,-1)} style={styles.quantityButton}>
      <Ionicons name="remove" color={C.forest} size={22}/>
     </Pressable>
     <Txt style={styles.quantity}>{item.qty}</Txt>
     <Pressable accessibilityLabel={`Increase ${p.name} quantity`} onPress={()=>changeQuantity(item.key,1)} style={[styles.quantityButton,{backgroundColor:C.green,borderColor:C.green}]}>
      <Ionicons name="add" color={C.white} size={22}/>
     </Pressable>
    </View>
   </View>
   <View style={styles.subtotalRow}><Txt style={styles.subtotalLabel}>Subtotal</Txt><Txt style={styles.subtotalValue}>{money(cartItemTotal(item))}</Txt></View>
  </Card>})}
  <Card style={{marginTop:17}}><SummaryLine label="Subtotal" value={money(subtotal)}/><SummaryLine label="Estimated delivery fee" value={deliveryFee===null?'Pin location to calculate':money(deliveryFee)}/><SummaryLine label="Estimated total" value={total===null?'Select a map pin':money(total)} bold/><Txt style={{fontSize:11,color:C.muted,marginTop:5}}>Below 1 km FREE • 1–1.99 km ₱15 • +₱10 per additional full km. Choose a road-route pin on the next screen.</Txt></Card>
  <Button style={{marginTop:20}} disabled={!cart.length||!storeStatus.isOpen} onPress={()=>router.push('/customer-info')}>Continue to Your Information</Button>
 </ScrollView>
 <Modal transparent animationType="fade" visible={Boolean(itemToRemove)} onRequestClose={()=>setItemToRemove(null)}>
  <View style={styles.scrim}><View style={styles.dialog}>
   <View style={styles.dialogIcon}><Ionicons name="trash-outline" size={25} color={C.red}/></View>
   <Txt style={styles.dialogTitle}>Remove This Item?</Txt>
   <Txt style={styles.dialogBody}>Are you sure you want to remove {getProduct(itemToRemove?.productId)?.name||'this item'} from your order?</Txt>
   <View style={styles.dialogActions}>
    <Pressable onPress={()=>setItemToRemove(null)} style={styles.cancel}><Txt style={styles.cancelText}>CANCEL</Txt></Pressable>
    <Pressable onPress={deleteItem} style={styles.confirm}><Ionicons name="trash-outline" size={17} color={C.white}/><Txt style={styles.confirmText}>YES, DELETE</Txt></Pressable>
   </View>
  </View></View>
 </Modal>
 </Page>;
}
const styles=StyleSheet.create({
 heading:{fontSize:20,fontWeight:'900',lineHeight:25,maxWidth:285,marginBottom:18,marginTop:10},
 choice:{flexDirection:'row',alignItems:'center',gap:14,borderColor:C.border,borderWidth:1.5,borderRadius:16,backgroundColor:C.white,padding:15},
 chosen:{borderColor:C.green,backgroundColor:C.paleMint},
 choiceIcon:{width:50,height:50,backgroundColor:'#F3F6F2',borderRadius:13,alignItems:'center',justifyContent:'center'},
 headingRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:28,marginBottom:12},
 item:{marginBottom:12,padding:13},
 itemTop:{flexDirection:'row',alignItems:'center',gap:13},
 itemPhoto:{height:94,width:94,overflow:'hidden',borderRadius:14,backgroundColor:C.mint},
 unitPrice:{fontSize:12,color:C.green,fontWeight:'800',marginTop:8},
 deleteButton:{height:47,borderRadius:12,marginTop:14,backgroundColor:C.red,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8},
 deleteText:{fontSize:14,color:C.white,fontWeight:'900',textTransform:'uppercase'},
 quantityRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginTop:14},
 quantityControls:{flexDirection:'row',alignItems:'center',gap:14},
 quantityButton:{width:46,height:46,borderRadius:12,backgroundColor:C.white,borderWidth:1.5,borderColor:C.border,alignItems:'center',justifyContent:'center'},
 quantity:{minWidth:28,textAlign:'center',fontSize:17,fontWeight:'900',color:C.forest},
 subtotalRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderTopWidth:1,borderTopColor:C.border,marginTop:13,paddingTop:12},
 subtotalLabel:{fontSize:13,color:C.muted,fontWeight:'800'},
 subtotalValue:{fontSize:17,color:C.green,fontWeight:'900'},
 scrim:{flex:1,backgroundColor:'rgba(11,42,32,.48)',alignItems:'center',justifyContent:'center',padding:24},
 dialog:{width:'100%',maxWidth:360,backgroundColor:C.white,borderRadius:20,padding:23,alignItems:'center'},
 dialogIcon:{width:52,height:52,borderRadius:27,backgroundColor:'#FFF0F0',alignItems:'center',justifyContent:'center',marginBottom:12},
 dialogTitle:{fontSize:20,fontWeight:'900',color:C.forest},
 dialogBody:{fontSize:13,lineHeight:19,color:C.muted,textAlign:'center',marginTop:7},
 dialogActions:{flexDirection:'row',gap:10,width:'100%',marginTop:22},
 cancel:{flex:1,alignItems:'center',justifyContent:'center',minHeight:45,backgroundColor:C.paleMint,borderRadius:11},
 cancelText:{fontSize:12,color:C.forest,fontWeight:'800'},
 confirm:{flex:1,flexDirection:'row',gap:6,alignItems:'center',justifyContent:'center',minHeight:45,backgroundColor:C.red,borderRadius:11},
 confirmText:{fontSize:12,color:C.white,fontWeight:'900'},
});
