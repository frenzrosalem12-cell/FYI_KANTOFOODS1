import React, {useMemo, useRef, useState} from 'react';
import {
  Alert, Animated, FlatList, Image, Pressable, ScrollView,
  StyleSheet, TextInput, View, Platform, useWindowDimensions,
} from 'react-native';
import {router} from 'expo-router';
import {StatusBar} from 'expo-status-bar';
import {Ionicons} from '@expo/vector-icons';
import {Page, Txt, Chip, ProductCard, Photo, ClosedNotice} from '../../components/UI';
import {C, money} from '../../constants/theme';
import {CATEGORIES, PRODUCTS, getCategory, getProduct} from '../../data/products';
import {photos} from '../../data/images';
import {useApp} from '../../context/AppContext';

const PINNED_HEADER_HEIGHT=113;
const DRINKS_BANNER_RATIO=1880/837;
const nonAllCategories=CATEGORIES.filter(category=>category.id!=='all');

function chunks(items,size=2){
  const rows=[];
  for(let i=0;i<items.length;i+=size)rows.push(items.slice(i,i+size));
  return rows;
}

export default function Menu(){
  const [query,setQuery]=useState('');
  const {width}=useWindowDimensions();
  const {
    cartCount,subtotal,storeStatus,productCatalogVersion,favorites,
    productPopularity,toggleFavorite,
  }=useApp();
  const listRef=useRef(null);
  const scrollY=useRef(new Animated.Value(0)).current;
  const customerWidth=Platform.OS==='web'?Math.min(width,520):width;
  const bannerHeight=(customerWidth-34)/DRINKS_BANNER_RATIO;
  const cardWidth=Math.min(225,(customerWidth-44)/2);
  const search=query.trim().toLowerCase();
  const matchingProducts=useMemo(()=>PRODUCTS.filter(product=>
    !search||product.name.toLowerCase().includes(search)
  ),[search,productCatalogVersion]);
  const rows=useMemo(()=>{
    if(search)return chunks(matchingProducts).map((products,index)=>({
      key:`search-${index}`,type:'products',products
    }));
    return nonAllCategories.flatMap(category=>{
      const products=PRODUCTS.filter(product=>product.category===category.id);
      return products.length?[
        {key:`heading-${category.id}`,type:'heading',category,count:products.length},
        {key:`featured-${category.id}`,type:'products',products:products.slice(0,2)},
        {key:`more-${category.id}`,type:'more',category,count:products.length},
      ]:[];
    });
  },[search,matchingProducts,productCatalogVersion]);
  const popularityFor=id=>productPopularity.find(row=>row.productId===id)||{};
  const topOrdered=useMemo(()=>PRODUCTS.map(product=>({product,...popularityFor(product.id)}))
    .filter(row=>row.orderCount>0)
    .sort((a,b)=>b.orderCount-a.orderCount).slice(0,5),[productPopularity,productCatalogVersion]);
  const topFavorited=useMemo(()=>PRODUCTS.map(product=>({product,...popularityFor(product.id)}))
    .filter(row=>row.favoriteCount>0)
    .sort((a,b)=>b.favoriteCount-a.favoriteCount).slice(0,5),[productPopularity,productCatalogVersion]);
  const myFavorites=useMemo(()=>PRODUCTS.filter(product=>favorites.includes(product.id)).slice(0,5),
    [favorites,productCatalogVersion]);

  const goProduct=product=>{if(product)router.push(`/product/${product.id}`);};
  const goCategory=category=>router.push(`/category/${category.id}`);
  const toggleProductFavorite=product=>async()=>{
    try{await toggleFavorite(product.id);}
    catch(error){Alert.alert('Favorite not saved',error.message||'Please try again.');}
  };
  const renderHighlights=(title,icon,items,keyFor)=>{
    if(!items.length)return null;
    return <View style={styles.highlightSection}>
      <View style={styles.rowTitle}>
        <View style={styles.highlightTitle}><Ionicons name={icon} size={17} color={C.green}/><Txt style={styles.h2}>{title}</Txt></View>
        <Txt style={styles.smallGreen}>Swipe to explore →</Txt>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:10,paddingRight:18}}>
        {items.map(entry=>{
          const product=entry.product||entry;
          const stats=entry.product?entry:{};
          return <Pressable key={product.id} onPress={()=>goProduct(product)} style={styles.featured}>
            <View style={styles.featuredPhoto}><Photo productId={product.id} image={product.image} category={product.category}/></View>
            <View style={{justifyContent:'space-between',flex:1,minWidth:0}}>
              <Txt numberOfLines={2} style={{fontWeight:'800',fontSize:12}}>{product.name}</Txt>
              <View style={styles.featurePrice}><Txt style={{fontWeight:'900',color:C.green}}>{money(product.sizes[0].price)}</Txt><Txt style={styles.highlightCount}>{keyFor(stats)}</Txt></View>
            </View>
          </Pressable>;
        })}
      </ScrollView>
    </View>;
  };

  const menuIntro=<View>
    <View style={styles.bannerArea}>
      <Pressable accessibilityRole="button" accessibilityLabel="Discover the FYI drinks menu"
        onPress={()=>goProduct(getProduct('premium-matcha'))}
        style={[styles.bannerCard,{height:bannerHeight}]}>
        <Image source={photos.drinksCollage} resizeMode="contain" style={styles.drinksImage}/>
      </Pressable>
      <View style={styles.bannerCaption}>
        <View style={styles.newBadge}><Txt style={styles.newBadgeText}>FYI FAVORITES</Txt></View>
        <Txt style={styles.bannerHint}>Fresh sips, tasty bites — made for you</Txt>
      </View>
    </View>
    {!storeStatus.isOpen?<ClosedNotice/>:null}
    {!search?<>
      {renderHighlights('Your favorites','heart',myFavorites,()=> 'Saved')}
      {renderHighlights('Most favorited','heart-outline',topFavorited,row=>`${row.favoriteCount||0} likes`)}
      {renderHighlights('Most ordered','trending-up-outline',topOrdered,row=>`${row.orderCount||0} orders`)}
      <View style={styles.rowTitle}><Txt style={styles.h2}>Browse categories</Txt></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:7,paddingBottom:13,paddingRight:20}}>
        {nonAllCategories.map(category=><Chip key={category.id} text={category.label}
          active={false} onPress={()=>goCategory(category)}/>)}
      </ScrollView>
    </>:<View style={styles.rowTitle}><Txt style={styles.h2}>Search results</Txt><Txt style={{fontSize:12,color:C.muted}}>{matchingProducts.length} items</Txt></View>}
  </View>;

  const renderRow=({item})=>{
    if(item.type==='heading')return <View style={styles.categoryHeading}>
      <View style={{flex:1}}>
        <Txt style={styles.h2}>{item.category.label}</Txt>
        <Txt style={styles.categoryCount}>{item.count} menu items</Txt>
      </View>
      <Pressable accessibilityRole="button" onPress={()=>goCategory(item.category)} style={styles.viewMore}>
        <Txt style={styles.viewMoreText}>View More</Txt><Ionicons name="chevron-forward" size={15} color={C.green}/>
      </Pressable>
    </View>;
    if(item.type==='more')return <Pressable accessibilityRole="button"
      onPress={()=>goCategory(item.category)} style={styles.moreRow}>
      <Txt style={styles.viewMoreText}>View all {item.count} {item.category.label} items</Txt>
      <Ionicons name="arrow-forward" size={16} color={C.green}/>
    </Pressable>;
    return <View style={styles.productRow}>
      {item.products.map(product=>{
        const stats=popularityFor(product.id);
        return <ProductCard key={product.id} product={product} width={cardWidth}
          onPress={()=>goProduct(product)} onAdd={()=>goProduct(product)}
          isFavorite={favorites.includes(product.id)}
          onToggleFavorite={toggleProductFavorite(product)}
          favoriteCount={stats.favoriteCount||0} orderCount={stats.orderCount||0}/>;
      })}
      {item.products.length===1?<View style={{width:cardWidth}}/>:null}
    </View>;
  };

  return <Page edges={['top']} style={{backgroundColor:C.green}}>
    <StatusBar style="light" backgroundColor={C.green}/>
    <View style={{flex:1,backgroundColor:C.cream}}>
      <Animated.FlatList
        ref={listRef}
        data={rows}
        keyExtractor={item=>item.key}
        renderItem={renderRow}
        ListHeaderComponent={menuIntro}
        ListEmptyComponent={<View style={styles.empty}>
          <Txt style={{fontSize:44}}>🍃</Txt>
          <Txt style={{color:C.muted,textAlign:'center',marginTop:10}}>No matching items. Try another search.</Txt>
        </View>}
        onScroll={Animated.event([{nativeEvent:{contentOffset:{y:scrollY}}}],{
          useNativeDriver:Platform.OS!=='web',
        })}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingTop:PINNED_HEADER_HEIGHT+7,paddingHorizontal:16,paddingBottom:cartCount>0?125:30}}
      />
      <View style={styles.stickyHeader}>
        <View style={styles.brandRow}>
          <Image source={require('../../assets/fyi-original-logo.png')} resizeMode="contain" style={styles.logo}/>
          <View style={styles.brandName}>
            <View style={styles.openLine}>
              <View style={[styles.statusDot,{backgroundColor:storeStatus.isOpen?'#B9F8CC':'#FFC2C2'}]}/>
              <Txt style={styles.statusText}>{storeStatus.label}</Txt>
            </View>
            <Txt numberOfLines={1} adjustsFontSizeToFit style={styles.brandTagline}>FEED YOUR INTESTINE</Txt>
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel="Open customer profile"
            onPress={()=>router.push('/profile')} style={styles.profileButton}>
            <Ionicons name="person-circle-outline" size={31} color={C.white}/>
          </Pressable>
        </View>
        <View style={styles.searchBar}>
          <Ionicons name="search" color={C.green} size={20}/>
          <TextInput style={styles.searchInput} value={query} onChangeText={setQuery}
            placeholder="Search food, drinks & more..." placeholderTextColor="#879E91" returnKeyType="search"/>
          {query?<Pressable accessibilityLabel="Clear search" onPress={()=>setQuery('')}>
            <Ionicons name="close-circle" color={C.muted} size={19}/>
          </Pressable>:null}
        </View>
      </View>
      {cartCount>0?<Pressable
        onPress={()=>storeStatus.isOpen?router.push('/order-type'):Alert.alert('Closed Now','Sorry, FYI-KANTO is closed. Ordering resumes during business hours.')}
        style={[styles.floating,!storeStatus.isOpen&&{backgroundColor:'#8B958D'}]}>
        <View style={styles.count}><Txt style={{fontWeight:'900',color:C.green}}>{cartCount}</Txt></View>
        <Txt style={{fontWeight:'900',color:C.white,fontSize:15,flex:1}}>
          {storeStatus.isOpen?`Place Order • ${money(subtotal)}`:'Closed — Ordering Paused'}
        </Txt>
        <Ionicons name="arrow-forward" size={22} color={C.white}/>
      </Pressable>:null}
    </View>
  </Page>;
}

const styles=StyleSheet.create({
  stickyHeader:{position:'absolute',top:0,left:0,right:0,height:PINNED_HEADER_HEIGHT,backgroundColor:C.green,paddingHorizontal:16,zIndex:30,elevation:10,borderBottomLeftRadius:25,borderBottomRightRadius:25},
  brandRow:{height:62,flexDirection:'row',alignItems:'center',gap:9},
  logo:{height:43,width:65},
  brandName:{flex:1,justifyContent:'center',gap:3},
  profileButton:{width:39,height:39,alignItems:'center',justifyContent:'center'},
  openLine:{flexDirection:'row',alignItems:'center',gap:6},
  statusDot:{width:8,height:8,borderRadius:5},
  statusText:{fontSize:12,color:C.white,fontWeight:'700'},
  brandTagline:{fontSize:15,fontWeight:'900',color:C.white,letterSpacing:-.3},
  searchBar:{height:41,borderRadius:12,backgroundColor:C.white,flexDirection:'row',alignItems:'center',gap:9,paddingHorizontal:13},
  searchInput:{flex:1,color:C.ink,fontSize:13,paddingVertical:0,minWidth:0},
  bannerArea:{paddingTop:7,paddingBottom:13},
  bannerCard:{backgroundColor:C.white,borderRadius:16,overflow:'hidden',borderWidth:1,borderColor:'#EDF0E9'},
  drinksImage:{height:'100%',width:'100%'},
  bannerCaption:{marginTop:10,flexDirection:'row',alignItems:'center',gap:9,justifyContent:'space-between'},
  newBadge:{paddingHorizontal:10,paddingVertical:5,backgroundColor:'#E3F5EA',borderRadius:8},
  newBadgeText:{fontWeight:'900',fontSize:9,color:C.green,letterSpacing:.4},
  bannerHint:{fontSize:10.5,color:C.muted,fontWeight:'600',flex:1},
  rowTitle:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:12,marginTop:8},
  h2:{color:C.forest,fontSize:17,fontWeight:'900'},
  smallGreen:{fontSize:12,color:C.green,fontWeight:'800'},
  highlightSection:{marginBottom:5},
  highlightTitle:{flexDirection:'row',alignItems:'center',gap:7},
  featured:{width:205,backgroundColor:C.white,borderRadius:15,borderWidth:1,borderColor:C.border,padding:8,flexDirection:'row',gap:9,marginBottom:12},
  featuredPhoto:{width:66,height:68,overflow:'hidden',borderRadius:12,backgroundColor:C.mint},
  featurePrice:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:4},
  highlightCount:{fontSize:9,color:C.muted,fontWeight:'700'},
  categoryHeading:{flexDirection:'row',alignItems:'center',marginTop:13,marginBottom:10},
  categoryCount:{fontSize:11,color:C.muted,marginTop:3},
  viewMore:{flexDirection:'row',alignItems:'center',gap:3,paddingHorizontal:10,paddingVertical:8,backgroundColor:C.paleMint,borderRadius:10},
  viewMoreText:{color:C.green,fontSize:12,fontWeight:'900'},
  productRow:{flexDirection:'row',justifyContent:'space-between',gap:10},
  moreRow:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:7,marginTop:0,marginBottom:8,padding:10},
  empty:{alignItems:'center',padding:35},
  floating:{position:'absolute',left:20,right:20,bottom:12,height:57,borderRadius:17,backgroundColor:C.green,paddingHorizontal:17,flexDirection:'row',alignItems:'center',gap:13,zIndex:35},
  count:{backgroundColor:C.white,borderRadius:10,width:32,height:32,justifyContent:'center',alignItems:'center'},
});
