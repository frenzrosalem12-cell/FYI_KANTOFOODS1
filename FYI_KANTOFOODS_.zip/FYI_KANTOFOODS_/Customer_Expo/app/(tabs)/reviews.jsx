import React, {useEffect, useState} from 'react';
import {Alert, Pressable, ScrollView, StyleSheet, TextInput, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, Card, Txt} from '../../components/UI';
import {C} from '../../constants/theme';
import {useApp} from '../../context/AppContext';
import {useCustomerAuth} from '../../context/AuthContext';
import {CONNECTED_MODE} from '../../config/backend';
import {DEMO_REVIEWS} from '../../data/demo';

export default function Reviews(){
 const {reviews,submitCustomerReview}=useApp();
 const {profile}=useCustomerAuth();
 const [name,setName]=useState('');
 const [productName,setProductName]=useState('');
 const [rating,setRating]=useState(5);
 const [message,setMessage]=useState('');
 const [submitting,setSubmitting]=useState(false);

 useEffect(()=>{
  if(profile&&!name.trim())setName(profile.username||profile.full_name||'');
 },[profile,name]);

 const submit=async()=>{
  if(name.trim().length<2)return Alert.alert('Add your name','Please enter a name with at least 2 characters.');
  if(message.trim().length<5)return Alert.alert('Write your review','Please write at least 5 characters.');
  setSubmitting(true);
  try{
   await submitCustomerReview({name,productName,rating,message});
   setMessage('');
   setProductName('');
   setRating(5);
   Alert.alert('Thank you!','Your review is now shared with other customers.');
  }catch(error){Alert.alert('Could not save review',error.message);}
  finally{setSubmitting(false);}
 };

 return <Page edges={['top']}><Header title="Customer Reviews" subtitle="Share your feedback with everyone"/>
 <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingHorizontal:18,paddingBottom:40}}>
  <Card style={{marginTop:5}}>
   <Txt style={{fontSize:17,fontWeight:'900'}}>Write a review</Txt>
   <Txt style={{fontSize:12,color:C.muted,marginTop:7,lineHeight:18}}>Anyone can share feedback. You do not need to place an order first.</Txt>
   <Txt style={styles.label}>Your name</Txt>
   <TextInput value={name} onChangeText={setName} placeholder="Name to show with your review" placeholderTextColor="#96A99C" maxLength={70} style={styles.textInput}/>
   <Txt style={styles.label}>Product (optional)</Txt>
   <TextInput value={productName} onChangeText={setProductName} placeholder="What are you reviewing?" placeholderTextColor="#96A99C" maxLength={100} style={styles.textInput}/>
   <Txt style={{fontSize:13,fontWeight:'900',marginTop:17,textAlign:'center'}}>Your rating</Txt>
   <View style={{flexDirection:'row',justifyContent:'center',gap:10,marginTop:10,marginBottom:15}}>
    {[1,2,3,4,5].map(value=><Pressable key={value} onPress={()=>setRating(value)} accessibilityLabel={`Rate ${value} stars`}>
     <Ionicons name={value<=rating?'star':'star-outline'} size={33} color={value<=rating?C.yellow:'#C8D0CB'}/>
    </Pressable>)}
   </View>
   <TextInput placeholder="Tell other customers what you think..." placeholderTextColor="#96A99C"
    multiline value={message} onChangeText={setMessage} style={styles.reviewInput} maxLength={500}/>
   <Txt style={{textAlign:'right',fontSize:11,color:C.muted,marginTop:5}}>{message.length}/500</Txt>
   <Button onPress={submit} disabled={submitting} style={{marginTop:14}}>{submitting?'Saving review…':'Share review'}</Button>
  </Card>
  <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:25,marginBottom:13}}>
   <Txt style={{fontSize:18,fontWeight:'900'}}>Customer feedback</Txt>
   <Txt style={{fontSize:11,color:C.muted}}>{reviews.length+(CONNECTED_MODE?0:DEMO_REVIEWS.length)} reviews</Txt>
  </View>
  {[...reviews,...(CONNECTED_MODE?[]:DEMO_REVIEWS)].map(review=><Card key={review.id} style={{marginBottom:12}}>
   <View style={{flexDirection:'row',gap:12,alignItems:'center'}}>
    <View style={styles.avatar}><Txt style={{color:C.white,fontWeight:'900'}}>{review.name?.[0]?.toUpperCase()||'F'}</Txt></View>
    <View style={{flex:1}}>
     <Txt style={{fontSize:13,fontWeight:'900'}}>{review.name}</Txt>
     <Txt style={{fontSize:10,color:C.muted,marginTop:2}}>{review.isDemo?'Sample review':new Date(review.date||review.at).toLocaleDateString('en-PH')}</Txt>
    </View>
    <View style={{flexDirection:'row',gap:1}}>{[1,2,3,4,5].map(value=><Ionicons key={value} name={value<=review.rating?'star':'star-outline'} size={12} color={C.yellow}/>)}</View>
   </View>
   {review.productName?<Txt style={styles.reviewProduct}>About: {review.productName}</Txt>:null}
   <Txt style={{fontSize:12,lineHeight:19,marginTop:12,color:C.ink}}>{review.message}</Txt>
  </Card>)}
  <View style={{padding:12,backgroundColor:C.mint,borderRadius:12,marginBottom:8}}>
   <Txt style={{color:C.green,textAlign:'center',fontSize:11}}>{CONNECTED_MODE?'Customer reviews are shared from Supabase with the admin website and app.':'Reviews here are saved locally. Sample comments are fictional and labeled.'}</Txt>
  </View>
 </ScrollView></Page>;
}

const styles=StyleSheet.create({
 label:{fontSize:12,fontWeight:'800',marginTop:15,marginBottom:6},
 textInput:{height:46,borderRadius:12,backgroundColor:C.cream,borderColor:C.border,borderWidth:1,paddingHorizontal:13,fontSize:13,color:C.forest},
 reviewInput:{height:115,textAlignVertical:'top',borderRadius:13,backgroundColor:C.cream,borderColor:C.border,borderWidth:1,padding:13,fontSize:13,color:C.forest},
 avatar:{height:39,width:39,borderRadius:20,backgroundColor:C.green,alignItems:'center',justifyContent:'center'},
 reviewProduct:{marginTop:12,fontSize:11,fontWeight:'800',color:C.green}
});
