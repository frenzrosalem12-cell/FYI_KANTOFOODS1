import React, {useEffect} from 'react';
import {Tabs, router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {C} from '../../constants/theme';
import {useApp} from '../../context/AppContext';
import {useCustomerAuth} from '../../context/AuthContext';
export default function TabsLayout(){
 const {latestOrder}=useApp();
 const {authReady,session}=useCustomerAuth();
 const active=latestOrder && latestOrder.status!=='delivered';
 useEffect(()=>{if(authReady&&!session)router.replace('/');},[authReady,session]);
 if(!authReady||!session)return null;
 return <Tabs screenOptions={{headerShown:false,tabBarActiveTintColor:C.green,tabBarInactiveTintColor:'#96A29A',tabBarLabelStyle:{fontSize:11,fontWeight:'800',marginTop:2},tabBarStyle:{height:65,borderTopColor:C.border,backgroundColor:C.white,paddingTop:7,paddingBottom:7},tabBarHideOnKeyboard:true}}>
  <Tabs.Screen name="menu" options={{title:'Menu',tabBarIcon:({color,focused})=><Ionicons name={focused?'restaurant':'restaurant-outline'} size={22} color={color}/>}}/>
  <Tabs.Screen name="orders" options={{title:'Orders',tabBarBadge:active?'•':undefined,tabBarBadgeStyle:{backgroundColor:C.orange,fontSize:12},tabBarIcon:({color,focused})=><Ionicons name={focused?'receipt':'receipt-outline'} size={22} color={color}/>}}/>
  <Tabs.Screen name="reviews" options={{title:'Reviews',tabBarIcon:({color,focused})=><Ionicons name={focused?'star':'star-outline'} size={22} color={color}/>}}/>
 </Tabs>;
}
