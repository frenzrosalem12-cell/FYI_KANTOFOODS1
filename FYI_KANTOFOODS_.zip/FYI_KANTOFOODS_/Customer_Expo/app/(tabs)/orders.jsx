import React, {useEffect, useMemo, useState} from 'react';
import {Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, Card, Line, Photo, SummaryLine, Txt} from '../../components/UI';
import {C, money} from '../../constants/theme';
import {useApp,cartItemTotal} from '../../context/AppContext';
import {getProduct} from '../../data/products';
import {CONNECTED_MODE} from '../../config/backend';
import OrderFeedbackModal from '../../components/OrderFeedbackModal';
const keys=['confirmed','preparing','out','delivered'];
function stageTime(order,status){
 for(const event of order?.history||[])
  if(event.status===status&&event.at)return new Date(event.at).getTime();
 return null;
}
function stepsFor(type){return [
 {id:'confirmed',title:'Order Confirmed',description:'Your order was received.',icon:'checkmark'},
 {id:'preparing',title:'Being Prepared',description:'Your food and drinks are being prepared.',icon:'restaurant'},
 {id:'out',title:type==='delivery'?'Out for Delivery':'Ready to Serve',description:type==='delivery'?'Your order is on its way!':'Your order is ready to serve.',icon:type==='delivery'?'bicycle':'cafe'},
 {id:'delivered',title:type==='delivery'?'Delivered':'Completed',description:type==='delivery'?'Enjoy your meal!':'Enjoy your food at the store!',icon:'happy'}
]}

// FYI UPGRADES: full-width values wrap cleanly on narrow iPhone screens.
function FyiEstimateRow({label, value}) {
  return <View style={{paddingVertical:10,borderBottomWidth:StyleSheet.hairlineWidth,borderBottomColor:C.border}}>
    <Txt style={{fontSize:12,color:C.muted,lineHeight:18}}>{label}</Txt>
    <Txt style={{fontSize:13,fontWeight:'800',color:C.forest,marginTop:4,lineHeight:20,flexShrink:1}}>{value}</Txt>
  </View>;
}

export default function Orders(){
 const {orders,advanceOrder,submitOrderFeedback}=useApp(); const [selected,setSelected]=useState(null);
 const [reviewTarget,setReviewTarget]=useState(null);
 const [clock,setClock]=useState(Date.now());
 useEffect(()=>{const timer=setInterval(()=>setClock(Date.now()),60000);return()=>clearInterval(timer);},[]);
 const order=useMemo(()=>orders.find(o=>o.id===selected)||orders[0]||null,[orders,selected]);
 const steps=stepsFor('delivery'); const progress=order?Math.max(0,keys.indexOf(order.status==='accepted'?'confirmed':order.status==='ready'?'preparing':order.status)):0; const pendingPayment=order?.status==='pending_payment'; const pendingVerification=order?.status==='pending_verification'; const pending=pendingPayment||pendingVerification;
 const waiting=order?.status==='pending_acceptance'; const rejected=order?.status==='rejected';
 const preparingAt=stageTime(order,'preparing');
 const prepElapsed=preparingAt?Math.max(0,Math.floor((clock-preparingAt)/60000)):0;
 const prepMinutes=preparingAt?Math.max(0,20-prepElapsed):20;
 const distanceValue=order?.roadKm??order?.deliveryLocation?.distanceKm;
 const roadKm=Number.isFinite(distanceValue)?distanceValue:null;
 const travelMinutes=roadKm===null?null:Math.max(5,Math.ceil(roadKm*4));
 const outAt=stageTime(order,'out');
 const travelElapsed=outAt?Math.max(0,Math.floor((clock-outAt)/60000)):0;
 const travelRemaining=travelMinutes===null?null:Math.max(0,travelMinutes-travelElapsed);
 const remainingEta=order?.status==='out'?travelRemaining:
  preparingAt?prepMinutes+(travelMinutes||0):20+(travelMinutes||0);
 return <Page edges={['top']}><Header title="Track Your Order" subtitle="Stay updated with every step" right={<View style={styles.headerChip}><Ionicons name="time-outline" color={C.green} size={16}/><Txt style={{fontSize:11,color:C.green,fontWeight:'900'}}>{CONNECTED_MODE?'Connected to Staff':'Live Demo'}</Txt></View>}/>
 <ScrollView contentContainerStyle={{paddingHorizontal:18,paddingBottom:35}} showsVerticalScrollIndicator={false}>
 {!order?<View style={{alignItems:'center',paddingTop:80}}><View style={styles.empty}><Ionicons name="receipt-outline" color={C.green} size={55}/></View><Txt style={{fontSize:21,fontWeight:'900',marginTop:20}}>No orders yet</Txt><Txt style={{fontSize:13,color:C.muted,textAlign:'center',maxWidth:240,lineHeight:21,marginTop:8}}>Your delicious orders will appear here once you check out.</Txt><Button style={{marginTop:24,width:'85%'}} onPress={()=>router.push('/(tabs)/menu')}>Explore the Menu</Button></View>:<>
  <Card style={{marginTop:6}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}><View><Txt style={{fontSize:12,color:C.muted}}>ORDER #{order.id}</Txt><Txt style={{fontSize:20,fontWeight:'900',marginTop:5}}>Delivery Order</Txt></View><View style={{backgroundColor:order.status==='delivered'?C.mint:'#FFF3DC',padding:9,borderRadius:11}}><Txt style={{color:order.status==='delivered'?C.green:'#AA7100',fontSize:11,fontWeight:'900'}}>{pendingPayment?'Awaiting PayMongo Payment':pendingVerification?'Awaiting Payment Verification':order.status==='pending_acceptance'?'Waiting for Cashier':order.status==='rejected'?'Rejected':order.status==='accepted'?'Accepted by Cashier':order.status==='ready'?'Kitchen Ready':order.status==='delivered'?'Completed':order.status==='preparing'?'Preparing':order.status==='out'?'On the way':'Confirmed'}</Txt></View></View><Txt style={{fontSize:11,color:C.muted,marginTop:13}}>Placed {new Date(order.createdAt).toLocaleString('en-PH',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}</Txt></Card>
  <Card style={{marginTop:14}}><Txt style={{fontWeight:'900',fontSize:16,marginBottom:10}}>Preparation & delivery estimate</Txt><FyiEstimateRow label="Road distance" value={roadKm===null?'Calculating':`${roadKm.toFixed(2)} km`}/><FyiEstimateRow label="Kitchen preparation" value={pending||waiting||rejected?'After payment and cashier acceptance':order.status==='delivered'?'Complete':preparingAt?`${prepMinutes} min estimated remaining`:'About 20 min after kitchen starts'}/><FyiEstimateRow label="Delivery travel" value={order.status==='delivered'?'Delivered':travelMinutes===null?'Route unavailable':order.status==='out'?`About ${travelRemaining} min remaining`:`About ${travelMinutes} min after dispatch`}/><FyiEstimateRow label="Estimated time remaining" value={pending||waiting||rejected?'Waiting for order acceptance':order.status==='delivered'?'Delivered':remainingEta===null?'Unavailable':`About ${remainingEta} min`}/>{!pending&&!waiting&&!rejected&&order.status!=='delivered'?<Txt style={{fontSize:11,lineHeight:17,color:C.muted,marginTop:6}}>Rough estimate only; actual kitchen and traffic times can vary.{order.status==='out'?' The app does not have the driver’s live GPS.':''}</Txt>:null}</Card>
  <Card style={{marginTop:14,paddingBottom:5}}><View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:21}}><View><Txt style={{fontWeight:'900',fontSize:17}}>Order Progress</Txt><Txt style={{fontSize:11,color:C.muted,marginTop:4}}>Follow your order's journey</Txt></View><View style={styles.eta}><Ionicons name="time-outline" size={17} color={C.green}/><Txt style={{fontWeight:'900',color:C.green,fontSize:12}}>{pending||waiting?'Pending':rejected?'Stopped':order.status==='delivered'?'Done':'In progress'}</Txt></View></View>
  {(pending||waiting||rejected)?<View style={styles.paymentWait}>
     <Ionicons name="time-outline" size={30} color="#966000"/>
     <View style={{flex:1}}><Txt style={{fontWeight:'900',color:'#865900'}}>{pendingPayment?'Awaiting PayMongo Payment':pendingVerification?'Awaiting Payment Verification':waiting?'Awaiting Cashier Acceptance':'Order Rejected'}</Txt>
     <Txt style={{fontSize:12,lineHeight:19,color:'#795D2F',marginTop:6}}>{pendingPayment?'Complete the secure GCash checkout. Staff will receive your order after PayMongo confirms payment.':pendingVerification?'Your payment is awaiting verification.':waiting?'Your payment is confirmed. The cashier will accept this delivery order shortly.':'This order was rejected. Contact the store if you need assistance.'}</Txt>
     </View></View>:null}
  {steps.map((step,i)=>{
    const completed=i<progress, current=i===progress;
    return <View key={step.id} style={{flexDirection:'row',gap:15,minHeight:i===steps.length-1?67:88}}><View style={{alignItems:'center',width:38}}><View style={[styles.stepIcon,(completed||current)&&{backgroundColor:completed?C.green:C.paleMint,borderColor:C.green}]}><Ionicons name={completed?'checkmark':step.icon} size={19} color={completed?C.white:current?C.green:'#C3CDC5'}/></View>{i<steps.length-1?<View style={{width:2,flex:1,backgroundColor:completed?C.green:C.border,marginVertical:6}}/>:null}</View><View style={{flex:1,paddingTop:3}}><Txt style={{fontSize:14,fontWeight:'900',color:completed||current?C.forest:C.muted}}>{step.title}</Txt><Txt style={{color:C.muted,fontSize:12,lineHeight:18,marginTop:5}}>{step.description}</Txt>{current&&order.status!=='delivered'?<View style={{marginTop:8,alignSelf:'flex-start',paddingHorizontal:8,paddingVertical:4,backgroundColor:'#FFF4DC',borderRadius:7}}><Txt style={{fontSize:10,color:'#AE7403',fontWeight:'900'}}>IN PROGRESS</Txt></View>:null}</View></View>
   })}
  </Card>
  <View style={styles.demo}><Ionicons name="construct-outline" size={22} color={C.green}/><View style={{flex:1}}><Txt style={{fontWeight:'900',color:C.forest,fontSize:13}}>Order status updates</Txt><Txt style={{fontSize:11,lineHeight:17,color:C.muted,marginTop:4}}>{CONNECTED_MODE?'Connected mode: only the cashier and kitchen can update order stages. The app polls the server for changes.':'Offline demo: use the button below to simulate order progress.'}</Txt></View></View>
  {(pending||waiting||rejected)?<View style={styles.waitNotice}><Ionicons name="lock-closed-outline" color="#946000" size={18}/><Txt style={{fontSize:12,flex:1,color:'#795D2F'}}>{pendingPayment?'Payment must be completed before the cashier can accept this delivery.':pendingVerification?'The cashier must verify payment before accepting the delivery.':waiting?'Waiting for cashier acceptance.':'This order is not being processed.'}</Txt></View>:order.status!=='delivered'?CONNECTED_MODE?<View style={{padding:12,marginTop:12,backgroundColor:C.mint,borderRadius:12}}><Txt style={{color:C.green,fontSize:12,textAlign:'center'}}>Waiting for the cashier or kitchen to update this order…</Txt></View>:<Button secondary icon="play-outline" style={{marginTop:12}} onPress={()=>advanceOrder(order.id)}>Advance Demo Status</Button>:null}
  {order.paymentStatus==='paid'&&!order.reviewed?<Button style={{marginTop:15}} icon="star-outline" onPress={()=>setReviewTarget(order)}>Rate Your Experience</Button>:order.reviewed?<View style={{padding:13,backgroundColor:C.mint,borderRadius:12,marginTop:15}}><Txt style={{textAlign:'center',color:C.green,fontWeight:'800'}}>Thanks for leaving a review! 💚</Txt></View>:null}
  <Card style={{marginTop:15}}><Txt style={{fontWeight:'900',fontSize:17,marginBottom:13}}>Order Summary</Txt>{order.items.map(item=>{const p=getProduct(item.productId);if(!p)return null;return <View key={item.key} style={{flexDirection:'row',alignItems:'center',gap:9,paddingVertical:8}}><View style={{height:44,width:44,overflow:'hidden',borderRadius:10}}><Photo productId={p.id} image={p.image} category={p.category}/></View><View style={{flex:1}}><Txt style={{fontWeight:'700',fontSize:12}}>{p.name}</Txt><Txt style={{color:C.muted,fontSize:11}}>x{item.qty} • {item.size}</Txt></View><Txt style={{fontWeight:'900',fontSize:12}}>{money(cartItemTotal(item))}</Txt></View>})}<Line/>{order.type==='delivery'?<><SummaryLine label="Road distance" value={order.deliveryLocation?`${order.deliveryLocation.distanceKm.toFixed(2)} km`:'—'}/><SummaryLine label="Delivery fee" value={money(order.deliveryFee)}/></>:null}<SummaryLine label="Total" value={money(order.total)} bold/><Txt style={{fontSize:11,color:C.muted,marginTop:6}}>{order.type==='delivery'?`Deliver to: ${order.customer.address}`:'Dine in at FYI KANTO'}</Txt></Card>
  {orders.length>1?<View style={{marginTop:22}}><Txt style={{fontWeight:'900',fontSize:17,marginBottom:12}}>Your Order History</Txt>{orders.map(o=><Pressable onPress={()=>setSelected(o.id)} key={o.id} style={[styles.history,order.id===o.id&&{borderColor:C.green}]}><Ionicons name="receipt-outline" size={21} color={C.green}/><View style={{flex:1}}><Txt style={{fontWeight:'900',fontSize:13}}>#{o.id}</Txt><Txt style={{fontSize:11,color:C.muted}}>{o.status==='pending_payment'?'Awaiting payment':o.status==='pending_verification'?'Pending payment verification':o.status==='delivered'?'Completed':'In progress'}</Txt></View><Txt style={{fontWeight:'900',color:C.green}}>{money(o.total)}</Txt></Pressable>)}</View>:null}
 </>}
 </ScrollView>
 <OrderFeedbackModal visible={Boolean(reviewTarget)} order={reviewTarget}
   onClose={()=>setReviewTarget(null)} onSubmit={submitOrderFeedback}/>
 </Page>;
}
const styles=StyleSheet.create({headerChip:{flexDirection:'row',gap:5,alignItems:'center',backgroundColor:C.mint,paddingHorizontal:10,paddingVertical:9,borderRadius:12},empty:{height:115,width:115,borderRadius:60,backgroundColor:C.mint,alignItems:'center',justifyContent:'center'},eta:{flexDirection:'row',gap:6,alignItems:'center',padding:10,backgroundColor:C.mint,borderRadius:12},stepIcon:{width:35,height:35,borderRadius:18,justifyContent:'center',alignItems:'center',borderColor:'#DFE9E0',borderWidth:2,backgroundColor:'#F7F9F7'},demo:{marginTop:15,backgroundColor:'#E9F5EF',borderRadius:13,padding:14,flexDirection:'row',gap:10},paymentWait:{marginBottom:22,borderRadius:12,backgroundColor:'#FFF5DB',padding:14,flexDirection:'row',gap:10},waitNotice:{marginTop:13,backgroundColor:'#FFF5DB',padding:13,borderRadius:12,flexDirection:'row',gap:9,alignItems:'center'},history:{padding:14,backgroundColor:C.white,borderColor:C.border,borderWidth:1,borderRadius:13,marginBottom:9,flexDirection:'row',gap:12,alignItems:'center'}});
