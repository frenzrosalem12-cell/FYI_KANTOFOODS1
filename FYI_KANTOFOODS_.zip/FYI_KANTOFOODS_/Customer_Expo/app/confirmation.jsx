import React, {useEffect, useState} from 'react';
import {Alert,Linking,ScrollView,StyleSheet,View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Button, Card, SummaryLine, Txt} from '../components/UI';
import {C, money} from '../constants/theme';
import {useApp} from '../context/AppContext';
import {CONNECTED_MODE} from '../config/backend';
import OrderFeedbackModal from '../components/OrderFeedbackModal';
export default function Confirmation(){
 const {latestOrder,submitOrderFeedback}=useApp();
 const [feedbackVisible,setFeedbackVisible]=useState(false);
 const [dismissedOrderId,setDismissedOrderId]=useState(null);
 const pending=latestOrder?.paymentStatus==='pending_payment';
 const paid=latestOrder?.paymentStatus==='paid';
 useEffect(()=>{
   if(paid&&!latestOrder?.reviewed&&latestOrder?.id&&dismissedOrderId!==latestOrder.id)
     setFeedbackVisible(true);
 },[paid,latestOrder?.reviewed,latestOrder?.id,dismissedOrderId]);
 const closeFeedback=()=>{setFeedbackVisible(false);setDismissedOrderId(latestOrder?.id||null);};
 const openCheckout=async()=>{
   try{await Linking.openURL(latestOrder.paymentUrl);}
   catch(error){Alert.alert('Unable to open PayMongo',error.message||'Please try again or contact the store.');}
 };
 return <Page><ScrollView contentContainerStyle={{flexGrow:1,justifyContent:'center',padding:25}}>
   <View style={{alignItems:'center'}}>
     <View style={[styles.icon,pending&&{backgroundColor:'#E99A27',borderColor:'#FFF2D9'}]}><Ionicons name={pending?'time-outline':'checkmark'} size={57} color={C.white}/></View>
     <Txt style={{fontSize:24,fontWeight:'900',color:C.forest,marginTop:20,textAlign:'center'}}>{pending?'Complete your payment':paid?'Transaction successful':'Order submitted'}</Txt>
     <Txt style={{textAlign:'center',fontSize:13,lineHeight:21,color:C.muted,marginTop:10}}>{pending?'Your delivery order is waiting for secure GCash payment. The cashier will receive it after PayMongo confirms payment.':paid?'PayMongo test mode confirmed your GCash payment. No real money was charged. Your order is now in the delivery queue. Track kitchen preparation and delivery progress in Orders.':'Your order is submitted. Follow the progress in the Orders tab.'}</Txt>
   </View>
   <Card style={{marginTop:30}}>
     <Txt style={{textAlign:'center',fontSize:12,color:C.muted}}>Order Reference</Txt>
     <Txt selectable style={{fontSize:24,fontWeight:'900',textAlign:'center',marginTop:5,color:C.green}}>#{latestOrder?.id||'FYI-DEMO'}</Txt>
     <View style={{height:1,backgroundColor:C.border,marginVertical:17}}/>
     <SummaryLine label="Order Type" value="Delivery"/>
     <SummaryLine label="Payment" value="GCash via PayMongo"/>
     <SummaryLine label="Transaction" value={paid?'Successful':pending?'Awaiting payment':'Awaiting confirmation'}/>
     {latestOrder?.type==='delivery'?<><SummaryLine label="Road Distance" value={latestOrder.deliveryLocation?`${latestOrder.deliveryLocation.distanceKm.toFixed(2)} km`:'—'}/><SummaryLine label="Delivery Fee" value={money(latestOrder.deliveryFee)}/></>:null}
     <SummaryLine label="Total" value={money(latestOrder?.total)} bold/>
   </Card>
   {pending&&latestOrder?.paymentUrl?<Button style={{marginTop:24}} onPress={openCheckout} icon="lock-closed-outline">Continue to secure payment</Button>:null}
   {paid&&!latestOrder?.reviewed?<Button secondary style={{marginTop:12}} onPress={()=>setFeedbackVisible(true)} icon="star-outline">Rate Your Experience</Button>:null}
   <Button style={{marginTop:pending?10:24}} onPress={()=>router.replace(paid?'/(tabs)/menu':'/(tabs)/orders')}>{paid?'Go to Home Dashboard':'Track Your Order'}</Button>
   {paid?<Button secondary icon="receipt-outline" style={{marginTop:10}} onPress={()=>router.replace('/(tabs)/orders')}>Track Delivery</Button>:<Button secondary icon="restaurant-outline" style={{marginTop:10}} onPress={()=>router.replace('/(tabs)/menu')}>Back to Menu</Button>}
   <Txt style={{fontSize:11,textAlign:'center',color:C.muted,marginTop:20}}>{CONNECTED_MODE?'PayMongo payment status is verified by the backend before the order is released to staff.':'Connect Supabase and the backend to place orders.'}</Txt>
 </ScrollView>
 <OrderFeedbackModal visible={feedbackVisible&&paid&&!latestOrder?.reviewed}
   order={latestOrder} onClose={closeFeedback} onSubmit={submitOrderFeedback}/>
 </Page>;
}
const styles=StyleSheet.create({icon:{width:103,height:103,backgroundColor:C.green,borderRadius:55,alignItems:'center',justifyContent:'center',borderWidth:10,borderColor:C.mint}});
