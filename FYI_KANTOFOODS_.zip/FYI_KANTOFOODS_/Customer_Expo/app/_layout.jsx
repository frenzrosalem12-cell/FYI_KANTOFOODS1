
import React, { useEffect } from 'react';
import { Platform, View } from 'react-native';
import { router, Stack, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AppProvider } from '../context/AppContext';
import { AuthProvider, useCustomerAuth } from '../context/AuthContext';
import { C } from '../constants/theme';

function AppStack() {
  const { authReady, session } = useCustomerAuth();
  const segments = useSegments();
  const currentRoute = segments[0];

  useEffect(() => {
    if (!authReady || session) return;

    // Allow these screens without logging in.
    const publicRoutes = [
      'index',
      'forgot-password',
      'reset-password'
    ];

    if (currentRoute && !publicRoutes.includes(currentRoute)) {
      router.replace('/');
    }
  }, [authReady, session, currentRoute]);

  return (
    <>
      <StatusBar
        style="dark"
        backgroundColor={C.cream}
      />

      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: {
            backgroundColor: C.cream
          },
          animation: 'slide_from_right'
        }}
      >
        <Stack.Screen name="index" />

        {/* Customer authentication screens */}
        <Stack.Screen name="forgot-password" />
        <Stack.Screen name="reset-password" />

        {/* Customer application screens */}
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="profile" />
        <Stack.Screen name="category/[id]" />
        <Stack.Screen name="product/[id]" />
        <Stack.Screen name="order-type" />
        <Stack.Screen name="customer-info" />
        <Stack.Screen name="delivery-map" />
        <Stack.Screen name="order-summary" />
        <Stack.Screen name="confirmation" />
      </Stack>
    </>
  );
}

export default function Layout() {
  return (
    <View
      style={
        Platform.OS === 'web'
          ? {
              flex: 1,
              width: '100%',
              maxWidth: 520,
              alignSelf: 'center',
              minHeight: '100vh',
              backgroundColor: C.cream,
              boxShadow: '0 0 36px rgba(0,45,28,0.10)'
            }
          : {
              flex: 1
            }
      }
    >
      <SafeAreaProvider>
        <AuthProvider>
          <AppProvider>
            <AppStack />
          </AppProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </View>
  );
}
