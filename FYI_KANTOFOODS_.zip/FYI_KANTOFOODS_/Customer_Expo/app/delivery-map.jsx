import React, {useEffect, useRef, useState} from 'react';
import {ActivityIndicator, Alert, Platform, Pressable, StyleSheet, View} from 'react-native';
import * as Location from 'expo-location';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, Txt, SummaryLine} from '../components/UI';
import DeliveryPinMap from '../components/DeliveryPinMap';
import {C, money} from '../constants/theme';
import {useApp} from '../context/AppContext';
import {calculateDeliveryFee, roundKm} from '../config/delivery';
import {backendRequest} from '../config/backend';

export default function DeliveryMapScreen(){
  const {deliveryLocation, setDeliveryLocation, subtotal} = useApp();
  const [pin, setPin] = useState(deliveryLocation?{latitude:deliveryLocation.latitude,longitude:deliveryLocation.longitude}:null);
  const [route, setRoute] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [findingLocation, setFindingLocation] = useState(false);
  const counter = useRef(0);

  useEffect(()=>{
    if(!pin){setRoute(null);return;}
    const requestId=++counter.current;
    const controller = new AbortController();
    setRoute(null);
    setError('');
    setLoading(true);
    const task=setTimeout(async()=>{
      try{
        const result=await backendRequest('/api/public/route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lat:pin.latitude,lng:pin.longitude})});
        if(!Number.isFinite(result.roadKm))throw new Error('The server could not calculate a drivable route. Move your pin closer to a road.');
        const coords=Array.isArray(result.coordinates)?result.coordinates:[];
        if(requestId!==counter.current)return;
        setRoute({km:roundKm(result.roadKm),coordinates:coords,storeLatitude:result.storeLatitude,storeLongitude:result.storeLongitude});
      }catch(err){
        if(requestId!==counter.current||controller.signal.aborted)return;
        setError(err.message||'Could not calculate road distance. Try again.');
      }finally{if(requestId===counter.current)setLoading(false);}
    },350);
    return ()=>{clearTimeout(task);controller.abort();};
  },[pin]);

  const useCurrentLocation=async()=>{
    if(findingLocation)return;
    setFindingLocation(true);
    try{
      const {status}=await Location.requestForegroundPermissionsAsync();
      if(status!=='granted'){
        Alert.alert('Location permission needed','Enable location access to use this feature, or tap the map to manually set your pin.');
        return;
      }
      const place=await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.Balanced});
      if(!Number.isFinite(place.coords.latitude)||!Number.isFinite(place.coords.longitude))throw Error('Invalid GPS coordinates');
      setPin({latitude:place.coords.latitude,longitude:place.coords.longitude});
    }catch(e){Alert.alert('Could not get location','Please turn on GPS and internet, or tap on the map manually.');}
    finally{setFindingLocation(false);}
  };
  const km=route?.km;
  const fee=calculateDeliveryFee(km);
  const confirm=()=>{
    if(!pin||!route||fee===null)return Alert.alert('Choose a location','Tap the map and wait for the road distance and fee.');
    setDeliveryLocation({latitude:pin.latitude,longitude:pin.longitude,distanceKm:km,fee,source:'backend_route',calculatedAt:new Date().toISOString(),storeLatitude:route.storeLatitude,storeLongitude:route.storeLongitude});
    router.back();
  };
  return <Page>
    <Header title="Pin Your Delivery Location" subtitle="Tap the map or drag the red marker" onBack={()=>router.back()}/>
    <View style={styles.tip}><Ionicons name="location" color={C.green} size={19}/><View style={{flex:1}}>
      <Txt style={{fontWeight:'900',fontSize:12}}>Green = store · Red = your delivery pin</Txt>
      <Txt style={{fontSize:11,color:C.muted,marginTop:3}}>Choose your exact drop-off spot. The route is calculated on roads, not straight-line distance.</Txt>
    </View></View>
    <Pressable onPress={useCurrentLocation} disabled={findingLocation} accessibilityRole="button" accessibilityLabel="Use my current location" style={styles.locationButton}>
      {findingLocation?<ActivityIndicator color="#EA661A" size="small"/>:<Ionicons name="location-sharp" color="#EA661A" size={21}/>}
      <Txt style={styles.locationButtonText}>{findingLocation?'Finding your location…':'Use My Current Location'}</Txt>
    </Pressable>
    <View style={styles.map}><DeliveryPinMap pin={pin} onPick={setPin} routeCoordinates={route?.coordinates||[]} storeLocation={route?{latitude:route.storeLatitude,longitude:route.storeLongitude}:null}/></View>
    <View style={styles.footer}>
      <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:8,marginBottom:9}}>
       <View><Txt style={styles.muted}>Road distance</Txt><Txt style={styles.value}>{loading?<ActivityIndicator size="small" color={C.green}/>:route?`${km.toFixed(2)} km`:'— km'}</Txt></View>
       <View style={{alignItems:'flex-end'}}><Txt style={styles.muted}>Delivery fee</Txt><Txt style={[styles.value,{color:C.green}]}>{route?money(fee):'—'}</Txt></View>
      </View>
      <SummaryLine label="Order subtotal" value={money(subtotal)}/>
      <SummaryLine label="Total after selecting pin" value={route?money(subtotal+fee):'Select pin first'} bold/>
      {!!error&&<Txt style={styles.error}>{error}</Txt>}
      {!pin && <Txt style={styles.help}>Tap anywhere on the map to set your destination.</Txt>}
      <Button style={{marginTop:12}} disabled={!route||loading||Platform.OS==='web'} onPress={confirm} icon="checkmark-circle-outline">Use This Location & Fee</Button>
      <Txt style={styles.disclaimer}>The server calculates the road route and delivery fee; the final order total is checked again before payment.</Txt>
    </View>
  </Page>;
}
const styles=StyleSheet.create({tip:{paddingHorizontal:17,paddingVertical:10,flexDirection:'row',gap:9,backgroundColor:C.paleMint,alignItems:'center'},locationButton:{marginHorizontal:15,marginTop:9,marginBottom:9,borderWidth:1.5,borderColor:'#F18A38',backgroundColor:'#FFFDF9',minHeight:53,borderRadius:14,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:9},locationButtonText:{fontSize:15,color:'#D66B1F',fontWeight:'900'},map:{flex:1,minHeight:225,marginHorizontal:15,backgroundColor:'#F1F0EB',borderRadius:14,overflow:'hidden',borderWidth:1,borderColor:C.border},footer:{paddingHorizontal:17,paddingTop:11,paddingBottom:12,backgroundColor:C.white,borderTopColor:C.border,borderTopWidth:1},warning:{flexDirection:'row',gap:7,alignItems:'center',padding:10,backgroundColor:'#FFF4DF',borderRadius:10},muted:{fontSize:12,color:C.muted},value:{fontSize:22,fontWeight:'900',color:C.forest,marginTop:3},error:{backgroundColor:'#FFF0F0',color:'#A63B3B',borderRadius:8,padding:9,fontSize:11,marginVertical:4},help:{color:C.muted,fontSize:11,marginTop:5},disclaimer:{fontSize:10,color:C.muted,textAlign:'center',marginTop:7}});
