import React, {useState} from 'react';
import {ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TextInput, View} from 'react-native';
import {router} from 'expo-router';
import {Button, Logo, Page, Txt} from '../components/UI';
import {C} from '../constants/theme';
import {useCustomerAuth} from '../context/AuthContext';

export default function ResetPassword() {
  const {authReady, session, recoveryMode, recoveryPending, recoveryError, updatePassword} = useCustomerAuth();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [complete, setComplete] = useState(false);

  const submit = async () => {
    setMessage('');
    if (password.length < 8) return setMessage('Use at least 8 characters for your new password.');
    if (password !== confirm) return setMessage('The passwords do not match.');
    setBusy(true);
    try {
      await updatePassword(password);
      setPassword('');
      setConfirm('');
      setComplete(true);
    } catch (error) {
      setMessage(error?.message || 'Could not update your password. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (!authReady || recoveryPending) {
    return <Page><View style={styles.center}>
      <ActivityIndicator size="large" color={C.green}/>
      <Txt>Verifying your reset link…</Txt>
    </View></Page>;
  }

  return <Page>
    <KeyboardAvoidingView style={{flex: 1}} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
        <View style={styles.logo}><Logo/></View>
        <Txt style={styles.heading}>{complete ? 'Password updated!' : 'Create a new password'}</Txt>
        {complete ? <>
          <Txt style={styles.description}>Your password has been changed. Log in using your new password.</Txt>
          <Button onPress={() => router.replace('/')} style={styles.button} icon="arrow-forward">Back to login</Button>
        </> : recoveryMode && session ? <>
          <Txt style={styles.description}>Enter a new password for your FYI-KANTO customer account.</Txt>
          <Txt style={styles.label}>New password</Txt>
          <TextInput style={styles.input} placeholder="At least 8 characters" secureTextEntry autoCapitalize="none"
            placeholderTextColor="#9AA79E" value={password} onChangeText={setPassword}/>
          <Txt style={styles.label}>Confirm new password</Txt>
          <TextInput style={styles.input} placeholder="Re-enter your new password" secureTextEntry autoCapitalize="none"
            placeholderTextColor="#9AA79E" value={confirm} onChangeText={setConfirm}/>
          {message ? <View style={styles.error}><Txt style={styles.errorText}>{message}</Txt></View> : null}
          <Button onPress={submit} disabled={busy} style={styles.button} icon={busy ? null : 'arrow-forward'}>
            {busy ? 'Saving password…' : 'Save new password'}
          </Button>
        </> : <>
          <Txt style={styles.description}>{recoveryError || 'Open the password reset link sent to your email. If it expired, request a new link.'}</Txt>
          <Button onPress={() => router.replace('/')} style={styles.button} icon="arrow-forward">Back to login</Button>
        </>}
      </ScrollView>
    </KeyboardAvoidingView>
  </Page>;
}

const styles = StyleSheet.create({
  content: {paddingHorizontal: 24, paddingTop: 48, paddingBottom: 30},
  logo: {alignItems: 'center', marginBottom: 28},
  heading: {fontSize: 27, fontWeight: '900', color: C.forest},
  description: {fontSize: 14, lineHeight: 21, color: C.muted, marginTop: 8, marginBottom: 24},
  label: {fontSize: 13, fontWeight: '800', marginBottom: 7},
  input: {backgroundColor: C.white, borderWidth: 1, borderColor: C.border, borderRadius: 12,
    paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: C.ink, marginBottom: 17},
  button: {marginTop: 12, minHeight: 52},
  error: {padding: 12, borderRadius: 11, backgroundColor: '#FFF0F0', marginTop: 5},
  errorText: {fontSize: 12, color: C.forest, lineHeight: 18},
  center: {flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14},
});
