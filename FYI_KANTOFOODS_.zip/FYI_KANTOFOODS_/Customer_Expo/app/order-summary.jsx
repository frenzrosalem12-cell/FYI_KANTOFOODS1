import React, {useState} from 'react';
import {Alert, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Header, Button, Card, Line, Photo, SummaryLine, Txt, ClosedNotice} from '../components/UI';
import {C, money} from '../constants/theme';
import {useApp,cartItemTotal} from '../context/AppContext';
import {getProduct} from '../data/products';
import {CONNECTED_MODE} from '../config/backend';
export default function OrderSummary(){
 const {cart,customer,orderType,subtotal,deliveryFee,total,deliveryLocation,hasDeliveryRoute,createOrder,storeStatus}=useApp();
 const [submitting,setSubmitting]=useState(false);
 const confirm=async()=>{
  if(!storeStatus.isOpen)return Alert.alert('Closed Now','FYI-KANTO is closed. You cannot confirm an order right now.');
  if(!cart.length)return Alert.alert('Empty order','Add products to your order first.');
  if(!customer.name.trim()||!/^09\d{9}$/.test(customer.phone)||!customer.address.trim())return Alert.alert('Missing details','Return to your information to complete required fields.');
  if(!hasDeliveryRoute)return Alert.alert('Pin missing','Please select a delivery location on the map first.');
  if(submitting)return;
  setSubmitting(true);
  try{const order=await createOrder(); if(order)router.replace('/confirmation');
  else Alert.alert('Unable to submit','Check the opening hours and delivery map pin.');}
  catch(err){Alert.alert('Submission failed',err.message||'Please check your server connection.');}
  finally{setSubmitting(false);}
 };
 return <Page><Header title="Order Summary" subtitle="Review everything before confirming" onBack={()=>router.back()}/>
 <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingHorizontal:18,paddingBottom:32}}>
  <ClosedNotice/>
  <Card><View style={styles.cardHeading}><Txt style={styles.section}>Delivery details</Txt><Pressable onPress={()=>router.push('/customer-info')}><Txt style={styles.edit}>Edit</Txt></Pressable></View>
   <View style={styles.info}><Ionicons name="person-outline" size={17} color={C.green}/><Txt>{customer.name}</Txt></View>
   <View style={styles.info}><Ionicons name="call-outline" size={17} color={C.green}/><Txt>{customer.phone}</Txt></View>
   <View style={styles.info}><Ionicons name="location-outline" size={17} color={C.green}/><Txt style={{flex:1}}>{customer.address}{customer.landmark?'; '+customer.landmark:''}</Txt></View>
   {hasDeliveryRoute?<View style={styles.info}><Ionicons name="map-outline" color={C.green} size={17}/><Txt style={{flex:1}}>{deliveryLocation.distanceKm.toFixed(2)} km by road · Delivery fee {money(deliveryFee)}</Txt><Pressable onPress={()=>router.push('/delivery-map')}><Txt style={styles.edit}>Edit pin</Txt></Pressable></View>:null}
   {customer.facebook?<View style={styles.info}><Ionicons name="logo-facebook" size={17} color={C.blue}/><Txt>{customer.facebook}</Txt></View>:null}
   <View style={styles.info}><Ionicons name="wallet-outline" size={17} color={C.green}/><Txt>GCash via PayMongo</Txt></View>
  </Card>
  <Card style={{marginTop:15}}><View style={styles.cardHeading}><Txt style={styles.section}>Order Items ({cart.length})</Txt><Pressable onPress={()=>router.push('/order-type')}><Txt style={styles.edit}>Edit</Txt></Pressable></View>
   {cart.map(item=>{const p=getProduct(item.productId);if(!p)return null;return <View key={item.key} style={styles.item}><View style={{width:59,height:59,overflow:'hidden',borderRadius:12}}><Photo productId={p.id} image={p.image} category={p.category}/></View><View style={{flex:1}}><Txt style={{fontSize:13,fontWeight:'900'}} numberOfLines={2}>{p.name}</Txt><Txt style={{fontSize:11,color:C.muted,marginTop:4}}>{item.size}{item.variant?' · '+item.variant:''}{item.addOnIds.length?' · '+item.addOnIds.join(', '):''}</Txt><Txt style={{fontSize:11,color:C.muted}}>Quantity: {item.qty}</Txt></View><Txt style={{fontWeight:'900',color:C.green}}>{money(cartItemTotal(item))}</Txt></View>})}
   <Line/><SummaryLine label="Subtotal" value={money(subtotal)}/><SummaryLine label="Estimated delivery fee" value={deliveryFee===null?'Select location':money(deliveryFee)}/><Line/><SummaryLine label="Total" value={total===null?'Not calculated':money(total)} bold color={C.green}/>
  </Card>
  {customer.notes?<Card style={{marginTop:15}}><Txt style={styles.section}>Order notes</Txt><Txt style={{color:C.muted,fontSize:13,marginTop:8}}>{customer.notes}</Txt></Card>:null}
  <View style={{backgroundColor:C.mint,padding:14,borderRadius:14,marginTop:17,flexDirection:'row',gap:10}}><Ionicons name="shield-checkmark-outline" size={21} color={C.green}/><Txt style={{flex:1,color:C.forest,lineHeight:19,fontSize:12}}>{CONNECTED_MODE?'The server creates a secure PayMongo checkout and confirms payment from its signed webhook before staff can accept the order.':'Connect Supabase and the backend before placing an order.'}</Txt></View>
  <Button style={{marginTop:19}} disabled={submitting||!storeStatus.isOpen||total===null||!CONNECTED_MODE} onPress={confirm}>{submitting?'Creating secure checkout…':'Continue to PayMongo'} • {total===null?'Pin location first':money(total)}</Button>
 </ScrollView></Page>
}
const styles=StyleSheet.create({cardHeading:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:12},section:{fontSize:16,fontWeight:'900'},edit:{color:C.green,fontWeight:'900',fontSize:12},info:{flexDirection:'row',gap:10,alignItems:'center',marginVertical:6},item:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:13,borderBottomWidth:1,borderBottomColor:C.border}});
