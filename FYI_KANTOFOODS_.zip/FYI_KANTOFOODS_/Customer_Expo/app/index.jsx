import React, {useEffect, useState} from 'react';
import {ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, TextInput, View} from 'react-native';
import {router} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Button, Logo, Page, Txt} from '../components/UI';
import {C} from '../constants/theme';
import {useCustomerAuth} from '../context/AuthContext';

export default function Login() {
  const {authReady, session, recoveryMode, recoveryPending, supabaseConfigured,
    signIn, signUp} = useCustomerAuth();
  const [mode, setMode] = useState('login');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!authReady || recoveryPending) return;
    if (recoveryMode) router.replace('/reset-password');
    else if (session) router.replace('/(tabs)/menu');
  }, [authReady, session, recoveryMode, recoveryPending]);

  const switchMode = next => {
    setMessage('');
    setMode(next);
  };

  const submit = async () => {
    setMessage('');
    if (!supabaseConfigured) {
      setMessage('Customer accounts are not connected yet. Check the Supabase URL and public key in Customer_Expo/.env.');
      return;
    }
    if (!password) {
      setMessage('Enter your password.');
      return;
    }
    if (mode === 'signup') {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setMessage('Enter a valid email address.');
      if (!/^[a-z0-9._-]{3,30}$/i.test(username.trim())) return setMessage('Username must be 3–30 letters, numbers, dots, underscores or hyphens.');
      if (!/^09\d{9}$/.test(phone)) return setMessage('Enter an 11-digit Philippine phone number starting with 09.');
      if (address.trim().length < 5) return setMessage('Enter your complete delivery address.');
      if (password !== confirmPassword) return setMessage('The passwords do not match.');
    }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const result = await signUp({email, password, username, phone, address});
        if (!result.session) throw Error('Your account was created, but automatic sign-in did not start. Please log in.');
      } else {
        await signIn(identifier, password);
      }
      router.replace('/(tabs)/menu');
    } catch (error) {
      const detail = String(error?.message || error || '');
      if (mode === 'signup' && (/profiles_username_lower_unique|duplicate key/i.test(detail) || error?.code === '23505')) {
        setMessage('That username is already taken. Choose another username.');
      } else if (/user already registered|email.*already.*registered/i.test(detail)) {
        setMessage('This email already has an account. Log in or use Forgot password.');
      } else setMessage(detail || 'Unable to continue. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (!authReady || session || recoveryMode || recoveryPending) {
    return <Page><View style={styles.center}>
      <ActivityIndicator size="large" color={C.green}/>
      <Txt style={styles.loadingText}>Getting your account ready…</Txt>
    </View></Page>;
  }

  return <Page>
    <KeyboardAvoidingView style={{flex: 1}} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.brand}>
          <Logo/>
          <View style={styles.badge}><Ionicons name="bicycle-outline" size={15} color={C.green}/><Txt style={styles.badgeText}>Delivery made easy</Txt></View>
        </View>
        <Txt style={styles.heading}>{mode === 'login' ? 'Welcome back' : 'Create your account'}</Txt>
        <Txt style={styles.subheading}>{mode === 'login'
          ? 'Sign in with your email to browse the menu and track deliveries.'
          : 'Join FYI-KANTO to order delivery and manage your details.'}</Txt>

        {mode === 'signup' ? <>
          <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" maxLength={254}/>
          <Field label="Username" value={username} onChangeText={setUsername} placeholder="Choose a username" autoCapitalize="none" maxLength={30}/>
          <Field label="Phone number" value={phone} onChangeText={value => setPhone(value.replace(/\D/g, '').slice(0, 11))} placeholder="09XXXXXXXXX" keyboardType="phone-pad" maxLength={11}/>
          <Field label="Delivery address" value={address} onChangeText={setAddress} placeholder="House, street, barangay, municipality" multiline maxLength={240}/>
        </> : null}
        {mode === 'login' ? <Field label="Email address" value={identifier} onChangeText={setIdentifier} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none"/> : null}
        <Field label="Password" value={password} onChangeText={setPassword} placeholder="Enter your password" secureTextEntry autoCapitalize="none"/>
        {mode === 'signup' ? <Field label="Confirm password" value={confirmPassword} onChangeText={setConfirmPassword} placeholder="Re-enter your password" secureTextEntry autoCapitalize="none"/> : null}
        {message ? <View style={[styles.message, styles.error]}><Txt style={styles.messageText}>{message}</Txt></View> : null}
        <Button onPress={submit} disabled={busy} style={styles.submit} icon={busy ? null : 'arrow-forward'}>
          {busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}
        </Button>
        {mode === 'login' ? <Pressable onPress={() => router.push('/forgot-password')} style={styles.switch}><Txt style={styles.switchLink}>Forgot password?</Txt></Pressable> : null}
        <Pressable onPress={() => switchMode(mode === 'login' ? 'signup' : 'login')} style={styles.switch}>
          <Txt style={styles.switchText}>{mode === 'login' ? 'New to FYI-KANTO? ' : 'Already have an account? '}
            <Txt style={styles.switchLink}>{mode === 'login' ? 'Create an account' : 'Log in'}</Txt>
          </Txt>
        </Pressable>
        <Txt style={styles.footnote}>Free test account. Email verification is not required. Use a password accepted by Supabase.</Txt>
      </ScrollView>
    </KeyboardAvoidingView>
  </Page>;
}

function Field({label, value, onChangeText, placeholder, multiline = false, secureTextEntry = false,
  keyboardType = 'default', autoCapitalize = 'sentences', maxLength}) {
  return <View style={styles.field}>
    <Txt style={styles.label}>{label}</Txt>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#9AA79E"
      multiline={multiline} secureTextEntry={secureTextEntry} keyboardType={keyboardType} autoCapitalize={autoCapitalize}
      autoCorrect={false} maxLength={maxLength} style={[styles.input, multiline && styles.textarea]}/>
  </View>;
}

const styles = StyleSheet.create({
  content: {paddingHorizontal: 24, paddingTop: 36, paddingBottom: 30},
  brand: {alignItems: 'center', marginBottom: 35},
  badge: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.mint, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, marginTop: 16},
  badgeText: {fontSize: 12, color: C.green, fontWeight: '800'},
  heading: {fontSize: 27, fontWeight: '900', color: C.forest},
  subheading: {fontSize: 13, color: C.muted, lineHeight: 20, marginTop: 7, marginBottom: 24},
  field: {marginBottom: 15},
  label: {fontSize: 13, fontWeight: '800', marginBottom: 7},
  input: {backgroundColor: C.white, borderWidth: 1, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: C.ink},
  textarea: {minHeight: 82, textAlignVertical: 'top'},
  submit: {marginTop: 7, minHeight: 52},
  switch: {alignItems: 'center', paddingVertical: 17},
  switchText: {fontSize: 13, color: C.muted},
  switchLink: {fontWeight: '900', color: C.green},
  footnote: {fontSize: 11, lineHeight: 17, textAlign: 'center', color: C.muted, marginTop: 4},
  message: {padding: 12, borderRadius: 11, marginBottom: 12},
  success: {backgroundColor: C.mint},
  error: {backgroundColor: '#FFF0F0'},
  messageText: {fontSize: 12, lineHeight: 18, color: C.forest},
  center: {flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14},
  loadingText: {color: C.muted, fontWeight: '700'},
});
