import React, {useMemo} from 'react';
import {FlatList, View, useWindowDimensions} from 'react-native';
import {router, useLocalSearchParams} from 'expo-router';
import {Header, Page, ProductCard, Txt} from '../../components/UI';
import {C} from '../../constants/theme';
import {CATEGORIES, PRODUCTS} from '../../data/products';
import {useApp} from '../../context/AppContext';

export default function CategoryProducts(){
  const {id}=useLocalSearchParams();
  const categoryId=Array.isArray(id)?id[0]:id;
  const category=CATEGORIES.find(item=>item.id===categoryId);
  const {width}=useWindowDimensions();
  const {favorites,productPopularity,productCatalogVersion,toggleFavorite}=useApp();
  const products=useMemo(()=>PRODUCTS.filter(product=>product.category===categoryId),
    [categoryId,productCatalogVersion]);
  const cardWidth=Math.min(225,(Math.min(width,520)-44)/2);
  if(!category)return <Page><Header title="Menu category" onBack={()=>router.back()}/><View style={{padding:20}}><Txt>That category could not be found.</Txt></View></Page>;
  return <Page>
    <Header title={category.label} subtitle={`${products.length} menu items`} onBack={()=>router.back()}/>
    <FlatList
      data={products}
      keyExtractor={product=>product.id}
      numColumns={2}
      columnWrapperStyle={{justifyContent:'space-between'}}
      contentContainerStyle={{paddingHorizontal:16,paddingBottom:30}}
      showsVerticalScrollIndicator={false}
      ListHeaderComponent={<View style={{paddingVertical:8}}>
        <Txt style={{fontSize:12,color:C.muted,lineHeight:19}}>
          Browse the full {category.label} selection. Availability and prices are synchronized with the menu.
        </Txt>
      </View>}
      ListEmptyComponent={<View style={{padding:30,alignItems:'center'}}>
        <Txt style={{color:C.muted}}>There are no items in this category right now.</Txt>
      </View>}
      renderItem={({item})=>{
        const stats=productPopularity.find(entry=>entry.productId===item.id);
        return <ProductCard
          product={item}
          width={cardWidth}
          onPress={()=>router.push(`/product/${item.id}`)}
          onAdd={()=>router.push(`/product/${item.id}`)}
          isFavorite={favorites.includes(item.id)}
          onToggleFavorite={()=>toggleFavorite(item.id)}
          favoriteCount={stats?.favoriteCount||0}
          orderCount={stats?.orderCount||0}
        />;
      }}
    />
  </Page>;
}
