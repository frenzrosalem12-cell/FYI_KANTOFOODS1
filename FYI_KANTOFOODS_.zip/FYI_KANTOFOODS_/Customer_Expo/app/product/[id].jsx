import React, {useEffect, useState} from 'react';
import {Alert, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {router, useLocalSearchParams} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Page, Txt, Photo, Button, Line, Chip} from '../../components/UI';
import {C, money} from '../../constants/theme';
import {ADD_ONS, getCategory, getProduct} from '../../data/products';
import {useApp} from '../../context/AppContext';
export default function ProductDetails(){
 const {id}=useLocalSearchParams(); const product=getProduct(id);const {addToCart,favorites,toggleFavorite,storeStatus,productCatalogVersion}=useApp();
 // Params identify a new screen instance; the hook state defaults to the first size.
 const [size,setSize]=useState(product?.sizes.find(o=>o.label==='Regular')?.label||product?.sizes[0]?.label||'Regular');
 const [variant,setVariant]=useState(product?.variants?.[0]||'');
 const [selected,setSelected]=useState([]);
 const [quantity,setQuantity]=useState(1);
 useEffect(()=>{
   if(product && !product.sizes.some(o=>o.label===size))setSize(product.sizes[0].label);
 },[productCatalogVersion,id]);
 if(!product)return <Page><View style={{padding:20}}><Txt>Product not found.</Txt><Button onPress={()=>router.replace('/(tabs)/menu')}>Back to Menu</Button></View></Page>;
 const options=ADD_ONS[product.addOns]||[];
 const price=product.sizes.find(o=>o.label===size)?.price||product.sizes[0].price;
 const addonTotal=options.filter(o=>selected.includes(o.id)).reduce((n,a)=>n+a.price,0);
 const total=(price+addonTotal)*quantity;
 const toggleAddon=id=>setSelected(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
 const submit=()=>{addToCart({productId:product.id,size,variant,addOnIds:selected,qty:quantity});router.back();};
 const onToggleFavorite=async()=>{
  try{await toggleFavorite(product.id);}
  catch(error){Alert.alert('Favorite not saved',error.message||'Please try again.');}
 };
 return <Page>
 <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:115}}>
  <View style={{height:315,position:'relative',backgroundColor:C.mint}}><Photo productId={product.id} image={product.image} category={product.category} emojiSize={85}/>
   <Pressable style={[styles.round,{left:18}]} onPress={()=>router.back()}><Ionicons name="chevron-back" size={24} color={C.forest}/></Pressable>
   <Pressable accessibilityRole="button" accessibilityLabel={favorites.includes(product.id)?'Remove from favorites':'Add to favorites'} style={[styles.round,{right:18}]} onPress={onToggleFavorite}><Ionicons name={favorites.includes(product.id)?'heart':'heart-outline'} size={23} color={favorites.includes(product.id)?C.red:C.forest}/></Pressable>
  </View>
  <View style={styles.body}>
   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><Txt style={{color:C.green,fontWeight:'900',fontSize:11,letterSpacing:1}}>{getCategory(product.category).label.toUpperCase()}</Txt><View style={{borderRadius:12,backgroundColor:C.mint,paddingHorizontal:12,paddingVertical:6}}><Txt style={{fontSize:13,color:C.green,fontWeight:'900'}}>From {money(product.sizes[0].price)}</Txt></View></View>
   <Txt style={styles.title}>{product.name}</Txt><Txt style={{fontSize:13,color:C.muted,lineHeight:21,marginTop:4}}>{product.description}</Txt>
   <Line/>
   {product.sizes.length>1?<><Txt style={styles.section}>Choose your size</Txt><View style={{flexDirection:'row',gap:8,marginBottom:20}}>{product.sizes.map(o=><Pressable key={o.label} onPress={()=>setSize(o.label)} style={[styles.sizeOption,size===o.label&&styles.sizeSelected]}><Txt style={{fontWeight:'900',color:size===o.label?C.green:C.ink}}>{o.label}</Txt><Txt style={{fontSize:12,marginTop:3,color:C.muted}}>{money(o.price)}</Txt>{size===o.label?<Ionicons name="checkmark-circle" size={16} color={C.green} style={{position:'absolute',top:4,right:4}}/>:null}</Pressable>)}</View></>:null}
   {product.variants?.length?<><Txt style={styles.section}>Choose a flavor</Txt><View style={{flexDirection:'row',flexWrap:'wrap',gap:8,marginBottom:20}}>{product.variants.map(v=><Chip key={v} text={v} active={variant===v} onPress={()=>setVariant(v)}/>)}</View></>:null}
   {options.length>0?<><Txt style={styles.section}>Make it extra special</Txt><Txt style={{fontSize:12,color:C.muted,marginBottom:11}}>Optional add-ons</Txt>{options.map(o=><Pressable key={o.id} onPress={()=>toggleAddon(o.id)} style={styles.addon}><View style={[styles.checkbox,selected.includes(o.id)&&{backgroundColor:C.green,borderColor:C.green}]}>{selected.includes(o.id)?<Ionicons name="checkmark" size={15} color={C.white}/>:null}</View><Txt style={{flex:1,fontWeight:'700'}}>{o.label}</Txt><Txt style={{fontWeight:'800',color:C.green}}>+{money(o.price)}</Txt></Pressable>)}</>:null}
   <View style={{marginTop:23,flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}><View><Txt style={styles.section}>Quantity</Txt><Txt style={{color:C.muted,fontSize:12}}>How many would you like?</Txt></View><View style={styles.qty}><Pressable onPress={()=>setQuantity(q=>Math.max(1,q-1))} style={styles.qtyBtn}><Ionicons name="remove" color={C.forest} size={19}/></Pressable><Txt style={{fontSize:16,fontWeight:'900',minWidth:25,textAlign:'center'}}>{quantity}</Txt><Pressable onPress={()=>setQuantity(q=>Math.min(99,q+1))} style={[styles.qtyBtn,{backgroundColor:C.green}]}><Ionicons name="add" color={C.white} size={19}/></Pressable></View></View>
  </View>
 </ScrollView>
 <View style={styles.footer}><Button disabled={!storeStatus.isOpen} onPress={submit} style={{width:'100%'}}>{storeStatus.isOpen?'Add to Order • '+money(total):'Closed Now • Ordering Unavailable'}</Button></View>
 </Page>
}
const styles=StyleSheet.create({round:{position:'absolute',top:15,width:42,height:42,borderRadius:22,alignItems:'center',justifyContent:'center',backgroundColor:'rgba(255,255,255,0.96)'},body:{paddingHorizontal:20,paddingTop:21},title:{color:C.forest,fontSize:24,fontWeight:'900',marginTop:12,lineHeight:28},section:{fontSize:15,fontWeight:'900',color:C.forest,marginBottom:11},sizeOption:{flex:1,paddingHorizontal:7,paddingVertical:14,borderWidth:1,borderColor:C.border,borderRadius:13,alignItems:'center',backgroundColor:C.white},sizeSelected:{borderWidth:2,borderColor:C.green,backgroundColor:C.paleMint},addon:{flexDirection:'row',alignItems:'center',gap:11,paddingVertical:13,borderBottomWidth:1,borderBottomColor:C.border},checkbox:{height:21,width:21,borderRadius:6,borderWidth:1.5,borderColor:'#A5B5AB',alignItems:'center',justifyContent:'center'},qty:{flexDirection:'row',alignItems:'center',gap:14},qtyBtn:{width:35,height:35,backgroundColor:C.white,borderColor:C.border,borderWidth:1,borderRadius:11,justifyContent:'center',alignItems:'center'},footer:{position:'absolute',bottom:0,left:0,right:0,paddingHorizontal:18,paddingTop:12,paddingBottom:12,borderTopWidth:1,borderTopColor:C.border,backgroundColor:C.white}});
