export const DEMO_REVIEWS = [
  {id:'demo1',name:'Maria S.',rating:5,message:'Super sarap ng cheesy hotdog! Great drinks and quick service.',date:'Demo review',isDemo:true},
  {id:'demo2',name:'Ken T.',rating:5,message:'Love the cookies n cream and the fruit tea!',date:'Demo review',isDemo:true},
  {id:'demo3',name:'Jana P.',rating:4,message:'The fries were crispy. Will order again!',date:'Demo review',isDemo:true},
];
