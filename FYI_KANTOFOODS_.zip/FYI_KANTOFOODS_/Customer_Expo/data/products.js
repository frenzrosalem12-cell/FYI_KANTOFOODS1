// Prices transcribed from the FYI-KANTO complete menu uploaded by the user.
// Please verify with the business before accepting real payments.
export const CATEGORIES = [
  { id:'all', label:'All', icon:'grid-outline', emoji:'🍽️', color:'#E4F4EA' },
  { id:'fruit-tea', label:'Fruit Tea', icon:'leaf-outline', emoji:'🍓', color:'#FFF0F0' },
  { id:'fruit-soda', label:'Fruity Soda', icon:'water-outline', emoji:'🥤', color:'#E6F5FF' },
  { id:'fruit-yakult', label:'Soda + Yakult', icon:'sparkles-outline', emoji:'🍋', color:'#FFF4DB' },
  { id:'fruit-milk', label:'Fruit Milk', icon:'ice-cream-outline', emoji:'🥭', color:'#FFF0D8' },
  { id:'milk-tea', label:'Milktea Shakes', icon:'cafe-outline', emoji:'🧋', color:'#F4EAF9' },
  { id:'premium-milk-tea', label:'Premium Milk Tea', icon:'ribbon-outline', emoji:'🍵', color:'#ECF7E7' },
  { id:'coffee', label:'Coffee Series', icon:'cafe-outline', emoji:'☕', color:'#EEE5DC' },
  { id:'food', label:'Pizza & Street Foods', icon:'pizza-outline', emoji:'🍕', color:'#FFF0DE' },
  { id:'sides', label:'Sides & Extras', icon:'fast-food-outline', emoji:'🍟', color:'#FFF1CC' },
  { id:'bottled', label:'Bottled Drinks', icon:'water-outline', emoji:'🥤', color:'#E6F3FB' },
];
export const ADD_ONS = {
  fruit: [{id:'nata',label:'Nata',price:10},{id:'fruit-jelly',label:'Fruit Jelly',price:10}],
  milktea: [{id:'pearl',label:'Pearl',price:10},{id:'oreo',label:'Oreo',price:15},{id:'grahams',label:'Grahams',price:10}],
  food: [],
};
const size = (label,price)=>({label,price});
const only = (price)=>[size('Regular',price)];
const shake = (s=40,r=60,l=80)=>[size('Small',s),size('Regular',r),size('Large',l)];
const premium = ()=>[size('Regular',75),size('Large',99)];
const fries = ()=>[size('Small',50),size('Regular',75),size('Large',99)];
const prod = (id, name, category, sizes, image, description, addOns='') => ({id,name,category,sizes,image,description,addOns});
export const PRODUCTS = [
  prod('ft-strawberry','Strawberry Fruit Tea','fruit-tea',only(39),'strawberry','Sweet, bright and refreshing.','fruit'),
  prod('ft-blue-lemonade','Blue Lemonade Fruit Tea','fruit-tea',only(39),'lemonade','Zesty citrus with a refreshing finish.','fruit'),
  prod('ft-blueberry','Blueberry Fruit Tea','fruit-tea',only(39),null,'Berry refreshment with a fruity twist.','fruit'),
  prod('ft-four-seasons','Four Seasons Fruit Tea','fruit-tea',only(39),null,'A refreshing tropical fruit blend.','fruit'),
  prod('ft-green-apple','Green Apple Fruit Tea','fruit-tea',only(39),'greenApple','Crisp, tangy and super refreshing.','fruit'),
  ...[['strawberry','Strawberry'],['blue-lemonade','Blue Lemonade'],['blueberry','Blueberry'],['four-seasons','Four Seasons'],['green-apple','Green Apple']].map(([id,label])=>prod('soda-'+id,label+' Fruity Soda','fruit-soda',only(55),null,'Sparkling, fruity and refreshing.','fruit')),
  ...[['strawberry','Strawberry'],['blue-lemonade','Blue Lemonade'],['blueberry','Blueberry'],['four-seasons','Four Seasons'],['green-apple','Green Apple']].map(([id,label])=>prod('yakult-'+id,label+' Soda + Yakult','fruit-yakult',only(69),null,'Fruity soda meets creamy Yakult.','fruit')),
  prod('fm-strawberry','Strawberry Fruit Milk','fruit-milk',only(59),null,'Smooth strawberry and creamy milk.','fruit'),
  prod('fm-blueberry','Blueberry Fruit Milk','fruit-milk',only(59),null,'A creamy berry favorite.','fruit'),
  prod('fm-mango','Mango Fruit Milk','fruit-milk',only(59),'mango','Tropical mango with a creamy finish.','fruit'),
  prod('fm-ube','Ube Fruit Milk','fruit-milk',only(59),'ube','Sweet purple yam with smooth milk.','fruit'),
  prod('mt-cookies','Cookies N Cream Milktea Shake','milk-tea',shake(42,65,90),'cookies','Creamy cookies and cream goodness.','milktea'),
  prod('mt-choco','Choco Kisses Milktea Shake','milk-tea',shake(42,65,90),'choco','Chocolatey, creamy and sweet.','milktea'),
  prod('mt-black-forest','Black Forest Milktea Shake','milk-tea',shake(42,65,90),null,'Chocolate-inspired shake with a rich finish.','milktea'),
  prod('mt-ube','Ube Macapuno Milktea Shake','milk-tea',shake(),null,'A creamy ube-inspired classic.','milktea'),
  prod('mt-taro','Taro Milktea Shake','milk-tea',shake(),null,'Classic taro flavor in every sip.','milktea'),
  prod('mt-strawberry','Strawberry Milktea Shake','milk-tea',shake(),null,'A fun strawberry milk tea favorite.','milktea'),
  prod('premium-cookies','Cookies N Cream Premium Milk Tea','premium-milk-tea',premium(),null,'Rich premium milk tea with cookie notes.','milktea'),
  prod('premium-matcha','Matcha Premium Milk Tea','premium-milk-tea',premium(),'matcha','Smooth, earthy matcha milk tea.','milktea'),
  prod('premium-red-velvet','Red Velvet Premium Milk Tea','premium-milk-tea',premium(),'redVelvet','Sweet and creamy red velvet-inspired milk tea.','milktea'),
  prod('premium-winter-melon','Winter Melon Premium Milk Tea','premium-milk-tea',premium(),null,'A mellow sweet milk tea classic.','milktea'),
  prod('premium-taro','Taro Premium Milk Tea','premium-milk-tea',premium(),null,'Rich, creamy taro milk tea.','milktea'),
  prod('coffee-espresso','Kape Espresso','coffee',only(59),'espresso','Bold and creamy iced coffee.'),
  prod('coffee-americano','Kape Americano','coffee',only(59),null,'A smooth iced coffee to perk you up.'),
  prod('coffee-spanish','Spanish Latte','coffee',only(69),'spanish','Sweet espresso with milk.'),
  prod('coffee-matcha','Iced Coffee with Matcha','coffee',only(69),'coffeeMatcha','Coffee meets matcha for a refreshing blend.'),
  prod('food-pizza','Italian Cheese Pizza','food',only(150),'pizza','Melty, cheesy pizza, made for sharing.'),
  prod('food-siomai','Siomai · 3 PCS','food',only(25),'siomai','Choose beef, pork, chicken or Japanese style.'),
  prod('food-lumpia','Lumpia · Per Piece','food',only(8),'lumpia','Crispy chicken, beef or pork lumpia.'),
  prod('food-tempura','Tempura · 4 PCS','food',only(25),null,'Fish or shrimp tempura, crispy and tasty.'),
  prod('food-pater','Chicken Pater','food',only(30),'pater','Savory chicken over warm rice.'),
  prod('food-hotdog','Cheesy Hotdog','food',only(50),'hotdog','Juicy hotdog with melted cheese and sauce.'),
  prod('side-lumpia','Lumpia · 1 Dozen','sides',only(85),'lumpia','Share a dozen crispy lumpia.'),
  prod('side-rice','Rice','sides',only(15),'rice','Freshly cooked rice.'),
  prod('side-fries','Fries','sides',fries(),'fries','Golden and crispy fries.'),
  prod('bottle-coke-swakto','Coke Swakto','bottled',only(20),null,'Cold cola.'),
  prod('bottle-coke-mismo','Coke Mismo','bottled',only(25),null,'Cold cola.'),
  prod('bottle-water','Mineral Water · 500 ML','bottled',only(20),null,'Refreshing mineral water.'),
];
export const FEATURED = ['food-hotdog','mt-cookies','ft-strawberry','fm-mango','food-pizza','premium-matcha'];
export const getProduct = id => PRODUCTS.find(p=>p.id===id);
export const getCategory = id => CATEGORIES.find(c=>c.id===id) || CATEGORIES[0];
export const productBasePrice = p => p.sizes[0].price;
const optionsForFood = {
 'food-siomai':['Beef','Pork','Chicken','Japanese'],
 'food-lumpia':['Chicken','Beef','Pork'],
 'side-lumpia':['Chicken','Beef','Pork'],
 'food-tempura':['Fish','Shrimp'],
};
for (const item of PRODUCTS) if (optionsForFood[item.id]) item.variants = optionsForFood[item.id];


// One shared runtime catalog for native Expo and Expo Web. Prices and availability
// come from the Node API; built-in data only serves as offline/demo fallback.
export function applyServerCatalog(result){
  if(!result || !Array.isArray(result.products))return false;
  const incoming=result.products.filter(p=>p && typeof p.id==='string' &&
    typeof p.name==='string' && Array.isArray(p.sizes) && p.sizes.length>0);
  const changed=JSON.stringify(PRODUCTS)!==JSON.stringify(incoming);
  if(changed)PRODUCTS.splice(0,PRODUCTS.length,...incoming);
  return changed;
}
