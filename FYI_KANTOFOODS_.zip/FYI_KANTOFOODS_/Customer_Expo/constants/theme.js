export const C = {
  forest: '#143B2D',
  forestDark: '#0B2A20',
  green: '#087B57',
  emerald: '#009B70',
  mint: '#E5F4EB',
  paleMint: '#F0F8F3',
  cream: '#F8F8F2',
  white: '#FFFFFF',
  ink: '#17342B',
  muted: '#78877E',
  border: '#E5EDE5',
  yellow: '#FFC343',
  orange: '#F38C36',
  red: '#E65C59',
  blue: '#3A90D5',
  shadow: '#133D29',
};
export const money = (n) => `₱${Number(n || 0).toLocaleString('en-PH', {maximumFractionDigits: 0})}`;
export const shadow = {shadowColor:'#18362B', shadowOffset:{width:0,height:4}, shadowOpacity:0.08, shadowRadius:12, elevation:2};
