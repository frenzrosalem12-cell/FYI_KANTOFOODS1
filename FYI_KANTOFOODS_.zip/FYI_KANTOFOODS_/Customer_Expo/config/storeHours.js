// EDIT THESE TIMES to match the actual FYI-KANTO operating hours.
// User-requested schedule: 8:00 AM - 8:00 PM every day (confirm with the store before launch).
// Uses Philippine local time (Asia/Manila, UTC+8).
// Days: 0=Sunday, 1=Monday, ... 6=Saturday.
// Set a day to null to close on that day.
export const STORE_HOURS = {
  0: {open:'08:00',close:'20:00'},
  1: {open:'08:00',close:'20:00'},
  2: {open:'08:00',close:'20:00'},
  3: {open:'08:00',close:'20:00'},
  4: {open:'08:00',close:'20:00'},
  5: {open:'08:00',close:'20:00'},
  6: {open:'08:00',close:'20:00'},
};

// For a temporary closure or special opening, change null to 'closed' or 'open'.
// This is a CODE-LEVEL DEMO override, NOT a synced admin setting.
export const STORE_STATUS_OVERRIDE = null; // null | 'open' | 'closed'

function toMinutes(time) {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time||'')) return null;
  const [h,m]=time.split(':').map(Number);
  return h*60+m;
}
function formatTime(s) {
  const m=toMinutes(s);
  if(m===null)return s;
  const h=Math.floor(m/60);
  return `${h%12||12}:${String(m%60).padStart(2,'0')} ${h<12?'AM':'PM'}`;
}

export function getStoreStatus(now=new Date()) {
  // Philippines currently uses UTC+8 and does not observe daylight saving time.
  // UTC components of a shifted Date safely yield the Philippine weekday/time,
  // regardless of the device's configured timezone.
  const manila=new Date(now.getTime()+8*60*60*1000);
  const day=manila.getUTCDay();
  const minute=manila.getUTCHours()*60+manila.getUTCMinutes();
  const today=STORE_HOURS[day];
  const yesterday=STORE_HOURS[(day+6)%7];
  let withinSchedule=false;
  const fromPrev= yesterday && toMinutes(yesterday.close)!==null && toMinutes(yesterday.open)!==null
    && toMinutes(yesterday.close) < toMinutes(yesterday.open)
    && minute < toMinutes(yesterday.close);
  if(today && toMinutes(today.open)!==null && toMinutes(today.close)!==null){
    const start=toMinutes(today.open);const end=toMinutes(today.close);
    withinSchedule=(start===end?false:start<end?(minute>=start&&minute<end):(minute>=start));
  }
  withinSchedule=withinSchedule||Boolean(fromPrev);
  const isOpen=STORE_STATUS_OVERRIDE==='open'?true:STORE_STATUS_OVERRIDE==='closed'?false:withinSchedule;
  const todayHours=today?`${formatTime(today.open)} – ${formatTime(today.close)}`:'Closed all day';
  return {isOpen, label:isOpen?'Open Now':'Closed Now', todayHours,
    message:isOpen?'Accepting orders for delivery and dine-in':'We are currently closed. Please check back during opening hours.',
    isOverride:STORE_STATUS_OVERRIDE!==null};
}
