// DEMO ONLY. Replace with the exact FYI-KANTO store entrance pin before real use.
// Coordinates below point to the USTP Jasaan campus area, not your business.
// Source: OpenStreetMap/Mapcarta USTP-Jasaan campus (8.65484, 124.75370).
export const STORE = {
  name: 'FYI-KANTO (DEMO: USTP Jasaan Campus)',
  latitude: 8.65484,
  longitude: 124.75370,
  isExactStorePin: false,
};

export const DELIVERY_RATES = {
  freeBelowKm: 1,
  firstPaidKmFee: 15,
  addedFeePerExtraKm: 10,
};

// Road distance gets rounded to 0.01km for both display and fee tier.
// 0.00–0.99km = ₱0; 1.00–1.99km = ₱15; 2.00–2.99km = ₱25; etc.
export function roundKm(km) {
  if (!Number.isFinite(km) || km < 0) return null;
  return Math.round((km + Number.EPSILON) * 100) / 100;
}
export function calculateDeliveryFee(distanceKm) {
  const km = roundKm(distanceKm);
  if (km === null) return null;
  if (km < DELIVERY_RATES.freeBelowKm) return 0;
  const extraFullKm = Math.floor(km - DELIVERY_RATES.freeBelowKm);
  return DELIVERY_RATES.firstPaidKmFee + extraFullKm * DELIVERY_RATES.addedFeePerExtraKm;
}

// Public demo route API. Use your own licensed routing backend for production;
// this demo endpoint has no guaranteed uptime, quota, or SLA.
export const DEMO_ROUTE_BASE_URL = 'https://router.project-osrm.org/route/v1/driving/';
