// Customer Expo and QR browser use exactly the same React Native/Expo UI.
// Native: EXPO_PUBLIC_API_URL=http://LAPTOP_WIFI_IP:3333 from Customer_Expo/.env
// Browser: resolve API using the web address, so the QR link stays connected.
// Never put a Supabase secret/service-role key in any EXPO_PUBLIC variable.
import {Platform} from 'react-native';

const nativeApi=(process.env.EXPO_PUBLIC_API_URL || '').trim().replace(/\/$/, '');
let url=nativeApi;
if(Platform.OS==='web' && typeof window!=='undefined') {
  // Expo dev preview uses :8081/:8082/:19000/:19006; the API remains on laptop port 3333.
  // Compiled QR build is hosted by Node at :3333, so use the same origin.
  const {origin,hostname,protocol,port}=window.location;
  const webApi=(process.env.EXPO_PUBLIC_WEB_API_URL || '').trim();
  url=webApi || (['8081','8082','19000','19006'].includes(port)
    ? `${protocol}//${hostname}:3333` : origin);
}
export const BACKEND_BASE_URL=url;
export const CONNECTED_MODE=Boolean(url);

export async function backendRequest(endpoint,options={}) {
  if(!CONNECTED_MODE)throw Error('The customer app is offline. Set EXPO_PUBLIC_API_URL in Customer_Expo/.env, restart Expo, and run the Node backend.');
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),18000);
  try {
    const response=await fetch(BACKEND_BASE_URL+endpoint,{...options,signal:controller.signal});
    let result;
    try {result=await response.json();}catch{throw Error('The backend returned an invalid response. Check the API URL.');}
    if(!response.ok)throw Error(result.error||'Unable to reach FYI-KANTO server.');
    return result;
  } catch(error) {
    if(error?.name==='AbortError')throw Error('Server timed out. Check your Wi-Fi and backend connection.');
    throw error;
  }finally{clearTimeout(timer);}
}
