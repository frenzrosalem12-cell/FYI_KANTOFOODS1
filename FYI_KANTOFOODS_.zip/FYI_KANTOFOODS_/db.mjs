import 'dotenv/config';
import {createClient} from '@supabase/supabase-js';
import crypto from 'node:crypto';

const url=process.env.SUPABASE_URL?.trim();
const key=process.env.SUPABASE_SECRET_KEY?.trim();
let customerEmailCache={expiresAt:0,usersById:new Map()};
export function checkConfig(){
 if(!url||!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url)||!key||(!key.startsWith('sb_secret_')&&!key.startsWith('eyJ'))||key.includes('REPLACE')) {
  throw Error('Missing Supabase credentials. Copy .env.example to .env and set SUPABASE_URL and SUPABASE_SECRET_KEY.');
 }
}
checkConfig();
export const supabase=createClient(url,key,{auth:{autoRefreshToken:false,persistSession:false,detectSessionInUrl:false}});
export async function createCustomerAccount({email,password,username,phone,address}){
 const normalizedEmail=String(email).trim().toLowerCase();
 const normalizedUsername=String(username).trim().toLowerCase();
 const existing=unwrap(await supabase.from('profiles').select('id')
  .ilike('username',normalizedUsername.replace(/_/g,'\\_')).limit(1));
 if(existing.length)throw Object.assign(Error('That username is already taken. Choose another username.'),{status:409});

 const {data,error}=await supabase.auth.admin.createUser({
  email:normalizedEmail,
  password,
  email_confirm:true,
  user_metadata:{
   username:normalizedUsername,
   full_name:normalizedUsername,
   phone:phone.trim(),
   address:address.trim()
  }
 });
 if(error){
  if(/already.*registered|already.*exists|duplicate/i.test(error.message))
   throw Object.assign(Error('This email already has an account. Log in or use Forgot password.'),{status:409});
  throw Object.assign(Error(error.message||'Supabase could not create the customer account.'),{status:error.status>=400&&error.status<500?400:503});
 }
 const user=data.user;
 if(!user?.id)throw Object.assign(Error('Supabase did not return the new customer account.'),{status:503});

 const {error:profileError}=await supabase.from('profiles').upsert({
  id:user.id,
  username:normalizedUsername,
  full_name:normalizedUsername,
  phone:phone.trim(),
  address:address.trim(),
  updated_at:new Date().toISOString()
 },{onConflict:'id'});
 if(profileError){
  const {error:rollbackError}=await supabase.auth.admin.deleteUser(user.id);
  if(rollbackError)console.error('Unable to roll back incomplete customer account:',rollbackError.message);
  if(profileError.code==='23505')
   throw Object.assign(Error('That username is already taken. Choose another username.'),{status:409});
  console.error('Unable to save new customer profile:',profileError.message);
  throw Object.assign(Error('Customer profile could not be saved. Check the Supabase customer profile schema and try again.'),{status:503});
 }
 return {id:user.id,email:user.email};
}
export async function customerFromToken(token){
 if(typeof token!=='string'||!token)return null;
 const {data,error}=await supabase.auth.getUser(token);
 if(error){
  if([401,403].includes(error.status))return null;
  throw Error('Unable to verify the customer session with Supabase.');
 }
 return data.user||null;
}
export async function customerProfile(customerId){
 const rows=unwrap(await supabase.from('profiles')
  .select('id,email,username,full_name,phone,address,avatar_path')
  .eq('id',customerId).limit(1));
 return rows[0]||null;
}
export async function customerFavorites(customerId){
 return unwrap(await supabase.from('fyi_customer_favorites')
  .select('product_id').eq('customer_id',customerId))
  .map(row=>row.product_id);
}
export async function setCustomerFavorite(customerId,productId,favorite){
 if(favorite){
  unwrap(await supabase.from('fyi_customer_favorites')
   .upsert({customer_id:customerId,product_id:productId},{onConflict:'customer_id,product_id'}));
 }else{
  unwrap(await supabase.from('fyi_customer_favorites')
   .delete().eq('customer_id',customerId).eq('product_id',productId));
 }
 return true;
}
export async function productPopularity(){
 return unwrap(await supabase.from('fyi_product_popularity')
  .select('product_id,favorite_count,order_count'))
  .map(row=>({
   productId:row.product_id,
   favoriteCount:Number(row.favorite_count),
   orderCount:Number(row.order_count)
  }));
}
export async function requestCustomerPasswordReset(username,redirectTo){
 const normalized=String(username||'').trim().toLowerCase();
 const rows=unwrap(await supabase.from('profiles').select('id')
  .ilike('username',normalized.replace(/_/g,'\\_')).limit(1));
 if(!rows.length)return false;
 const {data,error}=await supabase.auth.admin.getUserById(rows[0].id);
 if(error){
  if(error.status===404)return false;
  throw Error('Unable to verify the customer account with Supabase.');
 }
 const user=data.user;
 if(!user?.email||!user.email_confirmed_at||
    user.email.endsWith('@accounts.fyi-kanto.invalid'))return false;
 const {error:resetError}=await supabase.auth.resetPasswordForEmail(user.email,{redirectTo});
 if(resetError)throw Error('Unable to send the password reset email. Check Supabase email delivery settings.');
 return true;
}
export const sha256=v=>crypto.createHash('sha256').update(v).digest('hex');
export const newId=()=>crypto.randomUUID();
export const nonce=()=>crypto.randomBytes(24).toString('hex');
export const hashPassword=(s,salt)=>crypto.scryptSync(s,salt,64).toString('hex');
export function passwordMatches(secret,staff){
 // staffFromRow wraps the sensitive password hash under `secret`.
 // The login check must read that shape; otherwise every login is rejected.
 const salt=staff?.secret?.salt;
 const savedHash=staff?.secret?.hash;
 if(!salt||!savedHash||!secret)return false;
 const got=Buffer.from(hashPassword(secret,salt),'hex'),want=Buffer.from(savedHash,'hex');
 return got.length===want.length&&crypto.timingSafeEqual(got,want);
}
export function unwrap(result){
 if(result.error)throw Error('Supabase database operation failed: '+result.error.message);
 return result.data;
}
export async function preflight(){
 unwrap(await supabase.from('fyi_store_settings').select('id').eq('id',1).single());
 unwrap(await supabase.from('fyi_orders').select('id').limit(1));
 return true;
}
export async function settings(){
 const a=unwrap(await supabase.from('fyi_store_settings').select('*').eq('id',1).single());
 return {
  open:a.open_time,close:a.close_time,override:a.override,location:a.location,
  menuCategories:Array.isArray(a.menu_categories)?a.menu_categories:[],
  menuAddons:Array.isArray(a.menu_addons)?a.menu_addons:[]
 };
}
export async function saveSettings(s){
 const a=unwrap(await supabase.from('fyi_store_settings').update({open_time:s.open,close_time:s.close,override:s.override,updated_at:new Date().toISOString()}).eq('id',1).select().single());
 return {open:a.open_time,close:a.close_time,override:a.override,location:a.location};
}
export function staffFromRow(a){return a?{id:a.id,role:a.role,name:a.name,username:a.username,active:a.active,secret:{salt:a.salt,hash:a.password_hash}}:null;}
export async function staffByRole(role,username){
 let query=supabase.from('fyi_staff').select('*').eq('role',role).eq('active',true);
 if(username)query=query.eq('username',username);
 const data=unwrap(await query.limit(1));return staffFromRow(data[0]);
}
export async function staffById(id){
 const rows=unwrap(await supabase.from('fyi_staff').select('*').eq('id',id).eq('active',true).limit(1));return staffFromRow(rows[0]);
}
export async function listStaff(){
 return unwrap(await supabase.from('fyi_staff').select('id,name,role,username,active').order('created_at'));
}
export async function insertStaffBatch(rows){
 return unwrap(await supabase.from('fyi_staff').insert(rows).select('id'));
}
export async function insertStaff({id,role,name,username,salt,password_hash,active=true}){
 return unwrap(await supabase.from('fyi_staff').insert({id,role,name,username,salt,password_hash,active}).select('id').single());
}
export function orderFromRow(a){
 if(!a)return null;
 return {id:a.id,type:a.order_type,status:a.status,paymentStatus:a.payment_status,paymentMethod:a.payment_method,
 customerId:a.customer_id,paymentReference:a.payment_reference,paymentUrl:a.payment_checkout_url,
 customer:a.customer,items:a.items,subtotal:Number(a.subtotal),deliveryFee:Number(a.delivery_fee),roadKm:a.road_km===null?null:Number(a.road_km),
 total:Number(a.total),createdAt:a.created_at,updatedAt:a.updated_at,gcashReference:a.gcash_reference,reviewed:a.reviewed,
 history:a.history,proofPath:a.proof_path,proofMime:a.proof_mime};
}
export async function getOrder(id){
 const a=unwrap(await supabase.from('fyi_orders').select('*').eq('id',id).limit(1));return orderFromRow(a[0]);
}
export async function getOrderByPaymentReference(reference){
 if(typeof reference!=='string'||!reference)return null;
 const rows=unwrap(await supabase.from('fyi_orders').select('*').eq('payment_reference',reference).limit(1));
 return orderFromRow(rows[0]);
}
export async function getOrderByToken(id,token){
 if(typeof id!=='string'||typeof token!=='string'||!id||!token||token.length>300)return null;
 const a=unwrap(await supabase.from('fyi_orders').select('*').eq('id',id).eq('tracking_hash',sha256(token)).limit(1));return orderFromRow(a[0]);
}
export async function orders(){
 // Up to 1000 rows per demo; add pagination before production use.
 return unwrap(await supabase.from('fyi_orders').select('*').order('created_at',{ascending:false}).limit(1000)).map(orderFromRow);
}
export async function customerSummaries(){
 const customers=unwrap(await supabase.from('customerfyi_list').select('*')
  .order('account_created_at',{ascending:false}).limit(5000));
 if(customerEmailCache.expiresAt<=Date.now()){
  const usersById=new Map();
  for(let page=1;page<=5;page++){
   const {data,error}=await supabase.auth.admin.listUsers({page,perPage:1000});
   if(error)throw Error('Unable to load customer emails for the admin customer list: '+error.message);
   for(const user of data.users)usersById.set(user.id,user.email||'');
   if(data.users.length<1000)break;
  }
  customerEmailCache={expiresAt:Date.now()+60_000,usersById};
 }
 return customers.map(customer=>({
  id:customer.customer_id,username:customer.username||customer.full_name||'Customer',
  email:(customerEmailCache.usersById.get(customer.customer_id)||'').endsWith('@accounts.fyi-kanto.invalid')?'':customerEmailCache.usersById.get(customer.customer_id)||'',
  phone:customer.phone,address:customer.address,createdAt:customer.account_created_at,
  orders:Number(customer.order_count),paidOrders:Number(customer.paid_order_count),
  totalSpent:Number(customer.total_spent)
 }));
}
export async function paymentTransactions(){
 return unwrap(await supabase.from('paymentfyi_list').select('*')
  .order('created_at',{ascending:false}).limit(1000));
}
export async function recentPaymentTransactions(limit=8){
 return unwrap(await supabase.from('paymentfyi_list').select('*')
  .order('created_at',{ascending:false}).limit(limit));
}
async function exactCount(query){
 const {count,error}=await query;
 if(error)throw Error('Supabase database operation failed: '+error.message);
 return Number(count||0);
}
async function fetchStaffRows(queryFactory){
 const rows=[];
 for(let offset=0;offset<20000;offset+=1000){
  const page=unwrap(await queryFactory().range(offset,offset+999));
  rows.push(...page);
  if(page.length<1000)return rows;
 }
 throw Error('Dashboard query exceeded the safe 20,000-row limit.');
}
function bucketFallbackRows(rows,period='range'){
 const map=new Map();
 for(const order of rows){
  const date=new Date(order.created_at);if(Number.isNaN(date.getTime()))continue;
  const bucket=new Date(date);bucket.setUTCMinutes(0,0,0);
  const key=bucket.toISOString();const current=map.get(key)||{bucket:key,orders:0,sales:0};
  current.orders+=1;if(order.payment_status==='paid')current.sales+=Number(order.total||0);map.set(key,current);
 }
 return [...map.values()].sort((a,b)=>a.bucket.localeCompare(b.bucket));
}
async function staffDashboardAnalyticsFallback({start,end,todayStart,now}){
 // Fallback for missing, stale, or misconfigured analytics views: aggregate from source orders.
 const orders=await fetchStaffRows(()=>supabase.from('fyi_orders').select('id,created_at,total,status,payment_status,items'));
 const paid=orders.filter(o=>o.payment_status==='paid');
 const rangeOrders=orders.filter(o=>o.created_at>=start&&o.created_at<end);
 const rangePaid=rangeOrders.filter(o=>o.payment_status==='paid');
 const todayPaid=paid.filter(o=>o.created_at>=todayStart&&o.created_at<now);
 const salesBuckets=bucketFallbackRows(rangePaid).map(row=>({bucket:row.bucket,orders:row.orders,sales:row.sales}));
 const orderBuckets=bucketFallbackRows(rangeOrders).map(row=>({bucket:row.bucket,orders:row.orders}));
 const productMap=new Map();
 for(const order of paid){for(const item of (Array.isArray(order.items)?order.items:[])){
  const id=item.productId||item.product_id;if(!id)continue;
  const p=productMap.get(id)||{productId:id,name:item.name||item.productName||'Menu item',quantitySold:0,orderCount:0};
  const qty=Number(item.qty||0);p.quantitySold+=Number.isFinite(qty)?qty:0;p.orderCount+=1;productMap.set(id,p);
 }}
 const totalSales=paid.reduce((sum,o)=>sum+Number(o.total||0),0);
 const statusCounts=orders.filter(o=>o.created_at>=todayStart&&o.created_at<now).reduce((counts,o)=>{counts[o.status]=(counts[o.status]||0)+1;return counts;},{});
 const todaySales=todayPaid.reduce((sum,o)=>sum+Number(o.total||0),0);
 const totalTransactions=await exactCount(supabase.from('fyi_payment_transactions').select('id',{count:'exact',head:true}));
 return {salesSeries:salesBuckets,orderSeries:orderBuckets,bestSelling:[...productMap.values()].sort((a,b)=>b.quantitySold-a.quantitySold).slice(0,10),todaySales,today:{orderCount:orders.filter(o=>o.created_at>=todayStart&&o.created_at<now).length,statusCounts},totalOrders:orders.length,totalTransactions,totalSales,paidOrderCount:paid.length,recentTransactions:await recentPaymentTransactions()};
}
export async function staffDashboardAnalytics({start,end,todayStart,now,period}){
 // For week graph, aggregate from authoritative orders directly; the Supabase hourly views
 // can return no rows without throwing, which previously produced an empty weekly chart.
 if(period==='week')return staffDashboardAnalyticsFallback({start,end,todayStart,now});
 try{
  const [salesSeries,todaySalesSeries,orderSeries,productSales,salesSummary,todayRows,totalOrders,totalTransactions,recentTransactions]=
   await Promise.all([
    supabase.from('fyi_staff_sales_hourly').select('bucket,paid_order_count,sales_total')
     .gte('bucket',start).lt('bucket',end).order('bucket'),
    supabase.from('fyi_staff_sales_hourly').select('sales_total')
     .gte('bucket',todayStart).lt('bucket',now),
    supabase.from('fyi_staff_orders_hourly').select('bucket,order_count')
     .gte('bucket',start).lt('bucket',end).order('bucket'),
    supabase.from('fyi_staff_product_sales').select('product_id,product_name,quantity_sold,order_count')
     .order('quantity_sold',{ascending:false}).limit(10),
    supabase.from('fyi_staff_sales_summary').select('paid_order_count,total_sales').single(),
    fetchStaffRows(()=>supabase.from('fyi_orders').select('status')
     .gte('created_at',todayStart).lt('created_at',now).order('created_at')),
    exactCount(supabase.from('fyi_orders').select('id',{count:'exact',head:true})),
    exactCount(supabase.from('fyi_payment_transactions').select('id',{count:'exact',head:true})),
    recentPaymentTransactions()
   ]);
  const statusCounts=todayRows.reduce((counts,row)=>{counts[row.status]=(counts[row.status]||0)+1;return counts;},{});
  return {
   salesSeries:unwrap(salesSeries).map(row=>({bucket:row.bucket,orders:Number(row.paid_order_count),sales:Number(row.sales_total)})),
   orderSeries:unwrap(orderSeries).map(row=>({bucket:row.bucket,orders:Number(row.order_count)})),
   bestSelling:unwrap(productSales).map(row=>({productId:row.product_id,name:row.product_name,quantitySold:Number(row.quantity_sold),orderCount:Number(row.order_count)})),
   todaySales:unwrap(todaySalesSeries).reduce((sum,row)=>sum+Number(row.sales_total),0),
   today:{orderCount:todayRows.length,statusCounts},totalOrders,totalTransactions,
   totalSales:Number(unwrap(salesSummary).total_sales),paidOrderCount:Number(unwrap(salesSummary).paid_order_count),recentTransactions
  };
 }catch(error){
  console.warn('Staff analytics views unavailable; using direct order data fallback:',error.message);
  return staffDashboardAnalyticsFallback({start,end,todayStart,now});
 }
}

export async function menuConfiguration(){
 const row=unwrap(await supabase.from('fyi_store_settings')
  .select('menu_categories,menu_addons').eq('id',1).single());
 return {
  categories:Array.isArray(row.menu_categories)?row.menu_categories:[],
  addons:Array.isArray(row.menu_addons)?row.menu_addons:[]
 };
}
export async function saveMenuCategories(categories){
 unwrap(await supabase.from('fyi_store_settings').update({
  menu_categories:categories,updated_at:new Date().toISOString()
 }).eq('id',1).select('id').single());
 return categories;
}
export async function saveMenuAddons(addons){
 unwrap(await supabase.from('fyi_store_settings').update({
  menu_addons:addons,updated_at:new Date().toISOString()
 }).eq('id',1).select('id').single());
 return addons;
}
export async function insertOrder(a,token){
 const row={id:a.id,tracking_hash:sha256(token),order_type:a.type,status:a.status,payment_status:a.paymentStatus,
 customer_id:a.customerId||null,payment_method:a.paymentMethod,payment_reference:a.paymentReference||null,
 payment_checkout_url:a.paymentUrl||null,customer:a.customer,items:a.items,subtotal:a.subtotal,delivery_fee:a.deliveryFee,
 road_km:a.roadKm,total:a.total,created_at:a.createdAt,updated_at:a.updatedAt,gcash_reference:a.gcashReference||'',
 proof_path:a.proofPath||null,proof_mime:a.proofMime||null,history:a.history,reviewed:false};
 unwrap(await supabase.from('fyi_orders').insert(row));
 if(a.paymentMethod==='paymongo'){
  try{
   unwrap(await supabase.from('fyi_payment_transactions').insert({
    order_id:a.id,customer_id:a.customerId||null,provider:'paymongo',
    payment_reference:a.paymentReference,amount_minor:Math.round(a.total*100),
    currency:'PHP',status:a.paymentStatus,payment_url:a.paymentUrl||null,
    created_at:a.createdAt,updated_at:a.updatedAt
   }));
  }catch(error){
   const rollback=await supabase.from('fyi_orders').delete()
    .eq('id',a.id).eq('tracking_hash',sha256(token)).select('id');
   if(rollback.error)throw Error(`Payment transaction could not be saved and the pending order could not be rolled back: ${rollback.error.message}`);
   throw error;
  }
 }
}
export async function markPayMongoOrderPaid(order){
 if(!order||order.paymentMethod!=='paymongo')return null;
 let updated=order;
 if(order.paymentStatus!=='paid'){
  const stamp=new Date().toISOString();
  const history=[...(order.history||[]),{at:stamp,status:'pending_acceptance',actor:'paymongo',description:'Payment confirmed by PayMongo webhook'}];
  const rows=unwrap(await supabase.from('fyi_orders').update({
   status:'pending_acceptance',payment_status:'paid',updated_at:stamp,history
  }).eq('id',order.id).eq('payment_reference',order.paymentReference)
    .eq('status','pending_payment').eq('payment_status','pending_payment').select('*'));
  if(rows.length===1)updated=orderFromRow(rows[0]);
  else {
   const latest=await getOrder(order.id);
   if(latest?.paymentStatus!=='paid')throw Error('PayMongo payment could not be applied to this order.');
   updated=latest;
  }
 }
 const stamp=new Date().toISOString();
 const transaction=unwrap(await supabase.from('fyi_payment_transactions').update({
  status:'paid',updated_at:stamp
 }).eq('order_id',order.id).eq('payment_reference',order.paymentReference).select('id'));
 if(transaction.length!==1)throw Error('Payment transaction record could not be updated.');
 return updated;
}
export async function updateOrderStatus(order,update){
 const stamp=new Date().toISOString();
 const history=[...(order.history||[]),{at:stamp,status:update.to,actor:update.actor,description:update.description}];
 const values={status:update.to,updated_at:stamp,history};
 if(update.paymentStatus)values.payment_status=update.paymentStatus;
 const rows=unwrap(await supabase.from('fyi_orders').update(values).eq('id',order.id).eq('status',order.status).select('*'));
 if(rows.length===0)throw Object.assign(Error('Another staff member already updated this order. Refresh first.'),{status:409});
 return orderFromRow(rows[0]);
}
export async function reviews(includeUnapproved=false){
 let query=supabase.from('fyi_reviews').select('*').order('created_at',{ascending:false}).limit(300);
 if(!includeUnapproved)query=query.eq('approved',true);
 return unwrap(await query).map(a=>({
  id:a.id,name:a.name,rating:a.rating,message:a.message,at:a.created_at,
  orderId:a.order_id,approved:a.approved,productName:a.product_name||null,
  reviewType:a.review_type||'general',productId:a.product_id||null
 }));
}
export async function addCustomerReview({name,productName,rating,message}){
 const {data,error}=await supabase.from('fyi_reviews').insert({
  id:newId(),order_id:null,review_type:'general',name,product_name:productName||null,rating,message,approved:true
 }).select('id,name,product_name,rating,message,approved,created_at,order_id').single();
 if(error)throw Object.assign(Error('Unable to save review to Supabase: '+error.message),{status:503});
 return {
  id:data.id,name:data.name,productName:data.product_name||null,rating:data.rating,
  message:data.message,approved:data.approved,at:data.created_at,orderId:data.order_id
 };
}
export async function submitOrderFeedback(customerId,orderId,feedback){
 const order=await getOrder(orderId);
 if(!order||order.customerId!==customerId)
  throw Object.assign(Error('Paid order not found for this customer.'),{status:404});
 if(order.paymentStatus!=='paid'||order.status==='rejected')
  throw Object.assign(Error('Reviews are available after PayMongo confirms payment.'),{status:409});
 if(order.reviewed)
  throw Object.assign(Error('A review has already been submitted for this order.'),{status:409});
 if(!Array.isArray(feedback)||feedback.length<3||feedback.length>20)
  throw Object.assign(Error('Complete the product, delivery, and customer service ratings.'),{status:400});

 const purchased=new Set((order.items||[]).map(item=>String(item.productId||'')));
 const seen=new Set();
 const rows=feedback.map(entry=>{
  const reviewType=String(entry?.reviewType||'');
  const productId=reviewType==='product'?String(entry?.productId||''):'';
  const key=reviewType==='product'?`${reviewType}:${productId}`:reviewType;
  const rating=reviewType==='overall'&&entry?.rating==null?null:Number(entry?.rating);
  const rawMessage=String(entry?.message||'').trim();
  const message=rawMessage.slice(0,500);
  if(!['product','delivery','service','overall'].includes(reviewType)||
     seen.has(key)||rawMessage.length>500||
     (reviewType==='product'&&!purchased.has(productId))||
     (reviewType!=='overall'&&(!Number.isInteger(rating)||rating<1||rating>5))||
     (reviewType==='overall'&&rating!==null&&(!Number.isInteger(rating)||rating<1||rating>5)))
   throw Object.assign(Error('One or more review fields are invalid.'),{status:400});
  seen.add(key);
  const purchasedItem=(order.items||[]).find(item=>String(item.productId)===productId);
  return {
   id:newId(),customer_id:customerId,order_id:order.id,review_type:reviewType,
   product_id:productId||null,name:String(order.customer?.name||'Customer').slice(0,70),
   product_name:reviewType==='product'
    ?String(purchasedItem?.name||purchasedItem?.productName||productId).slice(0,100):null,
   rating,message,approved:true
  };
 });
 const requiredProductReviews=[...new Set((order.items||[]).map(item=>String(item.productId||'')))];
 if(!seen.has('delivery')||!seen.has('service')||
    requiredProductReviews.some(productId=>!seen.has(`product:${productId}`)))
  throw Object.assign(Error('Rate every product, delivery, and customer service before submitting.'),{status:400});

 const existing=unwrap(await supabase.from('fyi_reviews').select('id')
  .eq('order_id',order.id).eq('customer_id',customerId).limit(1));
 if(existing.length){
  const repaired=unwrap(await supabase.from('fyi_orders').update({reviewed:true,updated_at:new Date().toISOString()})
   .eq('id',order.id).eq('customer_id',customerId).eq('payment_status','paid').eq('reviewed',false).select('id'));
  if(!repaired.length){
   const latest=await getOrder(order.id);
   if(!latest?.reviewed)throw Object.assign(Error('Unable to complete the review for this order. Try again.'),{status:503});
  }
  return {reviewed:true};
 }

 const {error}=await supabase.from('fyi_reviews').insert(rows);
 if(error){
  if(error.code==='23505')
   throw Object.assign(Error('A review has already been submitted for this order.'),{status:409});
  throw Object.assign(Error('Unable to save your order review. Try again.'),{status:503});
 }
 const updated=unwrap(await supabase.from('fyi_orders').update({
  reviewed:true,updated_at:new Date().toISOString()
 }).eq('id',order.id).eq('customer_id',customerId).eq('payment_status','paid').eq('reviewed',false).select('id'));
 if(!updated.length){
  const latest=await getOrder(order.id);
  if(!latest?.reviewed)throw Object.assign(Error('Reviews were saved, but the order status could not be updated. Retry to finish.'),{status:503});
 }
 return {reviewed:true};
}
const BUCKET='fyi-payment-proofs';
export async function uploadProof(bytes,extension,mime,pathHint){
 const filepath=`orders/${pathHint}-${nonce().slice(0,12)}.${extension}`;
 unwrap(await supabase.storage.from(BUCKET).upload(filepath,bytes,{contentType:mime,upsert:false,cacheControl:'0'}));
 return filepath;
}
export async function removeProof(filepath){if(filepath)await supabase.storage.from(BUCKET).remove([filepath]);}
export async function downloadProof(filepath){const r=await supabase.storage.from(BUCKET).download(filepath);if(r.error)throw Error('Unable to access proof image.');return Buffer.from(await r.data.arrayBuffer());}


// Product photo uploads live in a public READ-ONLY bucket. Only the authenticated
// owner can use the server endpoint to write; never expose the Supabase secret to clients.
const PRODUCT_BUCKET = 'fyi-product-images';
export async function listProductImages(){
 const rows=unwrap(await supabase.from('fyi_product_images').select('product_id,storage_path'));
 return Object.fromEntries(rows.map(row=>[
   row.product_id,
   supabase.storage.from(PRODUCT_BUCKET).getPublicUrl(row.storage_path).data.publicUrl
 ]));
}
export async function uploadProductImage(productId,bytes,extension,mime){
 const storagePath=`products/${productId}/${newId()}.${extension}`;
 const bucket=supabase.storage.from(PRODUCT_BUCKET);
 unwrap(await bucket.upload(storagePath,bytes,{contentType:mime,upsert:false,cacheControl:'31536000'}));
 try {
   const previous=unwrap(await supabase.from('fyi_product_images').select('storage_path').eq('product_id',productId).maybeSingle());
   unwrap(await supabase.from('fyi_product_images').upsert({product_id:productId,storage_path:storagePath,updated_at:new Date().toISOString()},{onConflict:'product_id'}));
   if(previous?.storage_path && previous.storage_path!==storagePath){
     // Old photo deletion is best effort; failure must not roll back the saved new image.
     const removed=await bucket.remove([previous.storage_path]);
     if(removed.error)console.warn('Old photo cleanup failed:',removed.error.message);
   }
   return bucket.getPublicUrl(storagePath).data.publicUrl;
 } catch(error){
   await bucket.remove([storagePath]);
   throw error;
 }
}
export async function uploadMenuAsset(kind,id,bytes,extension,mime){
 if(kind!=='category'||!/^[-a-z0-9._]{1,60}$/i.test(id))
  throw Error('Invalid menu image destination.');
 const storagePath=`categories/${id}/${newId()}.${extension}`;
 const bucket=supabase.storage.from(PRODUCT_BUCKET);
 unwrap(await bucket.upload(storagePath,bytes,{contentType:mime,upsert:false,cacheControl:'31536000'}));
 return {storagePath,url:bucket.getPublicUrl(storagePath).data.publicUrl};
}
export async function removeMenuAsset(storagePath){
 if(typeof storagePath!=='string'||!/^categories\/[-a-z0-9._]{1,60}\/[a-f0-9-]+\.(jpg|png|webp)$/i.test(storagePath))
  throw Error('Invalid menu image path.');
 const {error}=await supabase.storage.from(PRODUCT_BUCKET).remove([storagePath]);
 if(error)throw Error('Unable to remove old category image: '+error.message);
}


// Product data: built-in catalog remains untouched until edited. Database rows override
// existing IDs and add custom IDs. Tombstones hide deleted products without losing orders.
export async function menuProductOverrides(){
 return unwrap(await supabase.from('fyi_menu_products').select('product_id,product,is_deleted'));
}
export async function saveMenuProduct(product){
 return unwrap(await supabase.from('fyi_menu_products').upsert({
  product_id:product.id,product,is_deleted:false,updated_at:new Date().toISOString()
 },{onConflict:'product_id'}).select('product_id').single());
}
export async function deleteMenuProduct(productId){
 return unwrap(await supabase.from('fyi_menu_products').upsert({
  product_id:productId,product:null,is_deleted:true,updated_at:new Date().toISOString()
 },{onConflict:'product_id'}).select('product_id').single());
}
