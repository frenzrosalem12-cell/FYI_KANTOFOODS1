// FYI KANTOFOODS: cautious patch for delivery map handoff, kitchen photos,
// and customer tracking row layout. Run from the project's root folder.
// Does not touch .env, credentials, auth files, or database schema.
const fs = require('node:fs');
const path = require('node:path');

const root = process.cwd();
const files = {
  staff: path.join(root, 'public', 'staff.js'),
  css: path.join(root, 'public', 'staff.css'),
  server: path.join(root, 'server.mjs'),
  orders: path.join(root, 'Customer_Expo', 'app', '(tabs)', 'orders.jsx')
};
for (const [name, file] of Object.entries(files)) {
  if (!fs.existsSync(file)) {
    console.error(`Missing ${name} file: ${file}`);
    process.exit(1);
  }
}
const original = Object.fromEntries(Object.entries(files).map(([name, file]) => [name, fs.readFileSync(file, 'utf8')]));
function check(ok, message) { if (!ok) throw Error(message); }
function between(source, start, end) {
  const a = source.indexOf(start);
  const b = a < 0 ? -1 : source.indexOf(end, a + start.length);
  check(a >= 0 && b > a, `Could not safely locate ${start} / ${end}. No files changed.`);
  return { a, b, content: source.slice(a, b) };
}
function replaceOnce(text, oldString, newString, label) {
  const first = text.indexOf(oldString);
  check(first >= 0, `Expected ${label} code not found. No files changed.`);
  check(text.indexOf(oldString, first + 1) < 0, `${label} occurs more than once. No files changed.`);
  return text.slice(0, first) + newString + text.slice(first + oldString.length);
}

const staffHelpers = String.raw`
// FYI UPGRADES: map handoff and kitchen image helpers.
function fyiValidPin(order) {
  const p = order?.customer?.deliveryPin || order?.deliveryLocation || {};
  const lat = Number(p.lat ?? p.latitude), lng = Number(p.lng ?? p.longitude);
  return Number.isFinite(lat) && Number.isFinite(lng) &&
    lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 &&
    !(lat === 0 && lng === 0) ? {lat, lng} : null;
}
function fyiRiderLink(order) {
  const p = fyiValidPin(order);
  if (p) return 'https://www.google.com/maps/dir/?api=1&destination=' +
    encodeURIComponent(p.lat + ',' + p.lng) + '&travelmode=driving';
  const address = String(order?.customer?.address || '').trim();
  return address ? 'https://www.google.com/maps/search/?api=1&query=' +
    encodeURIComponent(address) : '';
}
function fyiDeliveryCard(order) {
  if (!['owner','cashier'].includes(user?.role) || order.type !== 'delivery') return '';
  const customer = order.customer || {};
  const pin = fyiValidPin(order);
  const mapUrl = fyiRiderLink(order);
  const embed = pin ? 'https://maps.google.com/maps?q=' +
    encodeURIComponent(pin.lat + ',' + pin.lng) + '&z=16&output=embed' : '';
  return '<div class="detail-card fyi-delivery-card">' +
    '<h4>Rider Delivery Location</h4>' +
    '<p><b>Address:</b> ' + esc(customer.address || 'Not provided') + '</p>' +
    '<p><b>Landmark:</b> ' + esc(customer.landmark || 'Not provided') + '</p>' +
    '<p><b>Road distance:</b> ' + esc(order.roadKm ?? '—') + ' km</p>' +
    (pin ? '<p class="fyi-map-note">Customer-selected pin (exact drop-off marker).</p>' +
       '<iframe class="fyi-map-frame" loading="lazy" title="Customer delivery pin" referrerpolicy="no-referrer-when-downgrade" src="' + esc(embed) + '"></iframe>' :
       '<p class="fyi-map-warning">This order does not have a saved map pin. Address search is approximate; confirm the location with the customer.</p>') +
    '<div class="fyi-map-actions">' +
      (mapUrl ? '<a class="small-btn main" href="' + esc(mapUrl) + '" target="_blank" rel="noopener noreferrer">' +
        (pin ? 'View Pin / Directions ↗' : 'Search Address ↗') + '</a>' : '') +
      '<button type="button" class="small-btn" data-copy-rider="' + esc(order.id) + '">Copy Rider Details</button>' +
    '</div></div>';
}
function fyiKitchenItem(item) {
  const p = catalog?.products?.find(p => p.id === item.productId) ||
    catalog?.products?.find(p => String(p.name).toLowerCase() === String(item.name).toLowerCase());
  const source = productImages?.[item.productId] || p?.imageUrl || '';
  const img = typeof source === 'string' &&
    (/^https:\/\//i.test(source) || /^\/assets\//.test(source)) ? source : '';
  return '<div class="fyi-kitchen-item">' +
    (img ? '<img class="fyi-kitchen-img" loading="lazy" src="' + esc(img) + '" alt="' + esc(item.name) + '">' :
      '<div class="fyi-kitchen-img fyi-kitchen-no-photo">🍽</div>') +
    '<div class="fyi-kitchen-meta"><strong>' + esc(item.qty) + '× ' + esc(item.name) + '</strong>' +
    '<small>' + esc(item.size || '') + (item.variant ? ' · ' + esc(item.variant) : '') + '</small></div></div>';
}
function fyiRiderDetails(order) {
  const c = order.customer || {};
  return ['FYI KANTOFOODS DELIVERY', 'Order: ' + order.id,
    'Customer: ' + (c.name || ''), 'Phone: ' + (c.phone || ''),
    'Address: ' + (c.address || ''), 'Landmark: ' + (c.landmark || '—'),
    'Notes: ' + (c.notes || '—'),
    'Map: ' + (fyiRiderLink(order) || 'Pin unavailable')].join('\n');
}
`;

try {
  // Customer tracking: make ETA rows vertically stacked, preventing narrow-screen overlap.
  let orders = original.orders;
  check(!orders.includes('function FyiEstimateRow('), 'Estimate fix already exists. No files changed.');
  const marker = 'Preparation & delivery estimate';
  const start = orders.indexOf(marker);
  const end = start < 0 ? -1 : orders.indexOf('</Card>', start);
  check(start >= 0 && end > start, 'Could not find tracking estimate card. No files changed.');
  let estimate = orders.slice(start, end);
  const matches = (estimate.match(/<SummaryLine\s+label=/g) || []).length;
  check(matches === 4, `Found ${matches} estimate rows instead of 4. No files changed.`);
  estimate = estimate.replace(/<SummaryLine\s+label=/g, '<FyiEstimateRow label=');
  orders = orders.slice(0, start) + estimate + orders.slice(end);
  const rowComponent = `
// FYI UPGRADES: full-width values wrap cleanly on narrow iPhone screens.
function FyiEstimateRow({label, value}) {
  return <View style={{paddingVertical:10,borderBottomWidth:StyleSheet.hairlineWidth,borderBottomColor:C.border}}>
    <Txt style={{fontSize:12,color:C.muted,lineHeight:18}}>{label}</Txt>
    <Txt style={{fontSize:13,fontWeight:'800',color:C.forest,marginTop:4,lineHeight:20,flexShrink:1}}>{value}</Txt>
  </View>;
}
`;
  orders = replaceOnce(orders, 'export default function Orders()', rowComponent + '\nexport default function Orders()', 'Expo Orders screen');

  // Save the validated customer-selected map pin INSIDE existing customer JSON.
  // No new database column is required. Applies only to newly placed orders.
  let server = original.server;
  check(!server.includes('FYI UPGRADES: persist the selected customer drop-off pin'), 'Server pin fix already exists. No files changed.');
  const routeStart = server.indexOf("p === '/api/public/orders'");
  check(routeStart >= 0, 'Cannot locate current customer order API handler. No files changed.');
  const orderIndex = server.indexOf('const order = {', routeStart);
  check(orderIndex > routeStart && orderIndex - routeStart < 14000, 'Cannot find order payload inside customer order handler. No files changed.');
  const prior = server.slice(routeStart, orderIndex);
  check(prior.includes('roadDistance(') && prior.includes('const customer = {') && prior.includes('b.delivery?.lat') && prior.includes('b.delivery?.lng'),
    'Current order creation differs from known layout. No files changed.');
  const savePin = `// FYI UPGRADES: persist the selected customer drop-off pin in customer JSON.\n    // These coordinates were already validated when calculating the road distance.\n    const fyiPinLat = Number(b.delivery?.lat);\n    const fyiPinLng = Number(b.delivery?.lng);\n    if (Number.isFinite(fyiPinLat) && Number.isFinite(fyiPinLng) &&\n        fyiPinLat >= -90 && fyiPinLat <= 90 && fyiPinLng >= -180 && fyiPinLng <= 180) {\n      customer.deliveryPin = {lat: Number(fyiPinLat.toFixed(6)), lng: Number(fyiPinLng.toFixed(6))};\n    }\n\n    `;
  server = server.slice(0, orderIndex) + savePin + server.slice(orderIndex);

  // Staff UI: map and rider info, plus thumbnail-backed kitchen tickets.
  let staff = original.staff;
  check(!staff.includes('function fyiDeliveryCard('), 'Staff UI fix already exists. No files changed.');
  const a = staff.indexOf('function orderDetail(){');
  const b = staff.indexOf('function kitchen(){', a);
  check(a >= 0 && b > a, 'Cannot find staff order detail and kitchen functions. No files changed.');
  staff = staff.slice(0, a) + staffHelpers + '\n' + staff.slice(a);
  const detail = between(staff, 'function orderDetail(){', 'function kitchen(){');
  check(detail.content.includes('<div class="order-detail">'), 'Cannot locate order detail card layout. No files changed.');
  let updatedDetail = detail.content.replace('<div class="order-detail">', '<div class="order-detail">${fyiDeliveryCard(o)}');
  // Kitchen staff also see photos when opening an individual ticket.
  const oldDetailItems = "o.items.map(x=>`<div class=\"summary-line\"><span>${x.qty}× ${esc(x.name)} (${esc(x.size)})</span><b>${pesos(x.lineTotal)}</b></div>`).join('')";
  if (updatedDetail.includes(oldDetailItems)) {
    updatedDetail = updatedDetail.replace(oldDetailItems,
      "o.items.map(x=>user.role==='kitchen'?fyiKitchenItem(x):`<div class=\"summary-line\"><span>${x.qty}× ${esc(x.name)} (${esc(x.size)})</span><b>${pesos(x.lineTotal)}</b></div>`).join('')");
  }
  staff = staff.slice(0, detail.a) + updatedDetail + staff.slice(detail.b);
  const kitchenSectionStart = staff.indexOf('function kitchen(){');
  const kitchenSectionEnd = staff.indexOf('function products(){', kitchenSectionStart);
  const kitchenSectionAltEnd = staff.indexOf('// Full Product Manager', kitchenSectionStart);
  const kitchenEnd = kitchenSectionEnd > kitchenSectionStart ? kitchenSectionEnd : kitchenSectionAltEnd;
  check(kitchenSectionStart >= 0 && kitchenEnd > kitchenSectionStart, 'Cannot safely locate kitchen ticket function end. No files changed.');
  let kitchenChunk = staff.slice(kitchenSectionStart, kitchenEnd);
  const oldKitchenItems = "o.items.map(x=>`${x.qty}× ${esc(x.name)} · ${esc(x.size)}${x.variant?' · '+esc(x.variant):''}`).join('<br>')";
  check(kitchenChunk.includes(oldKitchenItems), 'Kitchen item renderer differs from reference version. No files changed.');
  kitchenChunk = kitchenChunk.replace(oldKitchenItems, "o.items.map(fyiKitchenItem).join('')");
  staff = staff.slice(0, kitchenSectionStart) + kitchenChunk + staff.slice(kitchenEnd);
  check(/function attach\(\)\s*\{/.test(staff), 'Cannot locate staff click handlers. No files changed.');
  staff = staff.replace(/function attach\(\)\s*\{/, `function attach(){
  document.querySelectorAll('[data-copy-rider]').forEach(button => {
    button.onclick = async () => {
      const order = data?.orders?.find(x => x.id === button.dataset.copyRider);
      if (!order) return;
      const details = fyiRiderDetails(order);
      try {
        if (!navigator.clipboard?.writeText) throw Error('Clipboard unavailable');
        await navigator.clipboard.writeText(details);
        notice('Rider details copied.');
      } catch {
        window.prompt('Copy rider delivery details:', details);
      }
    };
  });`);

  let css = original.css;
  const cssAppend = `
/* FYI UPGRADES: delivery map, rider actions, kitchen item thumbnails */
.fyi-delivery-card p{margin:6px 0;line-height:1.5;overflow-wrap:anywhere}
.fyi-map-note{font-size:12px;color:#0b7b53}
.fyi-map-warning{font-size:12px;color:#906014;background:#fff7e8;border-radius:9px;padding:10px}
.fyi-map-frame{width:100%;height:220px;border:0;border-radius:12px;margin:9px 0}
.fyi-map-actions{display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin-top:10px}
.fyi-map-actions .small-btn{text-decoration:none;display:inline-flex;align-items:center}
.fyi-kitchen-item{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #e7eee9}
.fyi-kitchen-img{width:64px;height:64px;flex:none;object-fit:cover;border-radius:10px;background:#f2f6f2}
.fyi-kitchen-no-photo{display:flex;align-items:center;justify-content:center;font-size:23px}
.fyi-kitchen-meta{min-width:0;flex:1;display:flex;flex-direction:column;gap:5px;line-height:1.4}
.fyi-kitchen-meta strong,.fyi-kitchen-meta small{white-space:normal;overflow-wrap:anywhere}
.fyi-kitchen-meta small{color:#687b74}
`;
  check(!css.includes('FYI UPGRADES: delivery map'), 'Staff style fix already exists. No files changed.');
  css += cssAppend;

  const patch = {staff, css, server, orders};
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  // All validations complete: back up all originals before writing anything.
  for (const [key, file] of Object.entries(files)) fs.copyFileSync(file, file + `.backup-${timestamp}`);
  for (const [key, file] of Object.entries(files)) fs.writeFileSync(file, patch[key], 'utf8');
  console.log('SUCCESS: 3 FYI upgrades applied.');
  console.log('1. Cashier/Admin view map and copy rider details (future orders save the pin).');
  console.log('2. Kitchen ticket cards show a photo where the product has one.');
  console.log('3. Customer tracking estimate labels no longer overlap values.');
  console.log('Backups saved beside each changed file.');
  console.log('Restart your Node backend and Expo to test.');
} catch (e) {
  console.error('STOPPED SAFELY:', e.message);
  console.error('Your project files were not changed.');
  process.exitCode = 1;
}
