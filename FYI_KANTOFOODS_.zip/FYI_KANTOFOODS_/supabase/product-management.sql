-- Run once after product-images.sql. All writes are performed only by the server's secret key.
-- For the 46 built-in products, a row is created ONLY after you edit/hide/delete it.
create table if not exists public.fyi_menu_products (
 product_id text primary key,
 product jsonb,
 is_deleted boolean not null default false,
 updated_at timestamptz not null default now(),
 constraint valid_product_row check (is_deleted or (product is not null and jsonb_typeof(product) = 'object'))
);
alter table public.fyi_menu_products enable row level security;
-- Intentionally NO anonymous/authenticated policies. Only Node's Supabase secret can write/read.
-- Do not turn off RLS.

-- Refresh PostgREST schema cache after adding this table.
notify pgrst, 'reload schema';
