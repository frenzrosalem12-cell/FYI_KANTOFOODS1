begin;

alter table public.fyi_reviews
  alter column order_id drop not null,
  add column if not exists product_name text;

do $$
declare
  order_unique_constraint text;
begin
  select constraint_row.conname into order_unique_constraint
  from pg_constraint as constraint_row
  join pg_attribute as order_column
    on order_column.attrelid = constraint_row.conrelid
   and order_column.attname = 'order_id'
  where constraint_row.conrelid = 'public.fyi_reviews'::regclass
    and constraint_row.contype = 'u'
    and array_length(constraint_row.conkey, 1) = 1
    and constraint_row.conkey[1] = order_column.attnum
  limit 1;

  if order_unique_constraint is not null then
    execute format('alter table public.fyi_reviews drop constraint %I', order_unique_constraint);
  end if;
end $$;

alter table public.fyi_reviews enable row level security;
revoke all on public.fyi_reviews from anon, authenticated;
grant usage on schema public to service_role;
grant all privileges on public.fyi_reviews to service_role;

commit;
