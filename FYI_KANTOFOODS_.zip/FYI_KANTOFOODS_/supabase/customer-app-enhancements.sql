begin;

alter table public.profiles
  add column if not exists avatar_path text;

alter table public.fyi_reviews
  add column if not exists customer_id uuid references auth.users(id) on delete set null,
  add column if not exists product_id text,
  add column if not exists review_type text not null default 'general';

alter table public.fyi_reviews alter column rating drop not null;
alter table public.fyi_reviews drop constraint if exists fyi_reviews_review_type_check;
alter table public.fyi_reviews
  add constraint fyi_reviews_review_type_check
  check (review_type in ('product','delivery','service','overall','general'));

do $$
declare
  order_unique_constraint text;
begin
  select constraint_row.conname into order_unique_constraint
  from pg_constraint as constraint_row
  join pg_attribute as order_column
    on order_column.attrelid = constraint_row.conrelid
   and order_column.attname = 'order_id'
  where constraint_row.conrelid = 'public.fyi_reviews'::regclass
    and constraint_row.contype = 'u'
    and array_length(constraint_row.conkey, 1) = 1
    and constraint_row.conkey[1] = order_column.attnum
  limit 1;

  if order_unique_constraint is not null then
    execute format('alter table public.fyi_reviews drop constraint %I', order_unique_constraint);
  end if;
end $$;

create unique index if not exists fyi_reviews_order_product_unique
  on public.fyi_reviews(order_id, product_id)
  where order_id is not null and customer_id is not null and review_type = 'product';
create unique index if not exists fyi_reviews_order_type_unique
  on public.fyi_reviews(order_id, review_type)
  where order_id is not null and customer_id is not null and review_type <> 'product';

create table if not exists public.fyi_customer_favorites (
  customer_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null,
  created_at timestamptz not null default now(),
  primary key (customer_id, product_id),
  check (length(product_id) between 1 and 80)
);
alter table public.fyi_customer_favorites enable row level security;
revoke all on public.fyi_customer_favorites from anon, authenticated;
grant all privileges on public.fyi_customer_favorites to service_role;

drop view if exists public.fyi_product_popularity;
create view public.fyi_product_popularity
with (security_invoker = true)
as
with favorite_counts as (
  select product_id, count(*)::bigint as favorite_count
  from public.fyi_customer_favorites
  group by product_id
),
order_counts as (
  select
    item.value->>'productId' as product_id,
    sum(greatest(coalesce(nullif(item.value->>'qty','')::integer,0),0))::bigint as order_count
  from public.fyi_orders as orders
  cross join lateral jsonb_array_elements(
    case when jsonb_typeof(orders.items) = 'array' then orders.items else '[]'::jsonb end
  ) as item(value)
  where orders.payment_status = 'paid'
  group by item.value->>'productId'
)
select
  coalesce(favorite_counts.product_id, order_counts.product_id) as product_id,
  coalesce(favorite_counts.favorite_count,0) as favorite_count,
  coalesce(order_counts.order_count,0) as order_count
from favorite_counts
full outer join order_counts using (product_id);
revoke all on public.fyi_product_popularity from anon, authenticated;
grant select on public.fyi_product_popularity to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'fyi-customer-photos',
  'fyi-customer-photos',
  false,
  5242880,
  array['image/jpeg','image/png','image/webp']::text[]
)
on conflict (id) do update
set public = false,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Customers can read their own profile photos" on storage.objects;
create policy "Customers can read their own profile photos"
on storage.objects for select to authenticated
using (
  bucket_id = 'fyi-customer-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "Customers can upload their own profile photos" on storage.objects;
create policy "Customers can upload their own profile photos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'fyi-customer-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "Customers can update their own profile photos" on storage.objects;
create policy "Customers can update their own profile photos"
on storage.objects for update to authenticated
using (
  bucket_id = 'fyi-customer-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
  bucket_id = 'fyi-customer-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "Customers can delete their own profile photos" on storage.objects;
create policy "Customers can delete their own profile photos"
on storage.objects for delete to authenticated
using (
  bucket_id = 'fyi-customer-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

notify pgrst, 'reload schema';
commit;
