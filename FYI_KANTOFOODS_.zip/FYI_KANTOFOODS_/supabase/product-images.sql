-- Run ONCE in Supabase > SQL Editor, after your existing FYI schema.
-- These are PUBLIC menu photos, not payment screenshots or customer data.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('fyi-product-images','fyi-product-images',true,2097152,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,
 file_size_limit=excluded.file_size_limit,
 allowed_mime_types=excluded.allowed_mime_types;

create table if not exists public.fyi_product_images (
 product_id text primary key,
 storage_path text not null,
 updated_at timestamptz not null default now()
);
alter table public.fyi_product_images enable row level security;
-- No anonymous INSERT/UPDATE/DELETE policies. Server uses the secret key.
-- Public downloads use storage public URLs; DB reads stay server-side.
