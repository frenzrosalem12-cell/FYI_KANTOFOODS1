-- run this whole script in the Supabase SQL Editor to repair customer profiles:))
-- rt adds the missing email column before installing the auth trigger:)

begin;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text not null default '',
  full_name text not null default '',
  phone text not null default '',
  address text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles
  add column if not exists email text,
  add column if not exists username text not null default '',
  add column if not exists full_name text not null default '',
  add column if not exists phone text not null default '',
  add column if not exists address text not null default '',
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

update public.profiles as profile
set email = auth_user.email
from auth.users as auth_user
where auth_user.id = profile.id
  and profile.email is distinct from auth_user.email;

with duplicate_usernames as (
  select id, row_number() over (
    partition by lower(btrim(username)) order by created_at, id
  ) as duplicate_number
  from public.profiles
  where nullif(btrim(username), '') is not null
)
update public.profiles as profile
set username = left(btrim(profile.username), 20) || '_' ||
  left(replace(profile.id::text, '-', ''), 8)
from duplicate_usernames as duplicate
where duplicate.id = profile.id
  and duplicate.duplicate_number > 1;

create unique index if not exists profiles_username_lower_unique
  on public.profiles (lower(username))
  where nullif(btrim(username), '') is not null;

alter table public.profiles enable row level security;

drop policy if exists "Customers can read their own profile" on public.profiles;
create policy "Customers can read their own profile"
  on public.profiles for select to authenticated
  using ((select auth.uid()) = id);

drop policy if exists "Customers can insert their own profile" on public.profiles;
create policy "Customers can insert their own profile"
  on public.profiles for insert to authenticated
  with check ((select auth.uid()) = id);

drop policy if exists "Customers can update their own profile" on public.profiles;
create policy "Customers can update their own profile"
  on public.profiles for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

grant select, insert, update on public.profiles to authenticated;
grant select, insert, update on public.profiles to service_role;
grant select on public.fyi_orders to service_role;

create or replace function public.handle_new_customer()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (
    id, email, username, full_name, phone, address
  )
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'username', ''),
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', ''),
    coalesce(new.raw_user_meta_data ->> 'address', '')
  )
  on conflict (id) do update set
    email = excluded.email,
    username = excluded.username,
    full_name = excluded.full_name,
    phone = excluded.phone,
    address = excluded.address,
    updated_at = now();

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
  after insert on auth.users
  for each row execute procedure public.handle_new_customer();

create or replace function public.sync_customer_profile_email()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles set email = new.email where id = new.id;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_updated on auth.users;
create trigger on_auth_user_email_updated
  after update of email on auth.users
  for each row when (old.email is distinct from new.email)
  execute procedure public.sync_customer_profile_email();

drop view if exists public.customerfyi_list;
create view public.customerfyi_list
with (security_invoker = true)
as
select
  profile.id as customer_id,
  profile.username,
  profile.email,
  profile.full_name,
  profile.phone,
  profile.address,
  profile.created_at as account_created_at,
  coalesce(totals.order_count, 0) as order_count,
  coalesce(totals.paid_order_count, 0) as paid_order_count,
  coalesce(totals.total_spent, 0)::numeric(12, 2) as total_spent
from public.profiles as profile
left join lateral (
  select
    count(*) as order_count,
    count(*) filter (where orders.payment_status = 'paid') as paid_order_count,
    coalesce(sum(orders.total) filter (where orders.payment_status = 'paid'), 0) as total_spent
  from public.fyi_orders as orders
  where orders.customer_id = profile.id
) as totals on true;

revoke all on public.customerfyi_list from anon, authenticated;
grant select on public.customerfyi_list to service_role;

commit;
