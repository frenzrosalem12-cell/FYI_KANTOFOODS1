begin;

alter table public.fyi_store_settings
  add column if not exists menu_categories jsonb not null default '[]'::jsonb,
  add column if not exists menu_addons jsonb not null default '[]'::jsonb;

do $$
declare
  role_check record;
  legacy_count integer;
  cashier_count integer;
begin
  for role_check in
    select constraint_row.conname
    from pg_constraint as constraint_row
    where constraint_row.conrelid = 'public.fyi_staff'::regclass
      and constraint_row.contype = 'c'
      and pg_get_constraintdef(constraint_row.oid) ilike '%role%'
  loop
    execute format('alter table public.fyi_staff drop constraint %I', role_check.conname);
  end loop;

  select count(*) into legacy_count
  from public.fyi_staff
  where lower(role) in ('admin2','admin_2','admin 2');

  select count(*) into cashier_count
  from public.fyi_staff
  where role = 'cashier';

  if legacy_count > 1 then
    raise exception 'Found multiple legacy Admin 2 accounts; no staff roles were changed.';
  elsif legacy_count = 1 and cashier_count > 0 then
    raise exception 'A Cashier account already exists; refusing to replace or merge staff credentials.';
  elsif legacy_count = 1 then
    update public.fyi_staff
    set role = 'cashier'
    where lower(role) in ('admin2','admin_2','admin 2');
  end if;
end $$;

alter table public.fyi_staff
  add constraint fyi_staff_role_check
  check (role in ('owner','cashier','kitchen'));

create or replace view public.fyi_staff_sales_hourly
with (security_invoker = true)
as
select
  date_trunc('hour', created_at) as bucket,
  count(*)::bigint as paid_order_count,
  coalesce(sum(total),0)::numeric(14,2) as sales_total
from public.fyi_orders
where payment_status = 'paid'
group by date_trunc('hour', created_at);

create or replace view public.fyi_staff_orders_hourly
with (security_invoker = true)
as
select
  date_trunc('hour', created_at) as bucket,
  count(*)::bigint as order_count
from public.fyi_orders
group by date_trunc('hour', created_at);

create or replace view public.fyi_staff_product_sales
with (security_invoker = true)
as
select
  item.value->>'productId' as product_id,
  max(coalesce(item.value->>'name', item.value->>'productName', 'Menu item')) as product_name,
  sum(case
    when coalesce(item.value->>'qty','') ~ '^[0-9]+$' then (item.value->>'qty')::bigint
    else 0
  end)::bigint as quantity_sold,
  count(distinct orders.id)::bigint as order_count
from public.fyi_orders as orders
cross join lateral jsonb_array_elements(
  case when jsonb_typeof(orders.items) = 'array' then orders.items else '[]'::jsonb end
) as item(value)
where orders.payment_status = 'paid'
  and nullif(item.value->>'productId','') is not null
group by item.value->>'productId';

create or replace view public.fyi_staff_sales_summary
with (security_invoker = true)
as
select
  count(*)::bigint as paid_order_count,
  coalesce(sum(total),0)::numeric(14,2) as total_sales
from public.fyi_orders
where payment_status = 'paid';

revoke all on public.fyi_staff_sales_hourly,
  public.fyi_staff_orders_hourly,
  public.fyi_staff_product_sales,
  public.fyi_staff_sales_summary
  from anon, authenticated;
grant select on public.fyi_staff_sales_hourly,
  public.fyi_staff_orders_hourly,
  public.fyi_staff_product_sales,
  public.fyi_staff_sales_summary
  to service_role;

notify pgrst, 'reload schema';
commit;
