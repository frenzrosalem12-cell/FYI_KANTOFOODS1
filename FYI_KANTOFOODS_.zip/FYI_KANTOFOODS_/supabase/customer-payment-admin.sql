-- Run once in Supabase SQL Editor for an existing FYI-KANTO database.
-- Adds username-based customer accounts, purchase totals, and payment records.

with duplicate_usernames as (
  select id,row_number() over (
    partition by lower(btrim(username)) order by created_at,id
  ) as duplicate_number
  from public.profiles
  where nullif(btrim(username),'') is not null
)
update public.profiles as profile
set username=left(btrim(profile.username),20)||'_'||left(replace(profile.id::text,'-',''),8)
from duplicate_usernames as duplicate
where duplicate.id=profile.id and duplicate.duplicate_number>1;

create unique index if not exists profiles_username_lower_unique
  on public.profiles (lower(username))
  where nullif(btrim(username),'') is not null;

alter table public.profiles add column if not exists email text;
update public.profiles as profile
set email=auth_user.email
from auth.users as auth_user
where auth_user.id=profile.id and profile.email is distinct from auth_user.email;

create or replace function public.handle_new_customer()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (
    id,email,username,full_name,phone,address
  )
  values (
    new.id,new.email,
    coalesce(new.raw_user_meta_data ->> 'username',new.raw_user_meta_data ->> 'full_name',''),
    coalesce(new.raw_user_meta_data ->> 'full_name',''),
    coalesce(new.raw_user_meta_data ->> 'phone',''),
    coalesce(new.raw_user_meta_data ->> 'address','')
  )
  on conflict (id) do update set
    email=excluded.email,
    username=excluded.username,
    full_name=excluded.full_name,
    phone=excluded.phone,
    address=excluded.address;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.handle_new_customer();

create or replace function public.sync_customer_profile_email()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles set email=new.email where id=new.id;
  return new;
end;
$$;
drop trigger if exists on_auth_user_email_updated on auth.users;
create trigger on_auth_user_email_updated
after update of email on auth.users
for each row when (old.email is distinct from new.email)
execute procedure public.sync_customer_profile_email();

create or replace function public.enforce_profile_auth_email()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  select auth_user.email into new.email
  from auth.users as auth_user where auth_user.id=new.id;
  return new;
end;
$$;
drop trigger if exists profiles_auth_email_guard on public.profiles;
create trigger profiles_auth_email_guard
before insert or update of email on public.profiles
for each row execute procedure public.enforce_profile_auth_email();

alter table public.fyi_orders
  add column if not exists customer_id uuid references auth.users(id) on delete set null,
  add column if not exists payment_reference text,
  add column if not exists payment_checkout_url text;

update public.fyi_orders as orders
set customer_id=(
  select profiles.id
  from public.profiles
  where btrim(profiles.phone)=btrim(orders.customer->>'phone')
  order by profiles.created_at,profiles.id
  limit 1
)
where orders.customer_id is null
  and nullif(btrim(orders.customer->>'phone'),'') is not null
  and exists (
    select 1
    from public.profiles
    where btrim(profiles.phone)=btrim(orders.customer->>'phone')
  );

create table if not exists public.fyi_payment_transactions (
  id uuid primary key default gen_random_uuid(),
  order_id text not null unique references public.fyi_orders(id) on delete cascade,
  customer_id uuid references auth.users(id) on delete set null,
  provider text not null default 'paymongo' check (provider = 'paymongo'),
  payment_reference text not null unique,
  amount_minor bigint not null check (amount_minor > 0),
  currency text not null default 'PHP' check (currency = 'PHP'),
  status text not null check (status in ('pending_payment','paid','failed','cancelled','refunded')),
  payment_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists fyi_payment_transactions_created
  on public.fyi_payment_transactions(created_at desc);
insert into public.fyi_payment_transactions (
  order_id,customer_id,provider,payment_reference,amount_minor,currency,status,
  payment_url,created_at,updated_at
)
select
  o.id,o.customer_id,'paymongo',o.payment_reference,round(o.total*100)::bigint,'PHP',
  case
    when o.payment_status='paid' then 'paid'
    when o.payment_status in ('failed','rejected') then 'failed'
    when o.payment_status='cancelled' then 'cancelled'
    when o.payment_status='refunded' then 'refunded'
    else 'pending_payment'
  end,
  o.payment_checkout_url,o.created_at,o.updated_at
from public.fyi_orders o
where o.payment_method='paymongo' and o.payment_reference is not null
on conflict do nothing;
alter table public.fyi_payment_transactions enable row level security;
revoke all on public.fyi_payment_transactions from anon, authenticated;
grant all privileges on public.fyi_payment_transactions to service_role;

drop view if exists public.customerfyi_list;
create view public.customerfyi_list
with (security_invoker = true)
as
select
  p.id as customer_id,
  p.username,
  p.email,
  p.full_name,
  p.phone,
  p.address,
  p.created_at as account_created_at,
  coalesce(totals.order_count,0) as order_count,
  coalesce(totals.paid_order_count,0) as paid_order_count,
  coalesce(totals.total_spent,0)::numeric(12,2) as total_spent
from public.profiles p
left join lateral (
  select
    count(*) as order_count,
    count(*) filter (where o.payment_status = 'paid') as paid_order_count,
    coalesce(sum(o.total) filter (where o.payment_status = 'paid'),0) as total_spent
  from public.fyi_orders o
  where o.customer_id = p.id
) totals on true;
revoke all on public.customerfyi_list from anon, authenticated;
grant select on public.customerfyi_list to service_role;
grant select on public.profiles,public.fyi_orders to service_role;

drop view if exists public.paymentfyi_list;
create view public.paymentfyi_list
with (security_invoker = true)
as
select
  t.id as transaction_id,
  t.order_id,
  t.customer_id,
  p.username,
  t.provider,
  t.payment_reference,
  t.amount_minor,
  t.currency,
  t.status as payment_status,
  o.status as order_status,
  t.payment_url,
  t.created_at,
  t.updated_at,
  coalesce(totals.paid_orders,0) as customer_paid_orders,
  coalesce(totals.total_spent,0)::numeric(12,2) as customer_total_spent
from public.fyi_payment_transactions t
join public.fyi_orders o on o.id = t.order_id
left join public.profiles p on p.id = t.customer_id
left join lateral (
  select count(*) as paid_orders, sum(paid.total) as total_spent
  from public.fyi_orders paid
  where paid.customer_id = t.customer_id and paid.payment_status = 'paid'
) totals on true;
revoke all on public.paymentfyi_list from anon, authenticated;
grant select on public.paymentfyi_list to service_role;
