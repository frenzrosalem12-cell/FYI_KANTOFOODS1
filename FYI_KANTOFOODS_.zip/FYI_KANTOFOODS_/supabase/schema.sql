-- FYI KANTO | Paste once into the SQL Editor of YOUR Supabase project.
-- Separate tables for staff, settings, orders, and customer reviews.
-- Browser/Expo never accesses these tables directly: Node server uses a secret key.

create table if not exists public.fyi_staff (
  id uuid primary key,
  role text not null check (role in ('owner','cashier','kitchen')),
  name text not null,
  username text not null unique,
  active boolean not null default true,
  salt text not null,
  password_hash text not null,
  created_at timestamptz not null default now()
);
create unique index if not exists fyi_one_owner on public.fyi_staff(role) where role='owner';
create unique index if not exists fyi_one_cashier on public.fyi_staff(role) where role='cashier';

create table if not exists public.fyi_store_settings (
  id integer primary key default 1 check(id=1),
  open_time text not null default '08:00',
  close_time text not null default '20:00',
  override text not null default 'auto' check (override in ('auto','open','closed')),
  location jsonb not null default '{"lat":8.65484,"lng":124.75370,"name":"DEMO USTP Jasaan campus area - NOT the verified shop"}'::jsonb,
  menu_categories jsonb not null default '[]'::jsonb,
  menu_addons jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.fyi_store_settings(id) values(1) on conflict(id) do nothing;
alter table public.fyi_store_settings
  add column if not exists menu_categories jsonb not null default '[]'::jsonb,
  add column if not exists menu_addons jsonb not null default '[]'::jsonb;

create table if not exists public.fyi_orders (
  id text primary key,
  tracking_hash text not null unique,
  customer_id uuid references auth.users(id) on delete set null,
  order_type text not null check (order_type in ('delivery','dine-in')),
  status text not null check(status in ('pending_payment','pending_verification','pending_acceptance','accepted','preparing','ready','out','delivered','rejected')),
  payment_status text not null,
  payment_method text not null check (payment_method in ('gcash','cash','paymongo')),
  payment_reference text,
  payment_checkout_url text,
  customer jsonb not null,
  items jsonb not null,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
  road_km numeric(8,2),
  total numeric(12,2) not null check (total >= 0),
  gcash_reference text not null default '',
  proof_path text,
  proof_mime text,
  history jsonb not null default '[]'::jsonb,
  reviewed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists fyi_orders_created on public.fyi_orders (created_at desc);
create index if not exists fyi_orders_status on public.fyi_orders (status);

alter table public.fyi_orders
  add column if not exists customer_id uuid references auth.users(id) on delete set null,
  add column if not exists payment_reference text,
  add column if not exists payment_checkout_url text;

create unique index if not exists fyi_orders_payment_reference
  on public.fyi_orders(payment_reference) where payment_reference is not null;

create table if not exists public.fyi_payment_transactions (
  id uuid primary key default gen_random_uuid(),
  order_id text not null unique references public.fyi_orders(id) on delete cascade,
  customer_id uuid references auth.users(id) on delete set null,
  provider text not null default 'paymongo' check (provider = 'paymongo'),
  payment_reference text not null unique,
  amount_minor bigint not null check (amount_minor > 0),
  currency text not null default 'PHP' check (currency = 'PHP'),
  status text not null check (status in ('pending_payment','paid','failed','cancelled','refunded')),
  payment_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists fyi_payment_transactions_created
  on public.fyi_payment_transactions(created_at desc);
insert into public.fyi_payment_transactions (
  order_id,customer_id,provider,payment_reference,amount_minor,currency,status,
  payment_url,created_at,updated_at
)
select
  o.id,o.customer_id,'paymongo',o.payment_reference,round(o.total*100)::bigint,'PHP',
  case
    when o.payment_status='paid' then 'paid'
    when o.payment_status in ('failed','rejected') then 'failed'
    when o.payment_status='cancelled' then 'cancelled'
    when o.payment_status='refunded' then 'refunded'
    else 'pending_payment'
  end,
  o.payment_checkout_url,o.created_at,o.updated_at
from public.fyi_orders o
where o.payment_method='paymongo' and o.payment_reference is not null
on conflict do nothing;

alter table public.fyi_orders drop constraint if exists fyi_orders_status_check;
alter table public.fyi_orders add constraint fyi_orders_status_check
  check(status in ('pending_payment','pending_verification','pending_acceptance','accepted','preparing','ready','out','delivered','rejected'));
alter table public.fyi_orders drop constraint if exists fyi_orders_payment_method_check;
alter table public.fyi_orders add constraint fyi_orders_payment_method_check
  check(payment_method in ('gcash','cash','paymongo'));

create table if not exists public.fyi_reviews (
  id uuid primary key,
  customer_id uuid references auth.users(id) on delete set null,
  order_id text references public.fyi_orders(id) on delete cascade,
  review_type text not null default 'general'
    check (review_type in ('product','delivery','service','overall','general')),
  product_id text,
  name text not null,
  product_name text,
  rating integer check (rating between 1 and 5),
  message text not null,
  approved boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.fyi_reviews alter column order_id drop not null;
alter table public.fyi_reviews add column if not exists product_name text;
alter table public.fyi_reviews add column if not exists customer_id uuid references auth.users(id) on delete set null;
alter table public.fyi_reviews add column if not exists product_id text;
alter table public.fyi_reviews add column if not exists review_type text not null default 'general';
alter table public.fyi_reviews alter column rating drop not null;
alter table public.fyi_reviews drop constraint if exists fyi_reviews_review_type_check;
alter table public.fyi_reviews add constraint fyi_reviews_review_type_check
  check (review_type in ('product','delivery','service','overall','general'));

do $$
declare
  order_unique_constraint text;
begin
  select constraint_row.conname into order_unique_constraint
  from pg_constraint as constraint_row
  join pg_attribute as order_column
    on order_column.attrelid = constraint_row.conrelid
   and order_column.attname = 'order_id'
  where constraint_row.conrelid = 'public.fyi_reviews'::regclass
    and constraint_row.contype = 'u'
    and array_length(constraint_row.conkey, 1) = 1
    and constraint_row.conkey[1] = order_column.attnum
  limit 1;

  if order_unique_constraint is not null then
    execute format('alter table public.fyi_reviews drop constraint %I', order_unique_constraint);
  end if;
end $$;

create unique index if not exists fyi_reviews_order_product_unique
  on public.fyi_reviews(order_id, product_id)
  where order_id is not null and customer_id is not null and review_type = 'product';
create unique index if not exists fyi_reviews_order_type_unique
  on public.fyi_reviews(order_id, review_type)
  where order_id is not null and customer_id is not null and review_type <> 'product';

create table if not exists public.fyi_customer_favorites (
  customer_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null,
  created_at timestamptz not null default now(),
  primary key (customer_id, product_id),
  check (length(product_id) between 1 and 80)
);

alter table public.fyi_customer_favorites enable row level security;
revoke all on public.fyi_customer_favorites from anon, authenticated;
grant all privileges on public.fyi_customer_favorites to service_role;

drop view if exists public.fyi_product_popularity;
create view public.fyi_product_popularity
with (security_invoker = true)
as
with favorite_counts as (
  select product_id, count(*)::bigint as favorite_count
  from public.fyi_customer_favorites
  group by product_id
),
order_counts as (
  select
    item.value->>'productId' as product_id,
    sum(greatest(coalesce(nullif(item.value->>'qty','')::integer,0),0))::bigint as order_count
  from public.fyi_orders as orders
  cross join lateral jsonb_array_elements(
    case when jsonb_typeof(orders.items) = 'array' then orders.items else '[]'::jsonb end
  ) as item(value)
  where orders.payment_status = 'paid'
  group by item.value->>'productId'
)
select
  coalesce(favorite_counts.product_id, order_counts.product_id) as product_id,
  coalesce(favorite_counts.favorite_count,0) as favorite_count,
  coalesce(order_counts.order_count,0) as order_count
from favorite_counts
full outer join order_counts using (product_id);
revoke all on public.fyi_product_popularity from anon, authenticated;
grant select on public.fyi_product_popularity to service_role;

create or replace view public.fyi_staff_sales_hourly
with (security_invoker = true)
as
select date_trunc('hour', created_at) as bucket,
  count(*)::bigint as paid_order_count,
  coalesce(sum(total),0)::numeric(14,2) as sales_total
from public.fyi_orders
where payment_status = 'paid'
group by date_trunc('hour', created_at);

create or replace view public.fyi_staff_orders_hourly
with (security_invoker = true)
as
select date_trunc('hour', created_at) as bucket,
  count(*)::bigint as order_count
from public.fyi_orders
group by date_trunc('hour', created_at);

create or replace view public.fyi_staff_product_sales
with (security_invoker = true)
as
select item.value->>'productId' as product_id,
  max(coalesce(item.value->>'name', item.value->>'productName', 'Menu item')) as product_name,
  sum(case
    when coalesce(item.value->>'qty','') ~ '^[0-9]+$' then (item.value->>'qty')::bigint
    else 0
  end)::bigint as quantity_sold,
  count(distinct orders.id)::bigint as order_count
from public.fyi_orders as orders
cross join lateral jsonb_array_elements(
  case when jsonb_typeof(orders.items) = 'array' then orders.items else '[]'::jsonb end
) as item(value)
where orders.payment_status = 'paid'
  and nullif(item.value->>'productId','') is not null
group by item.value->>'productId';

create or replace view public.fyi_staff_sales_summary
with (security_invoker = true)
as
select count(*)::bigint as paid_order_count,
  coalesce(sum(total),0)::numeric(14,2) as total_sales
from public.fyi_orders
where payment_status = 'paid';

revoke all on public.fyi_staff_sales_hourly,
  public.fyi_staff_orders_hourly,
  public.fyi_staff_product_sales,
  public.fyi_staff_sales_summary
  from anon, authenticated;
grant select on public.fyi_staff_sales_hourly,
  public.fyi_staff_orders_hourly,
  public.fyi_staff_product_sales,
  public.fyi_staff_sales_summary
  to service_role;

-- These tables contain customer addresses and payment metadata.
-- No anon/authenticated policies: ONLY server's secret key may access them.
alter table public.fyi_staff enable row level security;
alter table public.fyi_store_settings enable row level security;
alter table public.fyi_orders enable row level security;
alter table public.fyi_payment_transactions enable row level security;
alter table public.fyi_reviews enable row level security;
revoke all on public.fyi_staff, public.fyi_store_settings, public.fyi_orders, public.fyi_payment_transactions, public.fyi_reviews from anon, authenticated;
grant usage on schema public to service_role;
grant all privileges on public.fyi_staff, public.fyi_store_settings, public.fyi_orders, public.fyi_payment_transactions, public.fyi_reviews to service_role;

-- Private payment proof images. Never a public Storage bucket.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fyi-payment-proofs','fyi-payment-proofs',false,2621440,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set public=false, file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;
-- No public storage policies are added. Only backend with secret key uploads/downloads.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fyi-customer-photos','fyi-customer-photos',false,5242880,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set public=false, file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "Customers can read their own profile photos" on storage.objects;
create policy "Customers can read their own profile photos"
on storage.objects for select to authenticated
using (bucket_id='fyi-customer-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists "Customers can upload their own profile photos" on storage.objects;
create policy "Customers can upload their own profile photos"
on storage.objects for insert to authenticated
with check (bucket_id='fyi-customer-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists "Customers can update their own profile photos" on storage.objects;
create policy "Customers can update their own profile photos"
on storage.objects for update to authenticated
using (bucket_id='fyi-customer-photos' and (storage.foldername(name))[1]=(select auth.uid())::text)
with check (bucket_id='fyi-customer-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists "Customers can delete their own profile photos" on storage.objects;
create policy "Customers can delete their own profile photos"
on storage.objects for delete to authenticated
using (bucket_id='fyi-customer-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);

CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  username TEXT NOT NULL DEFAULT '',
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  avatar_path TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS username TEXT NOT NULL DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_path TEXT;
UPDATE public.profiles AS profile
SET email=auth_user.email
FROM auth.users AS auth_user
WHERE auth_user.id=profile.id AND profile.email IS DISTINCT FROM auth_user.email;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
WITH duplicate_usernames AS (
  SELECT id, row_number() OVER (
    PARTITION BY lower(btrim(username)) ORDER BY created_at,id
  ) AS duplicate_number
  FROM public.profiles
  WHERE nullif(btrim(username),'') IS NOT NULL
)
UPDATE public.profiles AS profile
SET username=left(btrim(profile.username),20)||'_'||left(replace(profile.id::text,'-',''),8)
FROM duplicate_usernames AS duplicate
WHERE duplicate.id=profile.id AND duplicate.duplicate_number>1;
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_unique
  ON public.profiles (lower(username))
  WHERE nullif(btrim(username),'') IS NOT NULL;

drop view if exists public.customerfyi_list;
create view public.customerfyi_list
with (security_invoker = true)
as
select
  p.id as customer_id,
  p.username,
  p.email,
  p.full_name,
  p.phone,
  p.address,
  p.created_at as account_created_at,
  coalesce(totals.order_count,0) as order_count,
  coalesce(totals.paid_order_count,0) as paid_order_count,
  coalesce(totals.total_spent,0)::numeric(12,2) as total_spent
from public.profiles p
left join lateral (
  select
    count(*) as order_count,
    count(*) filter (where o.payment_status = 'paid') as paid_order_count,
    coalesce(sum(o.total) filter (where o.payment_status = 'paid'),0) as total_spent
  from public.fyi_orders o
  where o.customer_id = p.id
) totals on true;
revoke all on public.customerfyi_list from anon, authenticated;
grant select on public.customerfyi_list to service_role;
grant select on public.profiles,public.fyi_orders to service_role;

-- Payment records are visible to staff through this service-role-only view.
drop view if exists public.paymentfyi_list;
create view public.paymentfyi_list
with (security_invoker = true)
as
select
  t.id as transaction_id,
  t.order_id,
  t.customer_id,
  p.username,
  t.provider,
  t.payment_reference,
  t.amount_minor,
  t.currency,
  t.status as payment_status,
  o.status as order_status,
  t.payment_url,
  t.created_at,
  t.updated_at,
  coalesce(totals.paid_orders,0) as customer_paid_orders,
  coalesce(totals.total_spent,0)::numeric(12,2) as customer_total_spent
from public.fyi_payment_transactions t
join public.fyi_orders o on o.id = t.order_id
left join public.profiles p on p.id = t.customer_id
left join lateral (
  select count(*) as paid_orders, sum(paid.total) as total_spent
  from public.fyi_orders paid
  where paid.customer_id = t.customer_id and paid.payment_status = 'paid'
) totals on true;
revoke all on public.paymentfyi_list from anon, authenticated;
grant select on public.paymentfyi_list to service_role;

DROP POLICY IF EXISTS
  "Customers can read their own profile"
  ON public.profiles;

CREATE POLICY "Customers can read their own profile"
ON public.profiles
FOR SELECT
TO authenticated
USING ((SELECT auth.uid()) = id);

DROP POLICY IF EXISTS
  "Customers can insert their own profile"
  ON public.profiles;

CREATE POLICY "Customers can insert their own profile"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK ((SELECT auth.uid()) = id);

DROP POLICY IF EXISTS
  "Customers can update their own profile"
  ON public.profiles;

CREATE POLICY "Customers can update their own profile"
ON public.profiles
FOR UPDATE
TO authenticated
USING ((SELECT auth.uid()) = id)
WITH CHECK ((SELECT auth.uid()) = id);

CREATE OR REPLACE FUNCTION public.handle_new_customer()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    username,
    full_name,
    phone,
    address
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'username', NEW.raw_user_meta_data ->> 'full_name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'phone', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'address', '')
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    username = EXCLUDED.username,
    full_name = EXCLUDED.full_name,
    phone = EXCLUDED.phone,
    address = EXCLUDED.address;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS
  on_auth_user_created_profile
  ON auth.users;

CREATE TRIGGER on_auth_user_created_profile
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE PROCEDURE public.handle_new_customer();

CREATE OR REPLACE FUNCTION public.sync_customer_profile_email()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.profiles SET email=NEW.email WHERE id=NEW.id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_email_updated ON auth.users;
CREATE TRIGGER on_auth_user_email_updated
AFTER UPDATE OF email ON auth.users
FOR EACH ROW
WHEN (OLD.email IS DISTINCT FROM NEW.email)
EXECUTE PROCEDURE public.sync_customer_profile_email();

CREATE OR REPLACE FUNCTION public.enforce_profile_auth_email()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  SELECT auth_user.email INTO NEW.email
  FROM auth.users AS auth_user
  WHERE auth_user.id=NEW.id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_auth_email_guard ON public.profiles;
CREATE TRIGGER profiles_auth_email_guard
BEFORE INSERT OR UPDATE OF email ON public.profiles
FOR EACH ROW
EXECUTE PROCEDURE public.enforce_profile_auth_email();