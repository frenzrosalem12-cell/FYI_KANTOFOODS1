FYI KANTOFOODS — 6-DIGIT EMAIL RECOVERY OTP
====================================================
This patch is based on the index.jsx and AuthContext.jsx that you posted in this conversation
and the complete replacement files previously prepared for you. It has NOT been run against
your live Supabase project or tested with your current device.

FILES
-----
Customer_Expo/app/index.jsx                 REPLACE your existing file (back up first!)
Customer_Expo/context/AuthContext.jsx      REPLACE your existing file (back up first!)
Customer_Expo/app/forgot-password.jsx      CREATE this new file
Supabase/Reset_Password_Email_Template.html  COPY its contents to Supabase Dashboard only

WHAT IT DOES
------------
1. Forgot Password on login opens /forgot-password.
2. Customer enters their registered email (not the username).
3. Supabase Auth resetPasswordForEmail() sends RECOVERY OTP email.
4. Customer enters 6-digit email code, verified with verifyOtp({email,token,type:'recovery'}).
5. Supabase creates a recovery session. updateUser({password}) changes password.
6. App signs out locally and shows Back to login.

YOUR EXISTING BACKEND
---------------------
Keep running your backend for signup, menu, orders, etc. The existing endpoint
/api/public/customer-recovery is NOT used by this new EMAIL OTP screen; do not delete it
unless you're sure nothing else depends on it. No SQL migration or new OTP table is required.

SUPABASE DASHBOARD SETTINGS
---------------------------
1. Authentication > Email Templates > Reset Password.
   Subject: FYI KANTOFOODS - Password Reset Code
   Paste the contents of Supabase/Reset_Password_Email_Template.html into the template body.
   The template MUST include {{ .Token }} (not only {{ .ConfirmationURL }}).
2. Authentication > Sign In / Providers > Email: ensure email authentication is enabled.
   OTP length: 6 digits (if your dashboard exposes the length setting).
   OTP expiration: 600 seconds is a reasonable demo setting; also check project policy.
3. Authentication > SMTP Settings / Email SMTP: Enable custom SMTP for real recipients.
   For an eligible Gmail sender account (demo only):
     Sender name: FYI KANTOFOODS
     Sender email: YOUR_SENDER@gmail.com
     Host: smtp.gmail.com
     Port: 465 (or 587 if the provider expects STARTTLS)
     Username: YOUR_SENDER@gmail.com
     Password: your Google APP PASSWORD, not your normal Gmail password
   Google app passwords require 2-Step Verification and might not be available for some
   managed / advanced-protection accounts. More reliable production alternative:
   use Resend, Postmark, Brevo, or a similar transactional-email SMTP service with
   a verified sender domain.
   NEVER put an SMTP password in Customer_Expo/.env or a public Git repository.
4. The email OTP flow does not use redirect links, so no local IP URL or deep-link
   redirect allow list is required for this particular OTP flow.
5. Keep Supabase Auth rate limits active, and enable CAPTCHA/abuse protection before
   allowing anonymous public traffic. Do not disclose whether a customer email exists.

TEST USING YOUR EXPO WEB URL
----------------------------
1. Start backend in FYI_KANTOFOODS_1: npm start
2. In Customer_Expo: npx expo start --web -c
3. Open your ACTUAL Expo Web address; if currently 192.168.254.138:8081,
   use http://192.168.254.138:8081
4. Create or use a CUSTOMER account with an inbox you control.
5. Sign out; click Forgot password?; enter THAT customer's email and Send 6-digit code.
6. Check Gmail Inbox + Spam; copy the code; enter it in the app.
7. Enter and confirm a new password. Return to login.
8. Try logging in with the new password; verify profile/orders are unchanged.
9. If mail fails, inspect Supabase > Authentication > Logs and SMTP settings.
   If verification says invalid/expired, check you used the latest code and the email matches.

KNOWN LIMITATION
----------------
The verified recovery session is kept in app memory. If you close/reload the page after
entering the OTP but before saving the new password, start recovery again. This is safer
than persisting the recovery permission indefinitely.

USER SAFETY
-----------
Never share customer OTP codes, recovery tokens, SMTP credentials, Supabase service-role
keys, or actual customer passwords. Avoid account enumeration, prevent brute-force
attempts using Supabase rate limits and CAPTCHA, use HTTPS for deployment.
