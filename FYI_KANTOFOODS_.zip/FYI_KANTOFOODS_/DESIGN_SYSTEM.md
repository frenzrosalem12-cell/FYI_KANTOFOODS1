# FYI-KANTOFOODS Design System

## Design direction
Formal, approachable restaurant operations software. Prioritize legibility, operational speed, consistent navigation, and real business information over decorative effects.

## Foundations
- Primary: Forest green `#174D35`
- Action: Green `#247A50`
- Background: Soft neutral `#F5F7F5`
- Surface: White `#FFFFFF`
- Text: Charcoal `#202923`
- Muted text: `#68756D`
- Borders: `#E1E7E2`
- Typography: Inter (system sans-serif fallback)
- Shape: 8–12px radii; subtle borders and restrained shadows

## Role-specific experience
- Admin: sales, order health, customer and staff management.
- Cashier: payment verification, order acceptance and dispatch.
- Kitchen: clear order queue and preparation status.
- Customer: menu discovery, ordering, payment and delivery tracking; retain the existing mobile app navigation and brand identity.

## Interaction rules
- Keep the sidebar independently scrollable and anchored while the main workspace scrolls.
- Avoid scroll-triggered entrance animations.
- Use real operational metrics; never fabricate reviews, sales, customer counts or testimonials.
- Prefer consistent vector iconography over emoji in navigation and controls.
- Use genuine product photography and actual system screenshots only.
- Preserve existing authentication, role permissions, Supabase integration, PayMongo, order flow and delivery behavior during visual changes.

## Notes
This design update currently applies the shared staff workspace stylesheet and staff login headline. Customer Expo screens have not been visually redesigned in this pass; they require a separate native component/theme review and device testing.
