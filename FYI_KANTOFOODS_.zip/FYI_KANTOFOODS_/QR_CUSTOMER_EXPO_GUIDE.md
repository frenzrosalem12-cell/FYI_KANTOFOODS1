# FYI KANTO: One Expo Customer UI for iPhone + QR Website

This project has **one customer interface**: `Customer_Expo/` (React Native / Expo Router). The Admin's `QR Ordering URL` (`/menu`) now opens a browser build of these same screens, instead of the old `public/customer.html`. Customer orders continue through the existing Node API → Supabase, and Owner/Cashier/Kitchen remain at `/staff`.

## What changed

- `server.mjs` serves the compiled Expo web app at `/menu`, `/orders`, `/reviews`, checkout and product paths; its JavaScript, fonts and product photos are under `public/expo-web/`.
- `public/staff.js`: QR copy/preview links point to `/menu`; store status uses existing backend settings.
- `public/qr.js` / `qr.html`: QR is for `/menu`. If accessed from `localhost`, enter the Windows laptop's **Wi-Fi IPv4** before printing; `localhost` cannot be scanned from a different phone.
- `Customer_Expo/config/backend.js`: iPhone uses `EXPO_PUBLIC_API_URL` in `.env`; QR web on the Node server uses its own origin, so it calls `/api/public/*` on the same server. No Supabase secret is placed in the browser.
- `Customer_Expo/app/_layout.jsx` + `(tabs)/menu.jsx`: same mobile-sized layout in a desktop browser.
- `Customer_Expo/components/DeliveryPinMap.web.jsx` + `app/delivery-map.jsx`: added browser map selection via Leaflet/OpenStreetMap and existing demo OSRM route calculation; native iOS/Android map is unchanged. Internet is required for map services.
- `public/expo-web/`: **prebuilt browser app INCLUDED**. Normally you do not need Metro/Expo running just to open the QR page.

## Run on your Windows laptop (after extracting)

1. Open the folder containing `package.json`, `server.mjs`, and `Customer_Expo/` in VS Code.
2. **Do not share secrets.** Your uploaded ZIP contained no `.env` file. Copy your existing PRIVATE server `.env` from your previous project into the new **main folder** (or follow `.env.example` using your existing Supabase credentials). Keep your Supabase database/tables as they already are; no migration is required for the QR change.
3. In a main-folder terminal run:

   ```powershell
   npm install
   npm start
   ```

4. In your laptop browser open `http://localhost:3333/staff` for the Owner/Cashier/Kitchen dashboard. Open `http://localhost:3333/menu` to preview the **same Expo customer design** in Chrome.
5. To scan from an iPhone, run `ipconfig` on the Windows laptop; find **Wi-Fi IPv4 Address**, such as `192.168.1.12`. On the phone, connected to the **same Wi-Fi**, visit `http://192.168.1.12:3333/menu`. The example IP is not necessarily yours.
6. In Admin → Settings → `Open printable QR poster`, if the page address is `localhost`, enter your Wi-Fi IPv4 into the QR poster field; print only after the QR URL shows your Wi-Fi IP. Or open the Admin itself using `http://YOUR_IP:3333/staff` so the printable QR uses that IP automatically.
7. In Owner Settings, set **Open — demo override** then Save Settings to test after 8 PM; restore **Automatic by schedule** when finished. The Expo web and iPhone customer apps check `/api/public/config` approximately every 30 seconds.

## Run the same UI in iPhone Expo Go

1. Preserve your existing `Customer_Expo/.env` with your Wi-Fi IP, or create it by copying `Customer_Expo/.env.example` and replacing the IP.
2. In a second terminal:

   ```powershell
   cd Customer_Expo
   npm install
   npx expo start -c
   ```

3. Scan the Metro QR using the iPhone's Camera. Your phone and laptop must reach each other on the same Wi-Fi.

**Expo Go's QR and the Admin's QR Ordering URL are different:** Expo Go's Metro QR opens the development app; Admin's QR opens its browser version for customers without needing Expo Go. Both use the same customer UI source, and the same Node/Supabase backend.

## After editing the Expo design

The browser's compiled build is not automatically updated when you edit the Expo source. Rebuild it in the **main folder** (after `Customer_Expo` dependencies are installed):

```powershell
npm run build:customer-web
```

Refresh the `/menu` webpage. `npm start` can stay running; reload the browser when rebuild finishes.

If you remove `public/expo-web/`, `/menu` falls back to the Expo development web server on port **8081**; then run `cd Customer_Expo` and `npx expo start --web`. A prebuilt web folder is included in this ZIP, so the fallback should not be needed for normal demos.

## Known limitations — please read

- **Only a local classroom demo:** do not expose the HTTP server, PIN login or payments to the public internet or accept real payments without a security review, HTTPS and verified payment workflow.
- **Web maps** require the Leaflet CDN, OpenStreetMap tiles and the demonstration OSRM routing service. Browser "Use my current location" may require HTTPS; the manual map pin works on LAN if the external map services load. Verify any road-distance/fee quote before real deliveries.
- The store pin is explicitly a *demonstration campus location*, not the verified shop entrance.
- **Your original ZIP did not contain Supabase SQL schema or private `.env` files.** The new ZIP excludes secrets and large generated `node_modules`; preserve your existing configured Supabase project and server credentials. For a brand-new database, you would need the original schema from your earlier project.
- React Native iOS/Android and web differ in capabilities. The Expo Web build succeeded, but a real Supabase-connected, end-to-end order test on your device is still required.
