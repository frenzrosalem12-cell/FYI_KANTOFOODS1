# FYI-KANTO Foods — Organized project (Customer_Expo + Backend)

This is a **reorganized copy** of the previously uploaded `fyi_kantofoods.zip`.
It does **not** contain the latest changes made only on your Windows laptop or Git branch.
Your original repository is NOT modified. This ZIP includes **no `.env`, Git history, installed node_modules, or generated Expo build files**.

## Folder structure

- `Customer_Expo/`: React Native / Expo SDK 58 customer app (`app`, `assets`, `components`, `config`, `constants`, `context`, `data`, `app.json`, Babel config, Expo `package.json`).
- Main/root: Node.js backend and staff website (`server.mjs`, `db.mjs`, `paymongo.mjs`, `public/`, `supabase/`, `scripts/`, `catalog.json`).
- Root `package.json` starts the backend. `Customer_Expo/package.json` starts the Expo app.
- Three missing source product images were restored from `public/assets/products/` to `Customer_Expo/assets/products/`.

## Credentials — two LOCAL `.env` files; neither is in ZIP

1. Copy `.env.example` to **root `.env`** and set `SUPABASE_URL` and `SUPABASE_SECRET_KEY` (backend ONLY). Never share/upload this file.
2. Copy `Customer_Expo/.env.example` to **Customer_Expo/.env** and set the laptop's current Wi-Fi IP, Supabase project URL, and **publishable** key. No secret keys in Expo.
3. `.gitignore` already excludes both `.env` files. This ZIP does not include any Git history; do not paste old secrets into Git.

## Run on Windows (two terminals)

**Terminal 1 — Backend + Admin/Cashier/Kitchen:**
```powershell
cd "C:\PATH\TO\FYI_KANTO_Organized"
npm install
npm start
```

- Open `http://localhost:3333/staff` for staff login.
- Check `http://localhost:3333/api/public/config` for the public configuration endpoint.
- Setup (`npm run setup`) should only be used after checking the existing Supabase staff accounts, not automatically.

**Terminal 2 — Customer Expo on iPhone:**
```powershell
cd "C:\PATH\TO\FYI_KANTO_Organized\Customer_Expo"
npm install
npx expo install --fix
npx expo start --tunnel -c
```

- This example is SDK 58 aligned because the current iOS Expo Go installed version is SDK 58. Expo dependencies still need installing/testing on your own machine.
- Use `npx expo-doctor@latest` to check dependencies.
- Both iPhone and laptop must be able to reach port 3333 (same reachable Wi-Fi); Expo Tunnel **does not tunnel the backend**.

## Expo Web / customer browser QR

The original `public/expo-web/` compiled files are omitted to avoid stale generated assets. To build the browser version after installing Expo dependencies:
```powershell
# Run in the ROOT folder
npm run build:customer-web
```

The Node backend serves the generated web build from `public/expo-web/`. The iPhone Expo Go QR is different from the website ordering QR.

## Important

- **Do not overwrite your current working `fyi_kantofoods` folder.** Extract this ZIP somewhere else and compare/test first.
- **This is a structural reorganization, not an end-to-end tested deployed application.** Expo, Supabase, routing, PayMongo, and customer signup should each be tested.
- **Existing Supabase DB:** your tables are already present. Do NOT rerun `supabase/schema.sql` or migrations without review/backups.
- Public OSRM demo road routing may time out; reorganizing folders does not automatically fix road-route calculation.
- `README.md` and `START_HERE.md` are original documents and may contain outdated guidance. Follow this file first.
- GitHub changes: if you intend to merge back, coordinate with your groupmate and review the folder moves and package dependencies in a separate branch.
