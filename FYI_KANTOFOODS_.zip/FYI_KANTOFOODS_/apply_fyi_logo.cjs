// FYI Smart Menu — replace the staff login/sidebar FYI letters with your existing customer logo.
// Usage: node apply_fyi_logo.cjs "Customer_Expo\assets\images\your-logo.png"
// Alternatively, copy your logo to public/images/fyi-logo.png first, then run without arguments.
// Does not change server.mjs, staff.js, login sessions, PayMongo, or Supabase.
const fs = require('node:fs');
const path = require('node:path');

const root = process.cwd();
const publicDir = path.join(root, 'public');
const htmlPath = path.join(publicDir, 'staff.html');
const imageDir = path.join(publicDir, 'images');
const marker = 'FYI_CUSTOM_LOGO_PATCH_V1';

function stop(message) {
  console.error('\nERROR: ' + message);
  process.exit(1);
}

if (!fs.existsSync(htmlPath)) {
  stop('Cannot find public/staff.html. Open the FYI_KANTOFOODS_1 project folder first.');
}
fs.mkdirSync(imageDir, { recursive: true });

let logoPath;
const sourceArg = process.argv[2];
if (sourceArg) {
  const source = path.resolve(root, sourceArg);
  if (!fs.existsSync(source) || !fs.statSync(source).isFile()) {
    stop('Logo file not found: ' + source);
  }
  const extension = path.extname(source).toLowerCase();
  if (!['.png', '.jpg', '.jpeg', '.webp', '.svg'].includes(extension)) {
    stop('Use a PNG, JPG, WEBP, or SVG logo image.');
  }
  logoPath = path.join(imageDir, 'fyi-logo' + extension);
  if (path.resolve(source) !== path.resolve(logoPath)) fs.copyFileSync(source, logoPath);
} else {
  logoPath = ['.png', '.webp', '.jpg', '.jpeg', '.svg']
    .map(ext => path.join(imageDir, 'fyi-logo' + ext))
    .find(p => fs.existsSync(p));
  if (!logoPath) {
    stop('Copy your existing customer logo to public/images/fyi-logo.png, OR provide its path as an argument.');
  }
}

let html = fs.readFileSync(htmlPath, 'utf8');
if (html.includes(marker)) {
  stop('Logo patch already exists in public/staff.html. No files were changed.');
}
if (!/<\/body\s*>/i.test(html)) stop('public/staff.html has no closing </body> tag; no changes made.');

const logoUrl = '/images/' + path.basename(logoPath);
const insertion = `
<!-- ${marker}: only updates visible FYI badge icons, preserving staff functionality -->
<style>
.fyi-custom-logo-host {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  overflow: hidden !important;
  background: transparent !important;
  color: transparent !important;
  line-height: normal !important;
}
.fyi-custom-logo-img {
  display: block !important;
  width: 100% !important;
  height: 100% !important;
  max-width: 85px;
  max-height: 85px;
  object-fit: contain !important;
}
</style>
<script>
(() => {
  'use strict';
  const logoUrl = ${JSON.stringify(logoUrl)};
  // Only replace small leaf elements showing the exact FYI letters,
  // not brand names, other labels, or dashboard data.
  function applyLogo() {
    document.querySelectorAll('div, span, b, strong').forEach(el => {
      if (el.dataset.fyiCustomLogo || el.children.length || el.textContent.trim() !== 'FYI') return;
      const box = el.getBoundingClientRect();
      if (box.width > 140 || box.height > 140) return;
      const img = document.createElement('img');
      img.src = logoUrl;
      img.alt = 'FYI Kanto logo';
      img.className = 'fyi-custom-logo-img';
      el.dataset.fyiCustomLogo = '1';
      el.classList.add('fyi-custom-logo-host');
      el.replaceChildren(img);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyLogo, { once: true });
  } else applyLogo();
  // Staff UI may update parts of the page after sign-in.
  const observer = new MutationObserver(() => {
    observer.disconnect();
    applyLogo();
    observer.observe(document.body, { childList: true, subtree: true });
  });
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => observer.observe(document.body, { childList: true, subtree: true }), { once: true });
  } else observer.observe(document.body, { childList: true, subtree: true });
})();
</script>
`;

const backupName = 'staff.html.backup-logo-' + new Date().toISOString().replace(/[:.]/g, '-') ;
const backupPath = path.join(publicDir, backupName);
fs.copyFileSync(htmlPath, backupPath);
html = html.replace(/<\/body\s*>/i, insertion + '\n</body>');
fs.writeFileSync(htmlPath, html, 'utf8');

console.log('\nSUCCESS! FYI custom logo installed.');
console.log('Logo: ' + logoPath);
console.log('HTML: ' + htmlPath);
console.log('Backup: ' + backupPath);
console.log('Refresh http://localhost:3333/staff with Ctrl+Shift+R.');
console.log('No changes were made to authentication, PayMongo, or database files.');
