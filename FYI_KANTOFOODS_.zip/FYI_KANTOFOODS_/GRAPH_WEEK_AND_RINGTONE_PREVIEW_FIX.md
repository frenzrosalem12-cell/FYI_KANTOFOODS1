# FYI-KANTOFOODS Graph and Ringtone Preview Fix

Applied to the latest uploaded `FYI_KANTOFOODS_Z` project.

## Fixes
- Admin Settings now contains shared Cashier and Kitchen ringtone uploads and preview controls.
- Ringtones are server-stored and shared across staff browsers (rather than being saved only in the uploader's local IndexedDB).
- Upload accepts MP3, WAV, OGG, M4A and AAC, capped at 3.5 MiB each.
- Preview and playback use Web Audio decoding; invalid/unplayable audio returns a clearer message instead of a browser `<audio>` unsupported-source error.
- Cashier and Kitchen dashboards retain their own mute/unmute controls but no longer have upload controls.
- Dashboard graphs now include Today/Week/Month/Year selectors.
- Weekly analytics aggregate directly from source orders rather than relying on analytics views that may silently return no rows.

## Checks
- `node --check server.mjs`, `public/staff.js`, and `db.mjs` passed.
- `npm test` passed.
- `npm run check` passed.
- Live Supabase, payment, multi-device, and audio device testing still required.

## Storage note
Uploaded ringtones are stored under `data/staff-sounds` on the running server. Deployments must use persistent server storage and keep this directory when redeploying.
