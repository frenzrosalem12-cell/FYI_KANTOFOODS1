﻿
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import {WebSocket, WebSocketServer} from 'ws';
import * as database from './db.mjs';
import {createPayMongoPaymentIntent, getPayMongoPaymentIntent, verifyPayMongoWebhook} from './paymongo.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const CATALOG = JSON.parse(
  fs.readFileSync(path.join(ROOT, 'catalog.json'), 'utf8')
);
const PORT = Number(process.env.PORT || 3333);
// Expo Web is the SAME customer UI as the iPhone app. Build it with:
//   npm run build:customer-web
// The build is kept out of staff files and contains no secret keys.
const CUSTOMER_WEB_DIR = path.join(ROOT, 'public', 'expo-web');
const CUSTOMER_WEB_INDEX = path.join(CUSTOMER_WEB_DIR, 'index.html');
const EXPO_DEV_PORT = /^\d{2,5}$/.test(process.env.EXPO_WEB_DEV_PORT || '')
  ? Number(process.env.EXPO_WEB_DEV_PORT) : 8081;

// Expo Router URLs used by the mobile customer UI.
const CUSTOMER_APP_ROUTES = new Set([
  '/menu', '/order', '/orders', '/reviews', '/order-type', '/customer-info',
  '/delivery-map', '/order-summary', '/confirmation', '/profile',
  '/reset-password'
]);
function isCustomerAppRoute(p) {
  return CUSTOMER_APP_ROUTES.has(p) || p.startsWith('/product/');
}

const sessions = new Map();
const loginAttempts = new Map();
const publicAttempts = new Map();
const paymongoStatusChecks = new Map();

const nonce = () => crypto.randomBytes(24).toString('hex');
const safe = (s, n = 200) =>
  String(s ?? '').trim().slice(0, n);

// Philippine time
const PH = (d = new Date()) => {
  const dt = new Date(d.getTime() + 8 * 3600000);
  return {
    day: dt.getUTCDay(),
    minute: dt.getUTCHours() * 60 + dt.getUTCMinutes()
  };
};

// Store open/closed setting controlled by Admin
function isOpen(settings) {
  const a = settings.open.split(':').map(Number);
  const b = settings.close.split(':').map(Number);

  const start = a[0] * 60 + a[1];
  const end = b[0] * 60 + b[1];
  const t = PH().minute;

  if (settings.override === 'open') return true;
  if (settings.override === 'closed') return false;

  if (start === end) return false;

  return start < end
    ? t >= start && t < end
    : t >= start || t < end;
}

let storeBoundaryTimer=null;
function scheduleNextStoreBoundary(settings) {
  clearTimeout(storeBoundaryTimer);
  const [openHour,openMinute]=settings.open.split(':').map(Number);
  const [closeHour,closeMinute]=settings.close.split(':').map(Number);
  const opening=openHour*60+openMinute;
  const closing=closeHour*60+closeMinute;
  if(opening===closing)return;
  const currentMinute=PH().minute;
  const minutesUntilBoundary=[opening,closing].reduce((nearest,boundary)=>{
    const delta=(boundary-currentMinute+1440)%1440||1440;
    return Math.min(nearest,delta);
  },1440);
  const delay=60000-(Date.now()%60000)+(minutesUntilBoundary-1)*60000;
  storeBoundaryTimer=setTimeout(async()=>{
    try {
      const currentSettings=await database.settings();
      broadcastStoreStatus(currentSettings);
      scheduleNextStoreBoundary(currentSettings);
    } catch(error) {
      console.error('Unable to refresh scheduled store status:',error.message);
      storeBoundaryTimer=setTimeout(()=>scheduleNextStoreBoundary(settings),60000);
    }
  },delay);
}

function json(res, value, status = 200, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...headers
  });
  res.end(JSON.stringify(value));
}

const bad = (res, msg, status = 400) =>
  json(res, { error: msg }, status);

const cookie = (req, name) => {
  const value = (req.headers.cookie || '').match(
    new RegExp('(?:^|; )' + name + '=([^;]+)')
  );
  return value ? decodeURIComponent(value[1]) : null;
};

// FYI_STAFF_SESSION_FIX_V1: separate HttpOnly cookies for owner, cashier, kitchen.
const STAFF_ROLES=new Set(['owner','cashier','kitchen']);
function requestedStaffRole(req){
  let role=typeof req.headers['x-fyi-staff-role']==='string'
    ?req.headers['x-fyi-staff-role']:null;
  // Normal HTML image links cannot send custom headers.
  if(!role&&String(req.url||'').startsWith('/api/staff/proof/')){
    try{role=new URL(req.url,'http://localhost').searchParams.get('staff_role');}
    catch{}
  }
  return STAFF_ROLES.has(role)?role:null;
}
function sessionCookie(id,expire=false,role='owner'){
  if(!STAFF_ROLES.has(role))throw Error('Unknown staff role.');
  return 'fyi_session_'+role+'='+id+'; HttpOnly; SameSite=Lax; Path=/; Max-Age='+
    (expire?0:28800)+(process.env.NODE_ENV==='production'?'; Secure':'');
}
async function current(req){
  const role=requestedStaffRole(req);
  const sid=cookie(req,role?'fyi_session_'+role:'fyi_session');
  const s=sessions.get(sid);
  if(!s)return null;
  if(Date.now()>s.expires){sessions.delete(sid);return null;}
  if(role&&s.role!==role)return null;
  const staff=await database.staffById(s.id);
  if(!staff||(role&&staff.role!==role))return null;
  return staff;
}

async function staffRole(req, res, roles) {
  const user = await current(req);

  if (!user) {
    bad(res, 'Please sign in.', 401);
    return null;
  }

  if (!roles.includes(user.role)) {
    bad(res, 'Not allowed for this staff role.', 403);
    return null;
  }

  return user;
}

const MAXBODY = 6 * 1024 * 1024;

async function rawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let length = 0;
    let failed = false;

    req.on('data', chunk => {
      if (failed) return;

      length += chunk.length;

      if (length > MAXBODY) {
        failed = true;
        reject(
          Object.assign(Error('Request too large.'), {
            status: 413
          })
        );
        return;
      }

      chunks.push(chunk);
    });

    req.on('end', () => {if(!failed)resolve(Buffer.concat(chunks));});

    req.on('error', reject);
  });
}

async function body(req) {
  const raw=await rawBody(req);
  try{return JSON.parse(raw.toString('utf8')||'{}');}
  catch{throw Error('Invalid JSON body.');}
}

function checkRate(map, key, max, window) {
  const now = Date.now();
  const arr = (map.get(key) || []).filter(
    n => n + window > now
  );

  if (arr.length >= max) {
    map.set(key, arr);
    return false;
  }

  arr.push(now);
  map.set(key, arr);
  return true;
}

async function customerFromAuthorization(req){
  const authorization=String(req.headers.authorization||'');
  const match=authorization.match(/^Bearer ([^\s]+)$/);
  return match?database.customerFromToken(match[1]):null;
}

function feeFromKm(km) {
  if (km < 1) return 0;
  return 15 + 10 * Math.floor(
    Math.round(km * 100) / 100 - 1
  );
}

function manilaCalendarDate(date){
  const values=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{
    timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'
  }).formatToParts(date).filter(part=>part.type!=='literal').map(part=>[part.type,Number(part.value)]));
  return values;
}
function dashboardRange(period,now=new Date()){
  const {year,month,day}=manilaCalendarDate(now);
  const utcDay=Date.UTC(year,month-1,day);
  const todayStart=new Date(utcDay-8*60*60*1000);
  let startDay=utcDay;
  if(period==='week'){
    const weekday=new Date(utcDay).getUTCDay();
    startDay-=((weekday+6)%7)*86400000;
  }else if(period==='month'){
    startDay=Date.UTC(year,month-1,1);
  }else if(period==='year'){
    startDay=Date.UTC(year,0,1);
  }else if(period!=='today'){
    throw Object.assign(Error('Choose a valid dashboard date range.'),{status:400});
  }
  return {
    start:new Date(startDay-8*60*60*1000).toISOString(),
    end:now.toISOString(),
    todayStart:todayStart.toISOString(),
    now:now.toISOString()
  };
}

// Merge source catalog with owner edits and custom items saved in Supabase.
// Never trust pricing or product availability sent from a customer's device.
async function liveCatalog(includeInactive = false){
  const changes = await database.menuProductOverrides();
  const products = new Map(CATALOG.products.map(product => [product.id, {...product,active:true}]));
  for (const row of changes){
    if (row.is_deleted){ products.delete(row.product_id); continue; }
    const original = products.get(row.product_id) || {};
    products.set(row.product_id,{...original,...row.product, id:row.product_id});
  }
  return {...CATALOG, products:[...products.values()].filter(p => includeInactive || p.active !== false)};
}
async function staffCatalog(includeInactive = true){
  const [base,menu]=await Promise.all([liveCatalog(includeInactive),database.menuConfiguration()]);
  return {
    ...base,
    categories:[...CATALOG.categories,...menu.categories],
    menuAddons:menu.addons
  };
}
async function customerCatalog(includeInactive = false){
  const [base,menu]=await Promise.all([liveCatalog(includeInactive),database.menuConfiguration()]);
  const addOns={...base.addOns};
  const products=base.products.map(product=>{
    const assigned=new Set(product.addonIds||[]);
    const custom=menu.addons.filter(addon=>addon.active!==false&&(
      assigned.has(addon.id)||
      (Array.isArray(addon.categoryIds)&&addon.categoryIds.includes(product.category))||
      (Array.isArray(addon.productIds)&&addon.productIds.includes(product.id))
    )).map(addon=>({id:addon.id,label:addon.name,price:addon.price}));
    if(!custom.length)return product;
    const groupId='staff-'+product.id;
    const options=[...(base.addOns[product.addOns]||[])];
    for(const addon of custom)if(!options.some(option=>option.id===addon.id))options.push(addon);
    addOns[groupId]=options;
    return {...product,addOns:groupId};
  });
  return {
    ...base,
    categories:[...CATALOG.categories,...menu.categories],
    products,
    addOns
  };
}
function validateMenuProduct(raw,id,categories,menuAddons,existing){
  if (!raw || typeof raw !== 'object') throw Object.assign(Error('Invalid product.'),{status:400});
  const name = safe(raw.name,100), description=safe(raw.description,500);
  const category = safe(raw.category,60), addOns=safe(raw.addOns,40);
  if(name.length<2 || name.length>100)throw Object.assign(Error('Product name must be 2â€“100 characters.'),{status:400});
  if(!categories.some(c=>c.id===category))throw Object.assign(Error('Invalid category.'),{status:400});
  if(addOns && !Object.hasOwn(CATALOG.addOns,addOns))throw Object.assign(Error('Invalid add-on group.'),{status:400});
  if(!Array.isArray(raw.sizes)||raw.sizes.length<1||raw.sizes.length>5)throw Object.assign(Error('Add 1â€“5 size/price options.'),{status:400});
  const sizes=raw.sizes.map(s=>({label:safe(s?.label,35),price:Number(s?.price)}));
  if(sizes.some(s=>!s.label || !Number.isFinite(s.price)||s.price<1||s.price>100000||Math.abs(Math.round(s.price*100)-s.price*100)>1e-6))
    throw Object.assign(Error('Each size needs a label and a valid price.'),{status:400});
  if(new Set(sizes.map(s=>s.label.toLowerCase())).size!==sizes.length)
    throw Object.assign(Error('Size labels must be unique.'),{status:400});
  const variants=Array.isArray(raw.variants)?raw.variants.map(v=>safe(v,30)).filter(Boolean):[];
  if(variants.length>10)throw Object.assign(Error('Too many flavors/variants.'),{status:400});
  const addonIds=Array.isArray(raw.addonIds)?[...new Set(raw.addonIds.map(x=>safe(x,60)))]:[];
  if(addonIds.length>30||addonIds.some(addonId=>{
    const addon=menuAddons.find(item=>item.id===addonId);
    if(!addon)return true;
    if(addon.active===false&&!(existing?.addonIds||[]).includes(addonId))return true;
    const targetsCategories=Array.isArray(addon.categoryIds)?addon.categoryIds:[];
    const targetsProducts=Array.isArray(addon.productIds)?addon.productIds:[];
    return (targetsCategories.length||targetsProducts.length)&&
      !targetsCategories.includes(category)&&!targetsProducts.includes(id);
  }))throw Object.assign(Error('One or more selected add-ons are unavailable for this product.'),{status:400});
  return {id,name,category,description,sizes,addOns,addonIds,variants,active:raw.active!==false};
}

function priceItems(items, currentCatalog) {
  if (!Array.isArray(items) || items.length < 1 || items.length > 30) {
    throw Error('Add at least one menu item.');
  }

  let subtotal = 0;
  const priced = [];

  for (const raw of items) {
    const p = currentCatalog.products.find(
      q => q.id === raw.productId
    );

    if (!p || p.unavailable || p.active === false) {
      throw Error('Unknown or unavailable menu product.');
    }

    const size = p.sizes.find(
      q => q.label === raw.size
    );

    if (!size) throw Error('Invalid product size.');

    const qty = Number(raw.qty);

    if (!Number.isInteger(qty) || qty < 1 || qty > 30) {
      throw Error('Invalid quantity.');
    }

    const addOns = currentCatalog.addOns[p.addOns] || [];
    const ids = Array.isArray(raw.addOnIds)
      ? [...new Set(raw.addOnIds)]
      : [];

    if (ids.length > 6) {
      throw Error('Too many add-ons.');
    }

    let adds = 0;

    for (const id of ids) {
      const a = addOns.find(v => v.id === id);
      if (!a) throw Error('Invalid add-on.');
      adds += a.price;
    }

    const variant = safe(raw.variant, 30);

    if (variant && !(p.variants || []).includes(variant)) {
      throw Error('Invalid variant.');
    }

    const unit = size.price + adds;
    subtotal += unit * qty;

    priced.push({
      productId: p.id,
      name: p.name,
      size: size.label,
      variant,
      addOnIds: ids,
      qty,
      unit,
      lineTotal: unit * qty
    });
  }

  return { items: priced, subtotal };
}

// Same byte-level validation as GCash proof, but product images are owner-only.
function decodeProductImage(raw){
  if(typeof raw!=='string')throw Object.assign(Error('Choose an image first.'),{status:400});
  const match=raw.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
  if(!match)throw Object.assign(Error('Use a JPG, PNG or WebP image.'),{status:400});
  const bytes=Buffer.from(match[2],'base64');
  if(bytes.length<100 || bytes.length>2*1024*1024)
    throw Object.assign(Error('Image must be under 2 MB.'),{status:413});
  const jpeg=bytes[0]===0xff && bytes[1]===0xd8 && bytes[2]===0xff;
  const png=bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'));
  const webp=bytes.toString('ascii',0,4)==='RIFF' && bytes.toString('ascii',8,12)==='WEBP';
  if(!((match[1]==='jpeg'&&jpeg)||(match[1]==='png'&&png)||(match[1]==='webp'&&webp)))
    throw Object.assign(Error('Image content does not match its file type.'),{status:400});
  return {bytes,ext:match[1]==='jpeg'?'jpg':match[1],mime:'image/'+match[1]};
}

function decodeProof(raw) {
  if (typeof raw !== 'string') {
    throw Error('Attach a GCash proof image.');
  }

  const m = raw.match(
    /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/
  );

  if (!m) {
    throw Error('Proof must be a JPG, PNG or WEBP image.');
  }

  const bytes = Buffer.from(m[2], 'base64');

  if (bytes.length < 150 || bytes.length > 2.5 * 1024 * 1024) {
    throw Error('Proof must be between 150 bytes and 2.5 MB.');
  }

  const jpg = bytes[0] === 255 && bytes[1] === 216;
  const png = bytes.subarray(0, 8).equals(
    Buffer.from('89504e470d0a1a0a', 'hex')
  );
  const webp =
    bytes.subarray(0, 4).toString() === 'RIFF' &&
    bytes.subarray(8, 12).toString() === 'WEBP';

  if (!(
    (m[1] === 'jpeg' && jpg) ||
    (m[1] === 'png' && png) ||
    (m[1] === 'webp' && webp)
  )) {
    throw Error('Invalid image data.');
  }

  return {
    bytes,
    ext: m[1] === 'jpeg' ? 'jpg' : m[1],
    mime: 'image/' + m[1]
  };
}

async function roadRoute(lat, lng, store) {
  if (
    !Number.isFinite(lat) ||
    !Number.isFinite(lng) ||
    Math.abs(lat) > 90 ||
    Math.abs(lng) > 180
  ) {
    throw Error('Select a delivery pin.');
  }

  const slat = Number(store.lat);
  const slng = Number(store.lng);

  if (!Number.isFinite(slat) || !Number.isFinite(slng)) {
    throw Error('Store location not configured.');
  }

  const url = `https://router.project-osrm.org/route/v1/driving/${slng},${slat};${lng},${lat}?overview=full&geometries=geojson&steps=false`;

  const controller = new AbortController();
  const timer = setTimeout(
    () => controller.abort(),
    7500
  );

  try {
    const r = await fetch(url, {
      signal: controller.signal
    });

    if (!r.ok) throw Error('Route unavailable.');

    const d = await r.json();

    if (!Number.isFinite(d.routes?.[0]?.distance)) {
      throw Error('No driving route.');
    }

    const km = Math.round(d.routes[0].distance / 10) / 100;

    if (km > 20) {
      throw Error(
        'The delivery pin is outside the 20 km demo service area.'
      );
    }

    const coordinates=(d.routes[0].geometry?.coordinates||[])
      .map(([longitude,latitude])=>({latitude,longitude}))
      .filter(point=>Number.isFinite(point.latitude)&&Number.isFinite(point.longitude));
    return {km,coordinates,storeLatitude:slat,storeLongitude:slng};
  } catch (e) {
    if (e.message.includes('20 km')) throw e;
    throw Error(
      'Road routing is temporarily unavailable. Try again shortly.'
    );
  } finally {
    clearTimeout(timer);
  }
}

async function roadDistance(lat,lng,store){
  return (await roadRoute(lat,lng,store)).km;
}

function serializeOrder(o, publicView = false) {
  const x = {
    id: o.id,
    type: o.type,
    status: o.status,
    paymentStatus: o.paymentStatus,
    items: o.items,
    subtotal: o.subtotal,
    deliveryFee: o.deliveryFee,
    total: o.total,
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
    customer: publicView
      ? {
          name: o.customer.name,
          address: o.customer.address
        }
      : o.customer,
    notes: o.customer.notes,
    roadKm: o.roadKm,
    history: o.history,
    reviewed: o.reviewed
  };

  if (!publicView) {
    x.paymentMethod = o.paymentMethod;
    x.paymentReference = o.paymentReference;
    x.gcashReference = o.gcashReference;
    x.hasProof = !!o.proofPath;
  }

  return x;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.json': 'application/json; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.map': 'application/json; charset=utf-8'
};

function serve(req, res, p) {
  const base = path.join(ROOT, 'public');
  const full = path.resolve(base, '.' + p);

  if (!full.startsWith(base + path.sep)) {
    res.writeHead(403);
    res.end();
    return;
  }

  fs.stat(full, (err, s) => {
    if (err || !s.isFile()) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }

    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full)] ||
        'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'public, max-age=120'
    });

    fs.createReadStream(full).pipe(res);
  });
}

// Safely serve the compiled Expo Web build. All Expo routes load the same SPA
// index; Expo Router handles navigation in the browser.
function serveExpoWeb(req, res, resource) {
  const full = path.resolve(CUSTOMER_WEB_DIR, '.' + resource);
  if (!full.startsWith(CUSTOMER_WEB_DIR + path.sep)) {
    res.writeHead(403); res.end(); return;
  }
  fs.stat(full, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404); res.end('Expo asset not found'); return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': resource.endsWith('.html') ? 'no-cache' : 'public, max-age=120'
    });
    fs.createReadStream(full).pipe(res);
  });
}

function redirectToExpoDev(req, res, p) {
  // Works on the same LAN: laptop:3333/menu -> laptop:8081/menu.
  // npx expo start --web must be running if no compiled build is available.
  let host = 'localhost';
  try { host = new URL('http://' + req.headers.host).hostname; } catch {}
  const destination = `http://${host}:${EXPO_DEV_PORT}${p}`;
  res.writeHead(302, {Location: destination, 'Cache-Control': 'no-store'});
  res.end();
}

function validClock(v) {
  if (typeof v !== 'string' || !/^\d\d:\d\d$/.test(v)) {
    return false;
  }

  const [h, m] = v.split(':').map(Number);
  return h <= 23 && m <= 59;
}

// ========================================
// CUSTOMER WEB CORS FIX
// ========================================

function isTrustedCustomerWebOrigin(origin, backendHostHeader) {
  if (!origin) return false;

  try {
    const parsed = new URL(origin);

    if (
      process.env.ALLOWED_WEB_ORIGIN &&
      parsed.origin === process.env.ALLOWED_WEB_ORIGIN
    ) {
      return true;
    }

    const backendHost = new URL(
      'http://' + (backendHostHeader || 'localhost')
    ).hostname;

    return (
      parsed.protocol === 'http:' &&
      ['8081', '8082', '19000', '19006'].includes(parsed.port) &&
      (
        parsed.hostname === 'localhost' ||
        parsed.hostname === '127.0.0.1' ||
        parsed.hostname === backendHost
      )
    );
  } catch {
    return false;
  }
}

function validatedCustomerRecoveryRedirect(value,req){
  if(typeof value!=='string'||value.length>500)
    throw Error('Password recovery redirect is not configured for this app.');
  let target;
  try{target=new URL(value);}
  catch{throw Error('Password recovery redirect is invalid.');}

  if(target.protocol==='fyikanto:'&&target.hostname==='reset-password'&&
     (target.pathname===''||target.pathname==='/')&&!target.search&&!target.hash)
    return target.toString();

  if(!['http:','https:'].includes(target.protocol)||target.pathname!=='/reset-password'||
     target.search||target.hash)
    throw Error('Password recovery redirect must point to the reset-password screen.');

  const allowedOrigin=process.env.ALLOWED_WEB_ORIGIN?.trim();
  const requestOrigin=String(req.headers.origin||'');
  const sameRequestHost=target.host.toLowerCase()===
    String(req.headers.host||'').toLowerCase()&&requestOrigin===target.origin;
  const trustedWebOrigin=requestOrigin===target.origin&&
    isTrustedCustomerWebOrigin(requestOrigin,req.headers.host);
  if(target.origin!==allowedOrigin&&!sameRequestHost&&!trustedWebOrigin)
    throw Error('Password recovery redirect is not an allowed website address.');
  return target.toString();
}

// ========================================
// MAIN SERVER
// ========================================

async function handle(req, res) {
  const url = new URL(
    req.url,
    'http://' + (req.headers.host || 'localhost')
  );

  const p = url.pathname;
  const method = req.method;
  const ip = req.socket.remoteAddress || '?';

  // CORS only for public customer API
  const publicApi = p.startsWith('/api/public/');

  const allowedCustomerOrigin =
    publicApi &&
    isTrustedCustomerWebOrigin(
      req.headers.origin,
      req.headers.host
    );

  if (allowedCustomerOrigin) {
    res.setHeader(
      'Access-Control-Allow-Origin',
      req.headers.origin
    );
    res.setHeader('Vary', 'Origin');
    res.setHeader(
      'Access-Control-Allow-Methods',
      'GET, POST, OPTIONS'
    );
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Content-Type, Authorization'
    );
  }

  if (method === 'OPTIONS') {
    if (req.headers.origin && !allowedCustomerOrigin) {
      return bad(
        res,
        'Cross-origin request not allowed.',
        403
      );
    }

    res.writeHead(204, {
      Allow: 'GET, POST, OPTIONS'
    });

    res.end();
    return;
  }

  if(method==='POST'&&p==='/webhooks/paymongo'){
    const raw=await rawBody(req);
    let payload;
    try{payload=JSON.parse(raw.toString('utf8')||'{}');}
    catch{return bad(res,'Invalid PayMongo webhook payload.');}
    if(!verifyPayMongoWebhook(req.headers['paymongo-signature'],raw.toString('utf8'))){
      return bad(res,'Invalid PayMongo webhook signature.',401);
    }

const event=payload?.data?.attributes?.type
  ? payload.data.attributes
  : payload?.data?.type
    ? payload.data
    : null;

if(!event?.type || !event?.data){
  return bad(res,'Invalid PayMongo event structure.');
}

if(event.livemode!==false){
  return bad(res,'Unexpected live payment event.',400);
}


if(!event?.type || !event?.data){
  return bad(res,'Invalid PayMongo event structure.');
}

if(event.livemode!==false){
  return bad(res,'Unexpected live payment event.',400);
}
    if(event?.type==='checkout_session.payment.paid'){
      const checkout=event.data;
      const checkoutId=checkout?.id;
      const reference=checkout?.attributes?.reference_number;
      if(typeof checkoutId!=='string'||typeof reference!=='string'){
        return bad(res,'PayMongo webhook is missing its checkout reference.');
      }
      const order=await database.getOrderByPaymentReference(checkoutId);
      if(!order)return bad(res,'Order for this PayMongo checkout is not available yet.',503);
      if(order.id!==reference||order.paymentMethod!=='paymongo'){
        return bad(res,'PayMongo checkout does not match the order.',409);
      }

const payments=checkout?.attributes?.payments;

const paidPayment=Array.isArray(payments)
  ? payments.find(p=>p?.attributes?.status==='paid')
  : null;

if(
  !paidPayment ||
  paidPayment.attributes.amount!==Math.round(order.total*100) ||
  String(paidPayment.attributes.currency||'').toUpperCase()!=='PHP'
){
  return bad(res,'PayMongo payment amount or currency does not match.',409);
}

if(order.paymentStatus!=='paid'){
  await database.markPayMongoOrderPaid(order);
}

return json(res,{ok:true});

    }
    if(event?.type!=='payment.paid'&&event?.type!=='payment_intent.succeeded'){
      return json(res,{ok:true,ignored:true});
    }
    const payment=event.data;
    const attributes=payment?.attributes;
    const intentId=event.type==='payment_intent.succeeded'
      ? payment?.id
      : attributes?.payment_intent_id;
    if(typeof intentId!=='string'){
      return bad(res,'PayMongo payment webhook is missing its payment intent reference.');
    }
    const order=await database.getOrderByPaymentReference(intentId);
    if(!order)return bad(res,'Order for this PayMongo payment is not available yet.',503);
    if(order.paymentMethod!=='paymongo'||
       attributes?.amount!==Math.round(order.total*100)||
       String(attributes?.currency||'').toUpperCase()!=='PHP'||
       (attributes?.metadata?.order_id&&attributes.metadata.order_id!==order.id)){
      return bad(res,'PayMongo payment does not match the order.',409);
    }
    if(order.paymentStatus!=='paid')await database.markPayMongoOrderPaid(order);
    return json(res,{ok:true});
  }

  // Website routes
  if (method === 'GET' && p === '/') {
    res.writeHead(302, { Location: '/staff' });
    res.end();
    return;
  }

  if (method === 'GET' && p === '/staff') {
    return serve(req, res, '/staff.html');
  }

  if(method==='GET'&&p==='/payment/success')
    return serve(req,res,'/payment-success.html');

  if(method==='GET'&&p==='/api/public/payment-return'){
    if(!checkRate(publicAttempts,'payment-return-'+ip,30,10*60*1000))
      return bad(res,'Please wait before checking this payment again.',429);
    const intentId=url.searchParams.get('payment_intent_id');
    let order;
    try{
      order=await database.getOrderByPaymentReference(intentId);
      if(!order||order.paymentMethod!=='paymongo')
        return bad(res,'Payment transaction was not found.',404);
      if(order.paymentStatus!=='paid'){
        const intent=await getPayMongoPaymentIntent(intentId);
        const attributes=intent.attributes||{};
        if(attributes.status==='succeeded'){
          if(attributes.amount!==Math.round(order.total*100)||
             String(attributes.currency||'').toUpperCase()!=='PHP'||
             attributes.metadata?.order_id!==order.id)
            return bad(res,'PayMongo payment does not match the order.',409);
          await database.markPayMongoOrderPaid(order);
          order=await database.getOrderByPaymentReference(intentId);
        }
      }
    }catch(error){
      console.error('PayMongo return verification failed:',error.message);
      return bad(res,error.message||'Unable to verify payment with PayMongo.',error.status||502);
    }
    return json(res,{
      ok:true,paid:order.paymentStatus==='paid',orderId:order.id,
      paymentStatus:order.paymentStatus,total:order.total,currency:'PHP',
      createdAt:order.createdAt
    });
  }

  if (method === 'GET' && p === '/qr') {
    return serve(req, res, '/qr.html');
  }

  // Reuse the real Expo customer screen for every QR/menu link.
  // /order is an old QR link and goes to the Expo menu too.
  if (method === 'GET' && isCustomerAppRoute(p)) {
    if (!fs.existsSync(CUSTOMER_WEB_INDEX)) return redirectToExpoDev(req, res, p === '/order' ? '/menu' : p);
    return serveExpoWeb(req, res, '/index.html');
  }

  // Serve Expo's JS/CSS and bundled images from its exported web directory.
  // Staff assets in public/assets still work as before.
  if (method === 'GET' && fs.existsSync(CUSTOMER_WEB_INDEX) &&
      (p.startsWith('/_expo/') || p.startsWith('/assets/') || p === '/favicon.ico')) {
    const asset = path.resolve(CUSTOMER_WEB_DIR, '.' + p);
    if (asset.startsWith(CUSTOMER_WEB_DIR + path.sep) && fs.existsSync(asset)) {
      return serveExpoWeb(req, res, p);
    }
  }

  if (method === 'GET' && p === '/api/health') {
    return json(res, {
      ok: true,
      database: 'supabase-postgresql',
      mode: 'prototype'
    });
  }

  // Public store settings
  if (method === 'GET' && p === '/api/public/config') {
    const s = await database.settings();

    return json(res, {
      isOpen: isOpen(s),
      open: s.open,
      close: s.close,
      override: s.override,
      location: s.location,
      deliveryRules: {
        freeBelow: 1,
        firstPaid: 15,
        extraPerKm: 10
      },
      payment: 'PayMongo GCash checkout for delivery',
      demo: true
    });
  }

  if (method === 'GET' && p === '/api/public/catalog') {
    return json(res,await customerCatalog(false));
  }

  // Owner catalog includes inactive items for editing; public customers see only active.
  if (method === 'GET' && p === '/api/staff/catalog') {
    if (!await staffRole(req,res,['owner'])) return;
    return json(res, await staffCatalog(true));
  }

  // Public photo URL lookup. No storage credentials are sent to browsers/phones.
  if (method === 'GET' && p === '/api/public/product-images') {
    return json(res, {images:await database.listProductImages()});
  }

  if(method==='GET'&&p==='/api/public/product-popularity'){
    try{return json(res,{products:await database.productPopularity()});}
    catch(error){
      console.error('Unable to load product popularity:',error.message);
      return bad(res,'Product popularity is temporarily unavailable.',503);
    }
  }

  if(method==='GET'&&p==='/api/public/favorites'){
    let customerUser;
    try{customerUser=await customerFromAuthorization(req);}
    catch(error){
      console.error('Unable to verify favorites customer:',error.message);
      return bad(res,'Unable to verify your customer account. Try again.',503);
    }
    if(!customerUser)return bad(res,'Please sign in to view your favorites.',401);
    try{return json(res,{favorites:await database.customerFavorites(customerUser.id)});}
    catch(error){
      console.error('Unable to load customer favorites:',error.message);
      return bad(res,'Your favorites are temporarily unavailable.',503);
    }
  }

  if(method==='POST'&&p==='/api/public/favorites'){
    let customerUser;
    try{customerUser=await customerFromAuthorization(req);}
    catch(error){
      console.error('Unable to verify favorites customer:',error.message);
      return bad(res,'Unable to verify your customer account. Try again.',503);
    }
    if(!customerUser)return bad(res,'Please sign in to update favorites.',401);
    if(!checkRate(publicAttempts,'favorite-'+customerUser.id,60,60*60*1000))
      return bad(res,'You have updated favorites too often. Try again later.',429);
    const b=await body(req);
    if(!b||typeof b!=='object')return bad(res,'Choose a valid product and favorite action.',400);
    const productId=String(b.productId||'');
    if(!/^[a-z0-9._-]{1,80}$/i.test(productId)||typeof b.favorite!=='boolean')
      return bad(res,'Choose a valid product and favorite action.',400);
    try{
      const catalog=await liveCatalog(false);
      if(!catalog.products.some(product=>product.id===productId))
        return bad(res,'That product is no longer available.',404);
      await database.setCustomerFavorite(customerUser.id,productId,b.favorite);
      return json(res,{ok:true,favorite:b.favorite});
    }catch(error){
      console.error('Unable to update customer favorite:',error.message);
      return bad(res,'Unable to save that favorite. Please try again.',503);
    }
  }

  if (method === 'GET' && p === '/api/public/reviews') {
    return json(res, {
      reviews: (await database.reviews()).slice(0, 30)
    });
  }

  if (method === 'GET' && p === '/api/public/order-status') {
    let o = await database.getOrderByToken(
      url.searchParams.get('id'),
      url.searchParams.get('token')
    );

    if(o?.paymentMethod==='paymongo'&&o.paymentStatus==='pending_payment'&&
       o.paymentReference){
      const lastCheck=paymongoStatusChecks.get(o.paymentReference)||0;
      if(Date.now()-lastCheck>=15000){
        paymongoStatusChecks.set(o.paymentReference,Date.now());
        if(paymongoStatusChecks.size>1000)
          paymongoStatusChecks.delete(paymongoStatusChecks.keys().next().value);
        try{
          const intent=await getPayMongoPaymentIntent(o.paymentReference);
          const attributes=intent.attributes||{};
          if(attributes.status==='succeeded'){
            if(attributes.amount!==Math.round(o.total*100)||
               String(attributes.currency||'').toUpperCase()!=='PHP'||
               attributes.metadata?.order_id!==o.id)
              return bad(res,'PayMongo payment does not match the order.',409);
            await database.markPayMongoOrderPaid(o);
            o=await database.getOrderByToken(url.searchParams.get('id'),url.searchParams.get('token'));
          }
        }catch(error){
          console.error('PayMongo payment status check failed:',error.message);
          return bad(res,error.message||'Unable to verify payment with PayMongo.',error.status||502);
        }
      }
    }

    return o
      ? json(res, { order: serializeOrder(o, true) })
      : bad(res, 'Order not found.', 404);
  }

  // Staff session
  if (method === 'GET' && p === '/api/me') {
    const s = await current(req);

    return json(res, {
      user: s
        ? {
            id: s.id,
            role: s.role,
            name: s.name,
            username: s.username
          }
        : null
    });
  }

  if (method === 'GET' && p === '/api/staff/overview') {
    const s = await staffRole(req, res, [
      'owner', 'cashier', 'kitchen'
    ]);

    if (!s) return;

    const all = await database.orders();

    const orders = s.role === 'kitchen'
      ? all.filter(o =>
          ['accepted', 'preparing', 'ready', 'out', 'delivered']
            .includes(o.status)
        )
      : all;

    return json(res, {
      user: {
        id: s.id,
        role: s.role,
        name: s.name
      },
      orders: orders.map(o => serializeOrder(o)),
      reviews: s.role === 'owner'
        ? await database.reviews(true)
        : [],
      staff: s.role === 'owner'
        ? await database.listStaff()
        : [],
      settings: s.role === 'owner'
        ? await database.settings()
        : {
            isOpen: isOpen(await database.settings())
          }
    });
  }

  // Admin-managed shared ringtone files. Uploads are capped at 3.5 MiB and stored server-side.
  if((method==='GET'||method==='POST')&&/^\/api\/staff\/sounds\/(cashier|kitchen)$/.test(p)){
    const staff=await staffRole(req,res,method==='POST'?['owner']:['owner','cashier','kitchen']);
    if(!staff)return;
    const kind=p.split('/').at(-1);
    const soundDir=path.join(ROOT,'data','staff-sounds');
    const soundPath=path.join(soundDir,kind+'.sound');
    if(method==='GET'){
      if(!fs.existsSync(soundPath))return bad(res,'No ringtone uploaded for this role.',404);
      const metaPath=path.join(soundDir,kind+'.json');
      let mime='audio/mpeg';try{mime=JSON.parse(fs.readFileSync(metaPath,'utf8')).mime||mime;}catch{}
      res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      return res.end(fs.readFileSync(soundPath));
    }
    const payload=await body(req);
    const allowedMime=['audio/mpeg','audio/mp3','audio/wav','audio/x-wav','audio/ogg','audio/mp4','audio/aac'];
    if(!allowedMime.includes(payload.mime))return bad(res,'Use MP3, WAV, OGG, M4A or AAC audio.');
    if(typeof payload.base64!=='string'||!payload.base64)return bad(res,'No audio data received.');
    const bytes=Buffer.from(payload.base64,'base64');
    if(!bytes.length||bytes.length>Math.floor(3.5*1024*1024))return bad(res,'Ringtone must be 3.5 MB or smaller.');
    if(!fs.existsSync(soundDir))fs.mkdirSync(soundDir,{recursive:true});
    fs.writeFileSync(soundPath,bytes);
    fs.writeFileSync(path.join(soundDir,kind+'.json'),JSON.stringify({mime:payload.mime,name:safe(payload.name,120)}));
    return json(res,{ok:true,name:safe(payload.name,120),size:bytes.length});
  }

  if(method==='GET'&&p==='/api/staff/dashboard'){
    const staff=await staffRole(req,res,['owner','cashier']);
    if(!staff)return;
    const period=url.searchParams.get('period')||'today';
    let range;
    try{range=dashboardRange(period);}
    catch(error){return bad(res,error.message,400);}
    let analytics;
    try{
      analytics=await database.staffDashboardAnalytics({...range,period});
    }catch(error){
      console.error('Unable to load staff dashboard analytics:',error.message);
      return bad(res,'Dashboard analytics are temporarily unavailable.',503);
    }
    if(staff.role==='cashier'){
      const {orderSeries,today,totalOrders,totalTransactions,recentTransactions}=analytics;
      return json(res,{period,orderSeries,today,totalOrders,totalTransactions,recentTransactions});
    }
    const products=await staffCatalog(true);
    const {totalProducts,activeProducts,inactiveProducts}=products.products.reduce((counts,product)=>{
      counts.totalProducts+=1;
      if(product.active===false)counts.inactiveProducts+=1;
      else counts.activeProducts+=1;
      return counts;
    },{totalProducts:0,activeProducts:0,inactiveProducts:0});
    return json(res,{period,...analytics,totalProducts,activeProducts,inactiveProducts});
  }

  if (method === 'GET' && p === '/api/staff/customers') {
    if (!await staffRole(req, res, ['owner'])) return;
    return json(res, {customers:await database.customerSummaries()});
  }

  if (method === 'GET' && p === '/api/staff/payment-transactions') {
    if (!await staffRole(req, res, ['owner','cashier'])) return;
    return json(res, {transactions:await database.paymentTransactions()});
  }

  if (
    method === 'GET' &&
    p.startsWith('/api/staff/proof/')
  ) {
    if (!await staffRole(req, res, ['owner', 'cashier'])) {
      return;
    }

    const o = await database.getOrder(
      decodeURIComponent(p.split('/').at(-1))
    );

    if (!o?.proofPath) {
      return bad(res, 'Proof not found.', 404);
    }

    const bytes = await database.downloadProof(o.proofPath);

    res.writeHead(200, {
      'Content-Type': o.proofMime || 'image/jpeg',
      'Content-Disposition': 'inline',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    });

    res.end(bytes);
    return;
  }

  // Protect staff mutations from cross-origin requests
  if (method === 'POST' && req.headers.origin) {
    try {
      const origin = new URL(req.headers.origin);

      const allowedConfiguredOrigin =
        process.env.ALLOWED_WEB_ORIGIN &&
        origin.origin === process.env.ALLOWED_WEB_ORIGIN;

      if (
        origin.host !== req.headers.host &&
        !(publicApi && allowedCustomerOrigin) &&
        !allowedConfiguredOrigin
      ) {
        return bad(
          res,
          'Cross-origin browser POST blocked.',
          403
        );
      }
    } catch {
      return bad(res, 'Invalid Origin.', 403);
    }
  }

  // Staff login: only failed attempts count toward lockout; role + IP are isolated.
  if(method==='POST'&&p==='/api/login'){
    const b=await body(req),role=safe(b.role,20);
    const username=role==='kitchen'?safe(b.username,120).toLowerCase():'';
    const windowMs=15*60*1000;
    const roleKey='login-role:'+ip+':'+role+':'+username;
    const ipKey='login-ip:'+ip;
    const failures=k=>(loginAttempts.get(k)||[]).filter(t=>t+windowMs>Date.now()).length;
    if(failures(roleKey)>=7||failures(ipKey)>=30)
      return bad(res,'Too many incorrect attempts. Try again after 15 minutes.',429);
    let staff=null,secret='';
    if(role==='owner'||role==='cashier'){
      staff=await database.staffByRole(role);secret=safe(b.pin,16);
    }else if(role==='kitchen'){
      staff=await database.staffByRole('kitchen',username);
      secret=String(b.password||'');
    }
    if(!staff||!secret||!database.passwordMatches(secret,staff)){
      checkRate(loginAttempts,roleKey,7,windowMs);
      checkRate(loginAttempts,ipKey,30,windowMs);
      return bad(res,'Incorrect credentials.',401);
    }
    loginAttempts.delete(roleKey);
    const prior=cookie(req,'fyi_session_'+role);
    if(prior)sessions.delete(prior);
    const sid=nonce()+nonce();
    sessions.set(sid,{id:staff.id,role:staff.role,expires:Date.now()+8*3600000});
    return json(res,{ok:true,role:staff.role,name:staff.name},200,{
      'Set-Cookie':sessionCookie(sid,false,role)
    });
  }
  // Logging out one role must not log out another role.
  if(method==='POST'&&p==='/api/logout'){
    const role=requestedStaffRole(req);
    if(!role)return bad(res,'Select a staff role to sign out.',400);
    sessions.delete(cookie(req,'fyi_session_'+role));
    return json(res,{ok:true},200,{'Set-Cookie':sessionCookie('',true,role)});
  }
  // Calculate delivery distance
  if(method==='POST'&&p==='/api/public/customer-signup'){
    if(!checkRate(publicAttempts,'customer-signup-'+ip,5,60*60*1000))
      return bad(res,'Too many signup attempts. Please try again later.',429);
    if(process.env.NODE_ENV==='production'&&process.env.CUSTOMER_SIGNUP_AUTO_CONFIRM!=='true')
      return bad(res,'Automatic email confirmation is disabled for this server.',503);
    const payload=await body(req);
    if(!payload||typeof payload!=='object'||Array.isArray(payload))
      return bad(res,'Enter your account details and try again.',400);
    const email=typeof payload.email==='string'?payload.email.trim().toLowerCase():'';
    const username=typeof payload.username==='string'?payload.username.trim().toLowerCase():'';
    const phone=typeof payload.phone==='string'?payload.phone.trim():'';
    const address=typeof payload.address==='string'?payload.address.trim():'';
    const password=typeof payload.password==='string'?payload.password:'';
    if(email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return bad(res,'Enter a valid email address.',400);
    if(!/^[a-z0-9._-]{3,30}$/.test(username))
      return bad(res,'Username must be 3â€“30 letters, numbers, dots, underscores or hyphens.',400);
    if(!/^09\d{9}$/.test(phone))
      return bad(res,'Enter an 11-digit Philippine phone number starting with 09.',400);
    if(address.length<5||address.length>240)
      return bad(res,'Enter your complete delivery address.',400);
    if(!password)
      return bad(res,'Enter a password.',400);
    try{
      const customer=await database.createCustomerAccount({email,password,username,phone,address});
      return json(res,{ok:true,customer},201);
    }catch(error){
      console.error('Customer signup failed:',error.message);
      return bad(res,error.message||'Unable to create your customer account.',error.status||503);
    }
  }

  if(method==='POST'&&p==='/api/public/customer-recovery'){
    if(!checkRate(publicAttempts,'customer-recovery-'+ip,4,15*60*1000))
      return bad(res,'Too many password reset requests. Try again later.',429);
    const payload=await body(req);
    const username=safe(payload.username,30).toLowerCase();
    if(!/^[a-z0-9._-]{3,30}$/.test(username))
      return bad(res,'Enter your customer username.',400);
    let redirectTo;
    try{
      redirectTo=validatedCustomerRecoveryRedirect(payload.redirectTo,req);
    }catch(error){
      return bad(res,error.message,503);
    }
    try{
      await database.requestCustomerPasswordReset(username,redirectTo);
    }catch(error){
      console.error('Customer password recovery failed:',error.message);
      return bad(res,error.message,503);
    }
    return json(res,{ok:true,message:'If the username belongs to a verified account, a password reset link has been sent to its email.'});
  }

  if (method === 'POST' && p === '/api/public/route') {
    if (!checkRate(
      publicAttempts,
      'route-' + ip,
      50,
      10 * 60 * 1000
    )) {
      return bad(
        res,
        'Please wait before requesting more routes.',
        429
      );
    }

    const b = await body(req);

    try {
      const route = await roadRoute(
        Number(b.lat),
        Number(b.lng),
        (await database.settings()).location
      );

      return json(res, {
        roadKm: route.km,
        deliveryFee: feeFromKm(route.km),
        coordinates:route.coordinates,
        storeLatitude:route.storeLatitude,
        storeLongitude:route.storeLongitude
      });
    } catch (e) {
      return bad(res, e.message, 503);
    }
  }

  // Cashier-only dine-in POS: server-priced, immediately paid, and sent to Kitchen.
  if(method==='POST'&&p==='/api/staff/dine-in-orders'){
    const staff=await staffRole(req,res,['cashier']);
    if(!staff)return;
    if(!checkRate(publicAttempts,'dine-in-'+staff.id,30,60*1000))
      return bad(res,'Too many dine-in orders. Please wait a moment.',429);
    const b=await body(req);
    const table=String(b.tableNumber||'').trim();
    if(!/^[A-Za-z0-9-]{1,12}$/.test(table))return bad(res,'Enter a valid table number.',400);
    const paymentMethod=String(b.paymentMethod||'cash').toLowerCase();
    if(!['cash','gcash'].includes(paymentMethod))return bad(res,'Select Cash or GCash payment.',400);
    const notes=safe(b.notes,300);
    const menuForOrder=await customerCatalog(false);
    let priced;
    try{priced=priceItems(b.items,menuForOrder);}catch(error){return bad(res,error.message,400);}
    const id='FYI-DI-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase();
    const token=nonce(),createdAt=new Date().toISOString();
    const order={id,customerId:null,type:'dine-in',status:'accepted',paymentStatus:'paid',paymentMethod,
      customer:{name:'Dine-In · Table '+table,phone:'',address:'Dine-In',landmark:'',notes,facebook:'',tableNumber:table},
      items:priced.items,subtotal:priced.subtotal,deliveryFee:0,roadKm:null,total:priced.subtotal,createdAt,updatedAt:createdAt,
      gcashReference:'',history:[{at:createdAt,status:'accepted',actor:'cashier',description:`Dine-in order for Table ${table}; ${paymentMethod.toUpperCase()} payment recorded and ticket sent to Kitchen.`}]};
    try{await database.insertOrder(order,token);}catch(error){console.error('Dine-in order insert failed:',error.message);return bad(res,'Could not save the dine-in order. Please retry after checking the connection.',503);}
    return json(res,{ok:true,order:serializeOrder(order)},201);
  }


  // Customer order submission
  if (method === 'POST' && p === '/api/public/orders') {
    let customerUser;
    try{
      customerUser=await customerFromAuthorization(req);
    }catch{
      return bad(res,'Unable to verify your customer account with Supabase. Try again.',503);
    }
    if(!customerUser)return bad(res,'Please sign in to place a delivery order.',401);
    if(!customerUser.email_confirmed_at)
      return bad(res,'Verify your email address before placing an order.',403);
    if (!checkRate(
      publicAttempts,
      'order-' + ip,
      10,
      15 * 60 * 1000
    )) {
      return bad(
        res,
        'Too many orders. Please wait.',
        429
      );
    }

    const s = await database.settings();

    if (!isOpen(s)) {
      return bad(
        res,
        'FYI-KANTO is currently closed.',
        409
      );
    }

    const b = await body(req);
    if(b.type!=='delivery')return bad(res,'Customer orders are delivery only.',400);
    if(b.paymentMethod!=='paymongo')return bad(res,'PayMongo GCash payment is required for delivery orders.',400);
    let profile;
    try{profile=await database.customerProfile(customerUser.id);}
    catch(error){
      console.error('Unable to load customer profile for order:',error.message);
      return bad(res,'Unable to load your saved delivery profile. Please update your account details and try again.',503);
    }
    if(!profile||!(profile.full_name||profile.username)?.trim()||!/^09\d{9}$/.test(profile.phone||'')||(profile.address||'').trim().length<5)
      return bad(res,'Complete your saved full name, phone number, and delivery address in your profile before ordering.',400);
    // Fetch live prices first; backend errors must not leak database details to callers.
    const menuForOrder = await customerCatalog(false);
    let priced;

    try {
      priced = priceItems(b.items, menuForOrder);
    } catch (e) {
      return bad(res, e.message);
    }

    const type = 'delivery';

    const customer = {
      name: safe(profile.full_name||profile.username, 70),
      phone: safe(profile.phone, 11),
      address: safe(profile.address, 240),
      landmark: safe(b.customer?.landmark, 120),
      notes: safe(b.customer?.notes, 300),
      facebook: '',
      tableNumber: ''
    };

    if (
      customer.name.length < 2 ||
      !/^09\d{9}$/.test(customer.phone) ||
      (type === 'delivery' && customer.address.length < 5)
    ) {
      return bad(
        res,
        'Enter a valid customer name, 11-digit Philippine mobile number, and address for delivery.'
      );
    }

    const methodPay = 'paymongo';

    let km = null;
    let fee = 0;

    if (type === 'delivery') {
      try {
        km = await roadDistance(
          Number(b.delivery?.lat),
          Number(b.delivery?.lng),
          s.location
        );
        fee = feeFromKm(km);
      } catch (e) {
        return bad(res, e.message, 503);
      }
    }

    const id =
      'FYI-' +
      Date.now().toString(36).toUpperCase() +
      '-' +
      crypto.randomBytes(2).toString('hex').toUpperCase();

    const token = nonce();
    const createdAt = new Date().toISOString();

    const status = 'pending_payment';

    // FYI UPGRADES: persist the selected customer drop-off pin in customer JSON.
    // These coordinates were already validated when calculating the road distance.
    const fyiPinLat = Number(b.delivery?.lat);
    const fyiPinLng = Number(b.delivery?.lng);
    if (Number.isFinite(fyiPinLat) && Number.isFinite(fyiPinLng) &&
        fyiPinLat >= -90 && fyiPinLat <= 90 && fyiPinLng >= -180 && fyiPinLng <= 180) {
      customer.deliveryPin = {lat: Number(fyiPinLat.toFixed(6)), lng: Number(fyiPinLng.toFixed(6))};
    }

    const order = {
      id,
      customerId:customerUser.id,
      type,
      status,
      paymentStatus:'pending_payment',
      paymentMethod: methodPay,
      customer,
      items: priced.items,
      subtotal: priced.subtotal,
      deliveryFee: fee,
      roadKm: km,
      total: priced.subtotal + fee,
      createdAt,
      updatedAt: createdAt,
      gcashReference:'',
      history: [{
        at: createdAt,
        status,
        actor: 'customer',
        description: 'Order submitted'
      }]
    };

    try{
      const email=typeof customerUser.email==='string'&&
        !customerUser.email.toLowerCase().endsWith('@accounts.fyi-kanto.invalid')
        ?customerUser.email:undefined;
      const payment=await createPayMongoPaymentIntent({
        orderId:id,total:order.total,
        customer:{...customer,email}
      });
      order.paymentReference=payment.id;
      order.paymentUrl=payment.paymentUrl;
      await database.insertOrder(order, token);
    }catch(e){if(e.status) return bad(res,e.message,e.status);throw e;}

    return json(res, {
      id,
      trackingToken: token,
      status,
      total: order.total,
      paymentStatus: order.paymentStatus,
      paymentUrl:order.paymentUrl
    }, 201);
  }

  // Customer reviews
  if(method==='POST'&&p==='/api/public/order-feedback'){
    let customerUser;
    try{customerUser=await customerFromAuthorization(req);}
    catch(error){
      console.error('Unable to verify order-review customer:',error.message);
      return bad(res,'Unable to verify your customer account. Try again.',503);
    }
    if(!customerUser)return bad(res,'Please sign in before reviewing this order.',401);
    if(!checkRate(publicAttempts,'order-review-'+customerUser.id,10,60*60*1000))
      return bad(res,'You have submitted several order reviews recently. Try again later.',429);
    const b=await body(req);
    if(!b||typeof b!=='object')return bad(res,'Invalid order review request.',400);
    const orderId=safe(b.orderId,100);
    try{
      const result=await database.submitOrderFeedback(customerUser.id,orderId,b.reviews);
      return json(res,{ok:true,...result},201);
    }catch(error){
      if(error.status>=500)
        console.error('Unable to save verified order review:',error.message);
      return bad(res,error.message||'Unable to save your order review.',error.status||503);
    }
  }

  if (method === 'POST' && p === '/api/public/review') {
    const b = await body(req);
    const rating = Number(b.rating);
    const name = safe(b.name,70);
    const productName = safe(b.productName,100);
    const message = safe(b.message, 500);

    if (
      name.length<2 ||
      !Number.isInteger(rating) ||
      rating < 1 ||
      rating > 5 ||
      message.length < 5
    ) {
      return bad(
        res,
        'Enter your name, choose 1â€“5 stars, and write at least 5 characters.'
      );
    }

    if(!checkRate(publicAttempts,'review-'+ip,5,15*60*1000))
      return bad(res,'You have submitted several reviews recently. Please try again later.',429);

    try {
      const review=await database.addCustomerReview({name,productName,rating,message});
      return json(res,{ok:true,review},201);
    } catch (e) {
      return bad(res, e.message, e.status || 500);
    }
  }

  // Staff order actions
  if (
    method === 'POST' &&
    p.startsWith('/api/staff/orders/') &&
    p.endsWith('/action')
  ) {
    const s = await staffRole(req, res, [
      'owner', 'cashier', 'kitchen'
    ]);

    if (!s) return;

    const id = decodeURIComponent(p.split('/')[4]);
    const o = await database.getOrder(id);

    if (!o) return bad(res, 'Order not found.', 404);

    const b = await body(req);
    const action = safe(b.action, 30);

    const rules = {
      verify: {
        role: 'cashier',
        from: ['pending_verification'],
        to: 'accepted',
        pay: 'verified',
        desc: 'GCash verified against actual transaction records'
      },
      reject: {
        role: 'cashier',
        from: ['pending_payment','pending_verification', 'pending_acceptance'],
        to: 'rejected',
        pay: 'rejected',
        desc: 'Order rejected by cashier'
      },
      accept: {
        role: 'cashier',
        from: ['pending_acceptance'],
        to: 'accepted',
        desc: 'Paid delivery order accepted by cashier'
      },
      start: {
        role: 'kitchen',
        from: ['accepted'],
        to: 'preparing',
        desc: 'Kitchen started preparing'
      },
      ready: {
        role: 'kitchen',
        from: ['preparing'],
        to: 'ready',
        desc: 'Kitchen marked order ready'
      },
      dispatch: {
        role: 'cashier',
        from: ['ready'],
        to: 'out',
        desc: 'Order dispatched or ready to serve'
      },
      delivered: {
        role: 'cashier',
        from: ['out'],
        to: 'delivered',
        desc: 'Order completed'
      }
    };

    const rule = rules[action];

    if (
      !rule ||
      rule.role !== s.role ||
      !rule.from.includes(o.status)
    ) {
      return bad(
        res,
        'This action is not allowed for this role or order stage.',
        403
      );
    }

    if(action==='accept'&&o.paymentMethod==='paymongo'&&o.paymentStatus!=='paid'){
      return bad(res,'PayMongo has not confirmed this payment yet.',409);
    }

    if(action==='verify'&&o.paymentMethod==='paymongo'){
      return bad(res,'PayMongo payments are verified automatically by webhook.',409);
    }

    if (action === 'verify' && !o.proofPath) {
      return bad(res, 'Payment proof missing.');
    }

    if (
      action === 'verify' &&
      b.confirmActualPayment !== true
    ) {
      return bad(
        res,
        'Confirm payment in the actual receiving GCash account.'
      );
    }

    try {
      const updated = await database.updateOrderStatus(o, {
        to: rule.to,
        actor: s.role,
        description: rule.desc,
        paymentStatus: rule.pay
      });

      return json(res, {
        order: serializeOrder(updated)
      });
    } catch (e) {
      return bad(res, e.message, e.status || 500);
    }
  }

  // Admin store settings
  if (method === 'POST' && p === '/api/staff/settings') {
    if (!await staffRole(req, res, ['owner'])) return;

    const b = await body(req);

    if (
      !['auto', 'open', 'closed'].includes(b.override) ||
      !validClock(b.open) ||
      !validClock(b.close)
    ) {
      return bad(
        res,
        'Invalid store hours or override.'
      );
    }

    const settings = await database.saveSettings({
      open: b.open,
      close: b.close,
      override: b.override
    });
    broadcastStoreStatus(settings);
    scheduleNextStoreBoundary(settings);

    return json(res, {
      settings,
      isOpen: isOpen(settings)
    });
  }

  // Full menu CRUD: owner-only, server-side validation, Supabase persistence.
  if(method==='POST' && p==='/api/staff/product-save'){
    if(!await staffRole(req,res,['owner']))return;
    const payload=await body(req);
    const current=await staffCatalog(true);
    const editing=payload.id!=null && payload.id!=='';
    const id=editing?safe(payload.id,80):'custom-'+crypto.randomUUID();
    const existing=current.products.find(x=>x.id===id);
    if(editing&&!existing)return bad(res,'Product not found.',404);
    const saved=validateMenuProduct(payload,id,current.categories,current.menuAddons,existing);
    // Retain packaged art path for built-in products, but prevent arbitrary URLs/HTML.
    saved.image=existing?.image||null;
    saved.imageUrl=existing?.imageUrl||null;
    await database.saveMenuProduct(saved);
    return json(res,{ok:true,product:saved});
  }
  if(method==='POST' && p==='/api/staff/product-delete'){
    if(!await staffRole(req,res,['owner']))return;
    const payload=await body(req);
    const id=safe(payload.id,80);
    if(!(await liveCatalog(true)).products.some(x=>x.id===id))return bad(res,'Product not found.',404);
    await database.deleteMenuProduct(id);
    return json(res,{ok:true,id});
  }

  if(method==='POST'&&p==='/api/staff/category-save'){
    if(!await staffRole(req,res,['owner']))return;
    const payload=await body(req);
    if(!payload||typeof payload!=='object'||Array.isArray(payload))
      return bad(res,'Invalid category details.',400);
    const label=safe(payload.label,60);
    const description=safe(payload.description,300);
    if(label.length<2)return bad(res,'Category name must be at least 2 characters.',400);
    const menu=await database.menuConfiguration();
    const requestedId=typeof payload.id==='string'?safe(payload.id,60):'';
    const current=requestedId?menu.categories.find(item=>item.id===requestedId):null;
    if(payload.id&&!current)return bad(res,'Category not found.',404);
    const id=current?.id||label.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60);
    if(!id)return bad(res,'Category name must include letters or numbers.',400);
    const names=[...CATALOG.categories,...menu.categories.filter(item=>item.id!==current?.id)];
    if(names.some(item=>item.id===id||item.label.trim().toLowerCase()===label.toLowerCase()))
      return bad(res,'A category with this name already exists.',409);
    if(!current&&menu.categories.length>=50)return bad(res,'The category limit has been reached.',409);
    let uploaded=null;
    if(payload.imageDataUrl){
      if(!checkRate(publicAttempts,'image:'+ip,25,60*60*1000))
        return bad(res,'Too many uploads. Try again later.',429);
      const file=decodeProductImage(payload.imageDataUrl);
      uploaded=await database.uploadMenuAsset('category',id,file.bytes,file.ext,file.mime);
    }
    const category={
      ...(current||{}),id,label,description,
      imageUrl:uploaded?.url||current?.imageUrl||null,
      imagePath:uploaded?.storagePath||current?.imagePath||null
    };
    const categories=current
      ?menu.categories.map(item=>item.id===id?category:item)
      :[...menu.categories,category];
    try{
      await database.saveMenuCategories(categories);
    }catch(error){
      if(uploaded)try{await database.removeMenuAsset(uploaded.storagePath);}
      catch(cleanupError){console.warn('Unable to clean up unsaved category image:',cleanupError.message);}
      throw error;
    }
    if(uploaded?.storagePath&&current?.imagePath&&current.imagePath!==uploaded.storagePath){
      try{await database.removeMenuAsset(current.imagePath);}
      catch(error){console.warn('Old category image cleanup failed:',error.message);}
    }
    return json(res,{ok:true,category});
  }

  if(method==='POST'&&p==='/api/staff/addon-save'){
    if(!await staffRole(req,res,['owner']))return;
    const payload=await body(req);
    if(!payload||typeof payload!=='object'||Array.isArray(payload))
      return bad(res,'Invalid add-on details.',400);
    const menu=await database.menuConfiguration();
    const current=payload.id?menu.addons.find(item=>item.id===safe(payload.id,60)):null;
    if(payload.id&&!current)return bad(res,'Add-on not found.',404);
    const name=safe(payload.name,60);
    const price=Number(payload.price);
    if(name.length<2||!Number.isFinite(price)||price<0||price>10000||
      Math.abs(Math.round(price*100)-price*100)>1e-6)
      return bad(res,'Enter an add-on name and a valid price.',400);
    const id=current?.id||name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60);
    if(!id)return bad(res,'Add-on name must include letters or numbers.',400);
    if(menu.addons.some(item=>item.id!==current?.id&&
      (item.id===id||item.name.trim().toLowerCase()===name.toLowerCase())))
      return bad(res,'An add-on with this name already exists.',409);
    if(!current&&menu.addons.length>=100)return bad(res,'The add-on limit has been reached.',409);
    const allCategories=[...CATALOG.categories,...menu.categories];
    const products=(await liveCatalog(true)).products;
    const categoryIds=Array.isArray(payload.categoryIds)?[...new Set(payload.categoryIds.map(value=>safe(value,60)))]:[];
    const productIds=Array.isArray(payload.productIds)?[...new Set(payload.productIds.map(value=>safe(value,80)))]:[];
    if(!categoryIds.length&&!productIds.length)
      return bad(res,'Select at least one category or product for this add-on.',400);
    if(categoryIds.some(value=>!allCategories.some(category=>category.id===value))||
      productIds.some(value=>!products.some(product=>product.id===value)))
      return bad(res,'One or more selected add-on targets are invalid.',400);
    const addon={
      id,name,price,categoryIds,productIds,
      active:payload.active!==false
    };
    const addons=current
      ?menu.addons.map(item=>item.id===id?addon:item)
      :[...menu.addons,addon];
    await database.saveMenuAddons(addons);
    return json(res,{ok:true,addon});
  }

  // Only the Admin 1 / Owner account can update product images.
  if (method === 'POST' && p === '/api/staff/product-image') {
    if (!await staffRole(req,res,['owner'])) return;
    if (!checkRate(publicAttempts,'image:'+ip,25,60*60*1000))
      return bad(res,'Too many uploads. Try again later.',429);
    const payload=await body(req);
    const productId=safe(payload.productId,80);
    if (!(await liveCatalog(true)).products.some(product=>product.id===productId))
      return bad(res,'Unknown product ID.',400);
    const file=decodeProductImage(payload.dataUrl);
    const imageUrl=await database.uploadProductImage(productId,file.bytes,file.ext,file.mime);
    return json(res,{ok:true,productId,imageUrl});
  }

  // Kitchen staff account creation
  if (method === 'POST' && p === '/api/staff/create') {
    if (!await staffRole(req, res, ['owner'])) return;

    const b = await body(req);
    const username = safe(
      b.username,
      80
    ).toLowerCase();

    const password = String(b.password || '');

    if (
      b.role !== 'kitchen' ||
      !/^[a-z0-9._@-]{4,80}$/.test(username) ||
      password.length < 12
    ) {
      return bad(
        res,
        'Unique username (4+ chars), kitchen role and 12+ character password required.'
      );
    }

    const salt = nonce();

    try {
      await database.insertStaff({
        id: database.newId(),
        role: 'kitchen',
        name: safe(b.name, 80) || 'Kitchen Staff',
        username,
        salt,
        password_hash: database.hashPassword(
          password,
          salt
        )
      });
    } catch (e) {
      return bad(
        res,
        'Could not create kitchen account (username may exist).',
        409
      );
    }

    return json(res, { ok: true });
  }

  // API not found
  if (
    method === 'GET' &&
    p.startsWith('/api/')
  ) {
    return bad(res, 'API endpoint not found.', 404);
  }

  // Public static assets
  if (
    method === 'GET' &&
    p.startsWith('/assets/')
  ) {
    return serve(req, res, p);
  }

  if (
    method === 'GET' &&
    [
      '/staff.js',
      '/staff.css',
      '/customer.js',
      '/customer.css',
      '/qr.js',
      '/logo.svg'
    ].includes(p)
  ) {
    return serve(req, res, p);
  }

  return bad(res, 'Not found.', 404);
}

// Start Node server
const server = http.createServer((req, res) =>
  handle(req, res).catch(e => {
    if(!(e.status>=400 && e.status<500))console.error('Server request failed:', e.message);

    if (!res.headersSent) {
      bad(
        res,
        e.status>=400 && e.status<500 ? e.message : 'A server/database error occurred.',
        e.status || 500
      );
    } else {
      res.end();
    }
  })
);
const storeStatusSockets = new WebSocketServer({noServer:true});

function storeStatusMessage(settings) {
  return {
    type:'store-status',
    isOpen:isOpen(settings),
    open:settings.open,
    close:settings.close,
    override:settings.override
  };
}

function broadcastStoreStatus(settings) {
  const message=JSON.stringify(storeStatusMessage(settings));
  for(const client of storeStatusSockets.clients) {
    if(client.readyState===WebSocket.OPEN)client.send(message);
  }
}

storeStatusSockets.on('connection',async socket=>{
  socket.isAlive=true;
  socket.on('pong',()=>{socket.isAlive=true;});
  socket.on('error',error=>console.warn('Store status WebSocket error:',error.message));
  try {
    socket.send(JSON.stringify(storeStatusMessage(await database.settings())));
  } catch(error) {
    console.error('Unable to send initial store status:',error.message);
    socket.close(1011,'Store status unavailable');
  }
});
const storeSocketHeartbeat=setInterval(()=>{
  for(const socket of storeStatusSockets.clients) {
    if(socket.isAlive===false) {
      socket.terminate();
      continue;
    }
    socket.isAlive=false;
    socket.ping();
  }
},30000);
server.on('close',()=>clearInterval(storeSocketHeartbeat));

server.on('upgrade',(request,socket,head)=>{
  let pathname;
  try { pathname=new URL(request.url,'http://localhost').pathname; }
  catch { socket.destroy(); return; }
  if(pathname!=='/api/public/store-status/live') {
    socket.destroy();
    return;
  }
  storeStatusSockets.handleUpgrade(request,socket,head,websocket=>{
    storeStatusSockets.emit('connection',websocket,request);
  });
});

try {
  await database.preflight();
  scheduleNextStoreBoundary(await database.settings());

  server.listen(PORT, '0.0.0.0', () => {
    console.log(
      `FYI-KANTO Supabase PostgreSQL server: http://localhost:${PORT}/staff`
    );

    console.log(
      `Customer QR (Expo UI) on local Wi-Fi: http://YOUR_LAPTOP_IP:${PORT}/menu`
    );

    console.log(
      'Supabase connected. Prototype server â€” do not expose to public internet without HTTPS and security hardening.'
    );
  });
} catch (e) {
  console.error(
    'Supabase startup failed:',
    e.message
  );

  console.error(
    'First run supabase/schema.sql in Supabase SQL Editor, then check your .env values.'
  );

  process.exit(1);
}
