const $=q=>document.querySelector(q);const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pesos=n=>'₱'+Number(n||0).toLocaleString('en-PH',{maximumFractionDigits:2});
let loginRole='owner',pin='',user=null,data=null,customerRows=[],paymentRows=[],section='dashboard',activeOrder=null,filter='all',search='',poll=null,storeSocket=null,storeReconnectTimer=null,storeRetryCount=0,lastStoreConfig='',catalog={products:[],categories:[],menuAddons:[]},productImages={},uploadingProduct=null,menuModalOpen=false,dashboardMetrics=null,dashboardPeriod='week',dashboardFetchedAt=0,signingOut=false,confirmationResolver=null,staffSoundMuted=localStorage.getItem('fyi_staff_sounds_muted')==='1',soundCtx=null;
const roleNames={owner:'Admin 1',cashier:'Cashier',kitchen:'Kitchen Staff'};
// FYI_STAFF_SESSION_FIX_V1: tab-specific selected role (never stores PIN/password).
const STAFF_TAB_ROLE_KEY='fyi_active_staff_role';
const storedStaffRole=sessionStorage.getItem(STAFF_TAB_ROLE_KEY);
if(Object.hasOwn(roleNames,storedStaffRole))loginRole=storedStaffRole;
const statNames={pending_payment:'Awaiting PayMongo',pending_verification:'Awaiting GCash',pending_acceptance:'Awaiting Acceptance',accepted:'Accepted',preparing:'Preparing',ready:'Kitchen Ready',out:'Out for Delivery',delivered:'Completed',rejected:'Rejected'};
const navOwner=[['dashboard','▦','Dashboard'],['orders','▤','Orders'],['payments','◉','Payments'],['menu','☰','Menu'],['customers','♙','Customers'],['reviews','☆','Reviews'],['reports','▥','Sales Reports'],['staff','♙','Staff Accounts'],['settings','⚙','Settings']];
const navCashier=[['dashboard','▦','Dashboard'],['dinein','🍽','Dine-In POS'],['orders','▤','Pending Orders'],['payments','◉','Payment Status'],['dispatch','⇢','Dispatch Queue']];
const navKitchen=[['kitchen','▣','Kitchen Board']];
let dineCart=[];
function alertOnce(kind,id){try{const key='fyi_staff_alerted_'+kind;const saved=JSON.parse(localStorage.getItem(key)||'[]');if(saved.includes(id))return false;saved.push(id);localStorage.setItem(key,JSON.stringify(saved.slice(-500)));return true;}catch{return true;}}
function posProduct(){return catalog.products.find(p=>p.id===($('#pos-product')?.value||''));}
function posAddons(product){return product?(catalog.addOns?.[product.addOns]||[]):[];}
function posLineTotal(line){const p=catalog.products.find(x=>x.id===line.productId);const size=p?.sizes.find(x=>x.label===line.size);const adds=posAddons(p).filter(a=>line.addOnIds.includes(a.id)).reduce((sum,a)=>sum+Number(a.price||0),0);return (Number(size?.price||0)+adds)*line.qty;}
function dineinPOS(){const available=catalog.products.filter(p=>p.active!==false&&!p.unavailable);return intro('Dine-In POS','Cashier-only order entry. Record payment and send the ticket directly to Kitchen.',soundSettingsControl())+'<div class="pos-grid"><section class="panel pos-builder"><h3>Add menu items</h3><label class="field">Menu item<select id="pos-product">'+available.map(p=>'<option value="'+esc(p.id)+'">'+esc(p.name)+'</option>').join('')+'</select></label><div id="pos-options"></div><div class="form-grid"><label class="field">Quantity<input id="pos-qty" type="number" min=1 max=30 value=1></label><div style="display:flex;align-items:end"><button id="pos-add" class="primary-btn" type="button">Add to order</button></div></div></section><section class="panel pos-cart"><h3>Current dine-in order</h3><div class="form-grid"><label class="field">Table Number<input id="pos-table" placeholder="e.g. 4" maxlength=12 required></label><label class="field">Payment<select id="pos-payment"><option value="cash">Cash</option><option value="gcash">GCash (confirmed at cashier)</option></select></label></div><label class="field">Order notes<input id="pos-notes" maxlength=300 placeholder="Special instructions for the Kitchen"></label><div id="pos-cart-lines"></div><div class="pos-total">Total <strong id="pos-total">₱0.00</strong></div><button id="pos-submit" class="primary-btn wide" type="button" disabled>Record payment &amp; Send to Kitchen</button><p class="help">Only the Cashier can create dine-in orders. Customer mobile ordering remains delivery-only.</p></section></div>'; }
function renderPosOptions(){const p=posProduct(),target=$('#pos-options');if(!target)return;if(!p){target.innerHTML='<p class="empty">No active menu items.</p>';return;}const addons=posAddons(p);const sizes=(p.sizes||[]).map(size=>'<option value="'+esc(size.label)+'">'+esc(size.label)+' — '+pesos(size.price)+'</option>').join('');const variants=(p.variants||[]).length?'<label class="field">Variant<select id="pos-variant"><option value="">No variant</option>'+p.variants.map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('')+'</select></label>':'';const addonHtml=addons.length?'<div class="pos-addons"><strong>Add-ons</strong>'+addons.map(a=>'<label class="checkline"><input type="checkbox" value="'+esc(a.id)+'" data-pos-addon><span>'+esc(a.label||a.name)+' +'+pesos(a.price)+'</span></label>').join('')+'</div>':'';target.innerHTML='<label class="field">Size<select id="pos-size">'+sizes+'</select></label>'+variants+addonHtml;}
function renderPosCart(){const target=$('#pos-cart-lines');if(!target)return;target.innerHTML=dineCart.length?dineCart.map((line,i)=>'<div class="pos-cart-item"><div><strong>'+esc(line.name)+'</strong><small>'+esc(line.size)+(line.variant?' · '+esc(line.variant):'')+(line.addOnIds.length?' · '+line.addOnIds.join(', '):'')+'</small><b>'+pesos(posLineTotal(line))+'</b></div><div class="pos-qty-controls"><button type="button" data-pos-minus="'+i+'">−</button><span>'+line.qty+'</span><button type="button" data-pos-plus="'+i+'">+</button><button type="button" data-pos-remove="'+i+'">Remove</button></div></div>').join(''):'<div class="empty">Cart is empty. Add an item to start.</div>';const total=dineCart.reduce((sum,line)=>sum+posLineTotal(line),0);$('#pos-total').textContent=pesos(total);const submit=$('#pos-submit');if(submit)submit.disabled=!dineCart.length;}

const tag=s=>`<span class="badge ${esc(s)}">${esc(statNames[s]||s)}</span>`;
const notice=msg=>{const el=$('#toast');el.textContent=msg;el.className='toast';clearTimeout(window.noticeT);window.noticeT=setTimeout(()=>el.className='',3400)};
function primeStaffAudio(){try{soundCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(soundCtx.state==='suspended')soundCtx.resume();}catch(error){console.warn('Staff audio could not be enabled',error);}}
const activeAudioSources=new Set();
async function loadSharedSound(kind){const response=await fetch('/api/staff/sounds/'+kind,{credentials:'same-origin',cache:'no-store'});if(!response.ok){if(response.status===404)return null;throw Error('Could not load the uploaded ringtone.');}const raw=await response.arrayBuffer();const ctx=soundCtx||new (window.AudioContext||window.webkitAudioContext)();soundCtx=ctx;if(ctx.state==='suspended')await ctx.resume();try{return await ctx.decodeAudioData(raw.slice(0));}catch{throw Error('This audio file cannot be decoded by your browser. Try a standard MP3, WAV, OGG, M4A or AAC file.');}}
async function playCustomAlert(kind){const buffer=await loadSharedSound(kind);if(!buffer)return false;const ctx=soundCtx||new (window.AudioContext||window.webkitAudioContext)();soundCtx=ctx;const source=ctx.createBufferSource();const gain=ctx.createGain();source.buffer=buffer;gain.gain.value=.65;source.connect(gain);gain.connect(ctx.destination);activeAudioSources.add(source);source.onended=()=>activeAudioSources.delete(source);source.start();return true;}
function stopStaffAudio(){for(const source of [...activeAudioSources]){try{source.stop();}catch{}activeAudioSources.delete(source);}}
async function playStaffAlert(kind){if(staffSoundMuted)return;try{if(await playCustomAlert(kind))return;}catch(e){console.warn('Custom staff sound failed; using default tone',e);}try{soundCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(soundCtx.state==='suspended')await soundCtx.resume();const notes=kind==='kitchen'?[740,980]:[620,820];notes.forEach((freq,i)=>{const osc=soundCtx.createOscillator(),gain=soundCtx.createGain();osc.type='sine';osc.frequency.value=freq;gain.gain.setValueAtTime(.0001,soundCtx.currentTime+i*.16);gain.gain.exponentialRampToValueAtTime(.13,soundCtx.currentTime+i*.16+.02);gain.gain.exponentialRampToValueAtTime(.0001,soundCtx.currentTime+i*.16+.14);osc.connect(gain);gain.connect(soundCtx.destination);osc.start(soundCtx.currentTime+i*.16);osc.stop(soundCtx.currentTime+i*.16+.15);});}catch(e){console.warn('Staff alert sound unavailable',e);}}
async function previewAlertSound(kind){stopStaffAudio();try{if(await playCustomAlert(kind)){notice((kind==='cashier'?'Cashier':'Kitchen')+' preview playing.');return;}notice('No ringtone uploaded yet for '+kind+'.');}catch(e){notice('Preview failed: '+e.message);}}
function soundSettingsControl(){return `<div class="staff-sound-controls"><button class="small-btn" id="toggle-staff-sounds" title="Notification sounds">${staffSoundMuted?'🔇 Sounds muted':'🔔 Sounds on'}</button></div>`;}
function ringtoneAdminPanel(){return `<section class="panel ringtone-admin"><h3>Staff Notification Ringtones</h3><p class="help">Upload ringtones here as Admin. These shared sounds are used by Cashier and Kitchen. Maximum 3.5 MB each; MP3, WAV, OGG, M4A or AAC.</p><div class="sound-upload-row"><label class="field">Cashier ringtone<input type="file" id="cashier-sound-upload" accept=".mp3,.wav,.ogg,.m4a,.aac,audio/mpeg,audio/wav,audio/ogg,audio/mp4,audio/aac"></label><button class="small-btn" id="preview-cashier-sound" type="button">Preview Cashier</button><label class="field">Kitchen ringtone<input type="file" id="kitchen-sound-upload" accept=".mp3,.wav,.ogg,.m4a,.aac,audio/mpeg,audio/wav,audio/ogg,audio/mp4,audio/aac"></label><button class="small-btn" id="preview-kitchen-sound" type="button">Preview Kitchen</button></div></section>`;}
async function uploadSharedSound(kind,file){if(!file)throw Error('Choose a ringtone file.');if(file.size>3.5*1024*1024)throw Error('Ringtone must be 3.5 MB or smaller.');const ext=file.name.split('.').pop().toLowerCase();const mimeByExt={mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',m4a:'audio/mp4',aac:'audio/aac'};const mime=mimeByExt[ext];if(!mime)throw Error('Use MP3, WAV, OGG, M4A or AAC.');const ctx=soundCtx||new (window.AudioContext||window.webkitAudioContext)();soundCtx=ctx;const buffer=await file.arrayBuffer();try{await ctx.decodeAudioData(buffer.slice(0));}catch{throw Error('This file is not playable in this browser. Please try another supported audio file.');}const bytes=new Uint8Array(buffer);let binary='';for(let offset=0;offset<bytes.length;offset+=0x8000)binary+=String.fromCharCode(...bytes.subarray(offset,offset+0x8000));const base64=btoa(binary);await call('/api/staff/sounds/'+kind,'POST',{mime,name:file.name,base64});notice((kind==='cashier'?'Cashier':'Kitchen')+' ringtone uploaded and shared successfully.');}
async function call(url,method='GET',payload){
  const headers={'X-FYI-Staff-Role':user?.role||loginRole};
  if(payload)headers['Content-Type']='application/json';
  const r=await fetch(url,{method,headers,credentials:'same-origin',
    body:payload?JSON.stringify(payload):undefined});
  let v;try{v=await r.json()}catch{v={error:'Unexpected response'}}
  if(!r.ok)throw Error(v.error||'Request failed');return v;
}
function requestConfirmation(title,message,confirmLabel='Confirm'){
 if(confirmationResolver)finishConfirmation(false);
 $('#action-confirm-title').textContent=title;
 $('#action-confirm-message').textContent=message;
 $('#action-confirm-accept').textContent=confirmLabel;
 $('#action-confirm-modal').classList.remove('hidden');
 $('#action-confirm-accept').focus();
 return new Promise(resolve=>{confirmationResolver=resolve;});
}
function finishConfirmation(accepted){
 if(!confirmationResolver)return;
 const resolve=confirmationResolver;confirmationResolver=null;
 $('#action-confirm-modal').classList.add('hidden');
 resolve(accepted);
}
$('#action-confirm-cancel').addEventListener('click',()=>finishConfirmation(false));
$('#action-confirm-accept').addEventListener('click',()=>finishConfirmation(true));
$('#action-confirm-modal').addEventListener('click',event=>{if(event.target.id==='action-confirm-modal')finishConfirmation(false);});
document.addEventListener('keydown',event=>{
 if(event.key==='Escape'&&!$('#action-confirm-modal').classList.contains('hidden'))finishConfirmation(false);
});
function showStaffRecovery(){const roleLabel=roleNames[loginRole]||'staff';const message=loginRole==='owner'?'For Admin PIN recovery, contact the authorized system owner/developer to verify your identity and reset the credential securely.':`For ${roleLabel} access recovery, contact the Admin 1 account holder. Admin 1 can update staff credentials in Staff Accounts after verifying your identity.`;$('#login-error').textContent=message;}
document.addEventListener('click',event=>{if(event.target.closest('[data-forgot-access]'))showStaffRecovery();});
function selectLogin(role){loginRole=role;sessionStorage.setItem(STAFF_TAB_ROLE_KEY,role);pin='';$('#login-title').textContent=role==='kitchen'?'Kitchen Staff Login':role==='cashier'?'Enter Cashier PIN':'Enter Admin PIN';$('#login-description').textContent=role==='kitchen'?'Sign in to access Kitchen Orders':'Enter your 4-digit staff PIN for quick access';$('#pin-pane').classList.toggle('hidden',role==='kitchen');$('#kitchen-pane').classList.toggle('hidden',role!=='kitchen');document.querySelectorAll('.role-pill').forEach(x=>x.classList.toggle('active',x.dataset.login===role));$('#login-error').textContent='';renderDots();}
function renderDots(){$('#pin-dots').innerHTML=Array.from({length:Math.max(4,Math.min(pin.length,8))},(_,i)=>`<i class="${i<pin.length?'filled':''}"></i>`).join('');}
async function doLogin(){try{const payload=loginRole==='kitchen'?{role:'kitchen',username:$('#kitchen-username').value,password:$('#kitchen-password').value}:{role:loginRole,pin};await call('/api/login','POST',payload);await boot();}catch(e){$('#login-error').textContent=e.message;pin='';renderDots();}}
$('#keypad').addEventListener('click',e=>{const k=e.target.closest('button')?.dataset.key;if(!k)return;if(k==='back')pin=pin.slice(0,-1);else if(k==='enter'){doLogin();return;}else if(pin.length<8)pin+=k;renderDots();});
$('#kitchen-pane').addEventListener('submit',e=>{e.preventDefault();doLogin();});
document.querySelectorAll('[data-login]').forEach(b=>b.addEventListener('click',()=>selectLogin(b.dataset.login)));
$('#logout').addEventListener('click',async()=>{
 if(signingOut)return;
 if(!await requestConfirmation('Sign out?','Are you sure you want to sign out?','Sign out'))return;
 signingOut=true;$('#logout').disabled=true;
 try{
  await call('/api/logout','POST',{});
  clearInterval(poll);clearTimeout(storeReconnectTimer);
  if(storeSocket){storeSocket.onclose=null;storeSocket.close();storeSocket=null;}
  sessionStorage.removeItem(STAFF_TAB_ROLE_KEY);
  user=null;data=null;dashboardMetrics=null;
  location.replace('/staff');
 }catch(error){
  notice('Sign out failed: '+error.message);
 }finally{signingOut=false;$('#logout').disabled=false;}
});
async function loadDashboardMetrics(force=false){
 if(!user||!['owner','cashier'].includes(user.role))return;
 if(!force&&dashboardMetrics&&dashboardMetrics.period===dashboardPeriod&&Date.now()-dashboardFetchedAt<20000)return;
 dashboardMetrics=await call(`/api/staff/dashboard?period=${encodeURIComponent(dashboardPeriod)}`);
 dashboardFetchedAt=Date.now();
}
async function boot(){const me=await call('/api/me');user=me.user;if(user){loginRole=user.role;sessionStorage.setItem(STAFF_TAB_ROLE_KEY,loginRole);}if(!user){$('#login').classList.remove('hidden');$('#app').classList.add('hidden');return;}$('#login').classList.add('hidden');$('#app').classList.remove('hidden');$('#top-name').textContent=user.name;$('#top-role-name').textContent=roleNames[user.role];$('#top-role').textContent=user.role==='owner'?'OW':user.role==='cashier'?'CA':'KI';section=user.role==='owner'||user.role==='cashier'?'dashboard':'kitchen';dashboardPeriod='week';dashboardMetrics=null;dashboardFetchedAt=0;catalog=await call(user.role==='owner'?'/api/staff/catalog':'/api/public/catalog');try{productImages=(await call('/api/public/product-images')).images||{};}catch(e){notice('Image feature setup needed: '+e.message);}renderNav();await refresh();connectStoreStatus();clearInterval(poll);poll=setInterval(refresh,5000);}
function renderNav(){const nav=user.role==='owner'?navOwner:user.role==='cashier'?navCashier:navKitchen;$('#sidebar-nav').innerHTML=nav.map(([id,ic,label])=>`<button class="sidebar-link ${section===id?'active':''}" data-nav="${id}"><span class="sidebar-icon">${ic}</span><span class="nav-text">${label}</span></button>`).join('');$('#sidebar-nav').querySelectorAll('[data-nav]').forEach(el=>el.addEventListener('click',()=>{section=el.dataset.nav;activeOrder=null;filter='all';search='';renderNav();render();if(['customers','payments'].includes(section))refresh()}));}
function connectStoreStatus(){if(!user||storeSocket?.readyState===WebSocket.OPEN||storeSocket?.readyState===WebSocket.CONNECTING)return;storeSocket=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/api/public/store-status/live`);const socket=storeSocket;socket.onopen=()=>{storeRetryCount=0;};socket.onmessage=event=>{try{const status=JSON.parse(event.data);if(status.type!=='store-status')return;$('#store-side').textContent=status.isOpen?'Open · Accepting Orders':'Closed · Orders Paused';const signature=[status.isOpen,status.override,status.open,status.close].join('|');if(lastStoreConfig&&signature!==lastStoreConfig)refresh();lastStoreConfig=signature;}catch(error){console.warn('Invalid live store status:',error.message);}};socket.onclose=()=>{if(!user)return;const delay=Math.min(1000*2**storeRetryCount,15000);storeRetryCount+=1;clearTimeout(storeReconnectTimer);storeReconnectTimer=setTimeout(connectStoreStatus,delay);};}
async function refresh(){try{const previous=data?.orders;data=await call('/api/staff/overview');if(previous&&user.role==='kitchen'){const prevIds=new Set(previous.map(o=>o.id));const prevById=new Map(previous.map(o=>[o.id,o]));const newKitchen=data.orders.filter(o=>['accepted','preparing','ready'].includes(o.status)&&(!prevIds.has(o.id)||!['accepted','preparing','ready'].includes(prevById.get(o.id)?.status)));if(newKitchen.length){const fresh=newKitchen.filter(o=>alertOnce('kitchen',o.id));if(fresh.length){notice(`New kitchen ticket: ${fresh.map(o=>o.id).join(', ')}`);playStaffAlert('kitchen');}}}if(previous&&['owner','cashier'].includes(user.role)){const previousById=new Map(previous.map(order=>[order.id,order]));const newOrders=data.orders.filter(order=>!previousById.has(order.id)&&order.status==='pending_payment');const paidOrders=data.orders.filter(order=>order.paymentStatus==='paid'&&previousById.get(order.id)?.paymentStatus!=='paid');if(newOrders.length&&user.role==='cashier'){const fresh=newOrders.filter(order=>alertOnce('cashier',order.id));if(fresh.length){notice(`New customer order: ${fresh.map(order=>order.id).join(', ')}.`);playStaffAlert('cashier');}}if(paidOrders.length){notice(`Payment confirmed: ${paidOrders.map(order=>order.id).join(', ')}. Ready for cashier acceptance.`);if(section==='dashboard')await loadDashboardMetrics(true);}}if(section==='dashboard'&&['owner','cashier'].includes(user.role))await loadDashboardMetrics();if(section==='customers'&&user.role==='owner')customerRows=(await call('/api/staff/customers')).customers||[];if(section==='payments'&&['owner','cashier'].includes(user.role))paymentRows=(await call('/api/staff/payment-transactions')).transactions||[];const status=await call('/api/public/config');$('#store-side').textContent=status.isOpen?'Open · Accepting Orders':'Closed · Orders Paused';lastStoreConfig=[status.isOpen,status.override,status.open,status.close].join('|');if(section!=='dinein'&&!uploadingProduct&&!menuModalOpen&&!document.querySelector('#content input:focus, #content select:focus, #content textarea:focus'))render();}catch(e){if(e.message==='Please sign in.'){clearInterval(poll);location.reload();return;}notice('Connection issue: '+e.message);}}
const intro=(title,desc,right='')=>`<div class="page-intro"><div><h1>${title}</h1><p>${desc}</p></div>${right||''}</div>`;
const metric=(label,num,icon,color='')=>`<div class="metric"><div class="metric-top"><div class="metric-icon ${color}">${icon}</div><label>${label}</label></div><h2>${num}</h2><small>Updated with shared server data</small></div>`;
function recentRows(items){return `<div style="overflow:auto"><table class="rows"><thead><tr><th>Order ID</th><th>Customer</th><th>Order Type</th><th>Total</th><th>Payment</th><th>Status</th><th>Action</th></tr></thead><tbody>${items.length?items.map(o=>`<tr><td><b>${esc(o.id)}</b></td><td>${esc(o.customer.name)}</td><td>${o.type==='delivery'?'🛵 Delivery':'🍽 Dine In'}</td><td><b>${pesos(o.total)}</b></td><td>${esc(o.paymentMethod)}</td><td>${tag(o.status)}</td><td><button class="small-btn" data-order="${esc(o.id)}">View →</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">No orders to show yet.</td></tr>'}</tbody></table></div>`;}
function groupSeries(rows,period,valueKey){
 const groups=new Map();
 for(const row of rows||[]){
  const date=new Date(row.bucket);
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{
   timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'
  }).formatToParts(date).filter(part=>part.type!=='literal').map(part=>[part.type,part.value]));
  const groupedHour=Math.floor(Number(parts.hour)/4)*4;
  const key=period==='today'?`${parts.year}-${parts.month}-${parts.day}T${String(groupedHour).padStart(2,'0')}`:
   period==='year'?`${parts.year}-${parts.month}`:`${parts.year}-${parts.month}-${parts.day}`;
  const label=period==='today'
   ?new Intl.DateTimeFormat('en-PH',{timeZone:'UTC',hour:'numeric'}).format(new Date(Date.UTC(2000,0,1,groupedHour)))
   :period==='year'
    ?new Intl.DateTimeFormat('en-PH',{timeZone:'Asia/Manila',month:'short'}).format(date)
    :new Intl.DateTimeFormat('en-PH',{timeZone:'Asia/Manila',weekday:'short',day:'numeric'}).format(date);
  const previous=groups.get(key)||{label,value:0,orders:0};
  previous.value+=Number(row[valueKey]||0);
  previous.orders+=Number(row.orders||0);
  groups.set(key,previous);
 }
 return [...groups.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([,value])=>value);
}
function completeWeekSeries(rows){
 const byDay=new Map(rows.map(row=>[row.label.slice(0,3),row]));
 const labels=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
 return labels.map(label=>byDay.get(label)||{label,value:0,orders:0});
}
function chartPanel(title,rows,period,valueLabel='orders'){
 const max=Math.max(1,...rows.map(row=>row.value));
 const total=rows.reduce((sum,row)=>sum+row.value,0);
 return `<section class="panel"><div class="panel-head"><h3>${title}</h3><span>${rows.length?`${valueLabel==='sales'?pesos(total):total.toLocaleString('en-PH')} · ${period==='today'?'Today':period}`:'No data in this period'}</span></div><div class="bars" role="img" aria-label="${title} chart">${rows.length?rows.map(row=>`<div class="bar-item" title="${esc(row.label)}: ${valueLabel==='sales'?pesos(row.value):row.value}" data-n="${esc(valueLabel==='sales'?pesos(row.value):row.value)}" data-day="${esc(row.label)}" style="height:${Math.max(2,row.value/max*100)}%"></div>`).join(''):'<div class="empty">No records yet.</div>'}</div></section>`;
}
function recentOrderTable(items){
 return `<div class="table-scroll"><table class="rows"><thead><tr><th>Order Number</th><th>Customer</th><th>Date & Time</th><th>Ordered Items</th><th>Total</th><th>Payment</th><th>Order Status</th><th>Action</th></tr></thead><tbody>${items.length?items.map(order=>`<tr><td><b>${esc(order.id)}</b></td><td>${esc(order.customer.name)}</td><td>${new Date(order.createdAt).toLocaleString('en-PH')}</td><td>${order.items.map(item=>`${esc(item.qty)}× ${esc(item.name)}`).join('<br>')}</td><td><b>${pesos(order.total)}</b></td><td>${tag(order.paymentStatus)}</td><td>${tag(order.status)}</td><td><button class="small-btn" data-order="${esc(order.id)}">View Details</button></td></tr>`).join(''):'<tr><td colspan="8" class="empty">No recent orders yet.</td></tr>'}</tbody></table></div>`;
}
function recentTransactionsTable(items){
 return `<div class="table-scroll"><table class="rows"><thead><tr><th>Payment Reference</th><th>Order</th><th>Customer</th><th>Amount</th><th>Payment Status</th><th>Date</th></tr></thead><tbody>${items.length?items.map(row=>`<tr><td><b>${esc(row.payment_reference)}</b></td><td>${esc(row.order_id)}</td><td>${esc(row.username||'Customer')}</td><td><b>${pesos(Number(row.amount_minor)/100)}</b></td><td>${tag(row.payment_status)}</td><td>${new Date(row.created_at).toLocaleString('en-PH')}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">No payment transactions yet.</td></tr>'}</tbody></table></div>`;
}
function dashboard(){
 const metrics=dashboardMetrics;
 const periodPicker=`<div class="chart-period-picker">${['today','week','month','year'].map(p=>`<button type="button" data-chart-period="${p}" class="${dashboardPeriod===p?'selected':''}">${p[0].toUpperCase()+p.slice(1)}</button>`).join('')}</div>`;
 if(user.role==='cashier'){
  let rows=groupSeries(metrics?.orderSeries||[],dashboardPeriod,'orders').map(row=>({...row,value:row.orders}));if(dashboardPeriod==='week')rows=completeWeekSeries(rows);
  return intro('Cashier Dashboard','Orders from the customer app, updated from Supabase.',soundSettingsControl())+
   `<section class="metrics cashier-metrics">${metric('Total Orders',metrics?.totalOrders??data.orders.length,'▤')}</section>`+
   periodPicker+chartPanel('Order Activity',rows,dashboardPeriod)+
   `<section class="panel"><div class="panel-head"><h3>Recent Orders</h3><button class="small-btn" data-go="orders">View Pending Orders</button></div>${recentOrderTable(data.orders.slice(0,12))}</section>`;
 }
 let salesRows=groupSeries(metrics?.salesSeries||[],dashboardPeriod,'sales').map(row=>({...row,orders:0}));if(dashboardPeriod==='week')salesRows=completeWeekSeries(salesRows);
 const counts=metrics?.today?.statusCounts||{};
 const pending=['pending_payment','pending_verification','pending_acceptance'].reduce((sum,status)=>sum+(counts[status]||0),0);
 const summaryCards=`<section class="metrics">${metric('Total Sales Today',pesos(metrics?.todaySales||0),'₱')}${metric('Total Orders Today',metrics?.today?.orderCount??'—','▤')}${metric('Pending Orders',pending,'◷','orange')}${metric('Completed Orders',Number(counts.delivered||0).toLocaleString('en-PH'),'✓','blue')}</section>`;
 return intro('Admin Dashboard','Sales and orders from the customer app, updated from Supabase.')+
  periodPicker+chartPanel('Sales',salesRows,dashboardPeriod,'sales')+summaryCards+
  `<section class="panel"><div class="panel-head"><h3>Recent Orders</h3><button class="small-btn" data-go="orders">View all</button></div>${recentOrderTable(data.orders.slice(0,12))}</section>`;
}
function ordersPage(mode='orders'){let arr=data.orders;const titles={orders:'Order Management',payments:'Payment Transactions',dispatch:'Dispatch Queue'};const subtitles={orders:'Review and manage customer orders.',payments:'PayMongo payment records and their linked orders.',dispatch:'Send kitchen-ready orders for delivery or mark them served.'};if(mode==='payments')arr=arr.filter(x=>['pending_payment','pending_verification'].includes(x.status));if(mode==='dispatch')arr=arr.filter(x=>['ready','out'].includes(x.status));if(filter!=='all')arr=arr.filter(x=>x.status===filter);if(search.trim()){const s=search.toLowerCase();arr=arr.filter(x=>(x.id+x.customer.name+x.customer.phone).toLowerCase().includes(s));}const transactionTable=mode==='payments'?`<section class="panel"><div class="panel-head"><h3>PayMongo Transactions</h3><small>${paymentRows.length} records</small></div><div style="overflow:auto"><table class="rows"><thead><tr><th>Payment Reference</th><th>Customer</th><th>Order</th><th>Amount</th><th>Payment</th><th>Order Status</th><th>Created</th></tr></thead><tbody>${paymentRows.length?paymentRows.map(x=>`<tr><td><b>${esc(x.payment_reference)}</b></td><td>${esc(x.username||'Customer')}</td><td>${esc(x.order_id)}</td><td><b>${pesos(Number(x.amount_minor)/100)}</b></td><td>${esc(x.payment_status)}</td><td>${tag(x.order_status)}</td><td>${new Date(x.created_at).toLocaleString('en-PH')}</td></tr>`).join(''):'<tr><td colspan="7" class="empty">No payment transactions yet.</td></tr>'}</tbody></table></div></section>`:'';return intro(titles[mode],subtitles[mode],`<input class="search" id="order-search" placeholder="Search orders or customers..." value="${esc(search)}">`)+(mode==='payments'?'<p class="note">Transactions are written to Supabase and update to paid only after PayMongo confirms the payment.</p>'+transactionTable:'')+`<section class="panel"><div class="filter-row">${['all','pending_payment','pending_verification','pending_acceptance','accepted','preparing','ready','out','delivered','rejected'].map(s=>`<button data-filter="${s}" class="${filter===s?'selected':''}">${s==='all'?'All Orders':statNames[s]}</button>`).join('')}</div>${recentRows(arr)}</section>`;}

// FYI UPGRADES: map handoff and kitchen image helpers.
function fyiValidPin(order) {
  const p = order?.customer?.deliveryPin || order?.deliveryLocation || {};
  const lat = Number(p.lat ?? p.latitude), lng = Number(p.lng ?? p.longitude);
  return Number.isFinite(lat) && Number.isFinite(lng) &&
    lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 &&
    !(lat === 0 && lng === 0) ? {lat, lng} : null;
}
function fyiRiderLink(order) {
  const p = fyiValidPin(order);
  if (p) return 'https://www.google.com/maps/dir/?api=1&destination=' +
    encodeURIComponent(p.lat + ',' + p.lng) + '&travelmode=driving';
  const address = String(order?.customer?.address || '').trim();
  return address ? 'https://www.google.com/maps/search/?api=1&query=' +
    encodeURIComponent(address) : '';
}
function fyiDeliveryCard(order) {
  if (!['owner','cashier'].includes(user?.role) || order.type !== 'delivery') return '';
  const customer = order.customer || {};
  const pin = fyiValidPin(order);
  const mapUrl = fyiRiderLink(order);
  const embed = pin ? 'https://maps.google.com/maps?q=' +
    encodeURIComponent(pin.lat + ',' + pin.lng) + '&z=16&output=embed' : '';
  return '<div class="detail-card fyi-delivery-card">' +
    '<h4>Rider Delivery Location</h4>' +
    '<p><b>Address:</b> ' + esc(customer.address || 'Not provided') + '</p>' +
    '<p><b>Landmark:</b> ' + esc(customer.landmark || 'Not provided') + '</p>' +
    '<p><b>Road distance:</b> ' + esc(order.roadKm ?? '—') + ' km</p>' +
    (pin ? '<p class="fyi-map-note">Customer-selected pin (exact drop-off marker).</p>' +
       '<iframe class="fyi-map-frame" loading="lazy" title="Customer delivery pin" referrerpolicy="no-referrer-when-downgrade" src="' + esc(embed) + '"></iframe>' :
       '<p class="fyi-map-warning">This order does not have a saved map pin. Address search is approximate; confirm the location with the customer.</p>') +
    '<div class="fyi-map-actions">' +
      (mapUrl ? '<a class="small-btn main" href="' + esc(mapUrl) + '" target="_blank" rel="noopener noreferrer">' +
        (pin ? 'View Pin / Directions ↗' : 'Search Address ↗') + '</a>' : '') +
      '<button type="button" class="small-btn" data-copy-rider="' + esc(order.id) + '">Copy Rider Details</button>' +
    '</div></div>';
}
function fyiKitchenItem(item) {
  const p = catalog?.products?.find(p => p.id === item.productId) ||
    catalog?.products?.find(p => String(p.name).toLowerCase() === String(item.name).toLowerCase());
  const source = productImages?.[item.productId] || p?.imageUrl || '';
  const img = typeof source === 'string' &&
    (/^https:\/\//i.test(source) || /^\/assets\//.test(source)) ? source : '';
  return '<div class="fyi-kitchen-item">' +
    (img ? '<img class="fyi-kitchen-img" loading="lazy" src="' + esc(img) + '" alt="' + esc(item.name) + '">' :
      '<div class="fyi-kitchen-img fyi-kitchen-no-photo">🍽</div>') +
    '<div class="fyi-kitchen-meta"><strong>' + esc(item.qty) + '× ' + esc(item.name) + '</strong>' +
    '<small>' + esc(item.size || '') + (item.variant ? ' · ' + esc(item.variant) : '') + '</small></div></div>';
}
function fyiRiderDetails(order) {
  const c = order.customer || {};
  return ['FYI KANTOFOODS DELIVERY', 'Order: ' + order.id,
    'Customer: ' + (c.name || ''), 'Phone: ' + (c.phone || ''),
    'Address: ' + (c.address || ''), 'Landmark: ' + (c.landmark || '—'),
    'Notes: ' + (c.notes || '—'),
    'Map: ' + (fyiRiderLink(order) || 'Pin unavailable')].join('\n');
}

function orderDetail(){const o=data.orders.find(x=>x.id===activeOrder);if(!o){activeOrder=null;return ordersPage(section);}const actions=[];
 if(user.role==='cashier'&&o.status==='pending_verification')actions.push(['verify','Verify Payment & Accept','main'],['reject','Reject Order','danger']);
 if(user.role==='cashier'&&o.status==='pending_payment')actions.push(['reject','Reject Unpaid Order','danger']);
 if(user.role==='cashier'&&o.status==='pending_acceptance')actions.push(['accept','Accept Delivery','main'],['reject','Reject','danger']);
 if(user.role==='cashier'&&o.status==='ready')actions.push(['dispatch',o.type==='delivery'?'Out for Delivery':'Ready to Serve','main']);
 if(user.role==='cashier'&&o.status==='out')actions.push(['delivered',o.type==='delivery'?'Mark Delivered':'Mark Served','main']);
 if(user.role==='kitchen'&&o.status==='accepted')actions.push(['start','Start Preparing','main']);
 if(user.role==='kitchen'&&o.status==='preparing')actions.push(['ready','Mark Ready','main']);
 return intro('Order Details',`#${esc(o.id)} · Placed ${new Date(o.createdAt).toLocaleString('en-PH')}`,`<button class="small-btn" id="back-orders">← Back</button>`)+`<div class="panel"><div class="panel-head"><h3>${tag(o.status)} &nbsp; ${o.type==='delivery'?'Delivery order':'Dine-in order'}</h3><strong>${pesos(o.total)}</strong></div><div class="order-detail">${fyiDeliveryCard(o)}<div class="detail-card"><h4>Customer Details</h4><p><b>Customer:</b> ${esc(o.customer.name)}<br><b>Phone:</b> ${esc(o.customer.phone)}<br><b>Address:</b> ${esc(o.customer.address||'Dine-in')}<br><b>Facebook:</b> ${esc(o.customer.facebook||'—')}<br><b>Notes:</b> ${esc(o.customer.notes||'—')}</p></div><div class="detail-card"><h4>Payment</h4><p>Method: <b>${esc(o.paymentMethod.toUpperCase())}</b><br>Status: <b>${esc(o.paymentStatus)}</b><br>Reference: ${esc(o.gcashReference||'—')}</p>${o.hasProof&&user.role!=='kitchen'?`<a class="small-btn" target="_blank" rel="noopener" href="/api/staff/proof/${encodeURIComponent(o.id)}?staff_role=${encodeURIComponent(user.role)}">View Payment Screenshot ↗</a>`:''}${o.paymentStatus==='pending_verification'?'<p class="help">Screenshot submitted only. Verify funds in the actual GCash app before acceptance.</p>':''}</div><div class="detail-card"><h4>Order Items</h4>${o.items.map(x=>user.role==='kitchen'?fyiKitchenItem(x):`<div class="summary-line"><span>${x.qty}× ${esc(x.name)} (${esc(x.size)})</span><b>${pesos(x.lineTotal)}</b></div>`).join('')}<div class="summary-line"><span>Subtotal</span><b>${pesos(o.subtotal)}</b></div><div class="summary-line"><span>Delivery (${o.roadKm??'—'} km)</span><b>${pesos(o.deliveryFee)}</b></div><div class="summary-line total"><span>Total</span><span>${pesos(o.total)}</span></div></div><div class="detail-card"><h4>Order Timeline</h4>${o.history.map(h=>`<div class="summary-line"><span>${tag(h.status)}<br><small>${esc(h.description||'')}</small></span><small>${new Date(h.at).toLocaleTimeString('en-PH',{hour:'numeric',minute:'2-digit'})}</small></div>`).join('')}</div></div>${actions.length?`<div class="actions" style="margin-top:18px">${actions.map(([id,label,style])=>`<button data-action="${id}" class="small-btn ${style}" style="padding:12px 19px">${label}</button>`).join('')}</div>`:'<p class="help">No status updates available for your role at this stage.</p>'}</div>`;}
function kitchen(){const queue=data.orders.filter(o=>['accepted','preparing','ready'].includes(o.status));return intro('Kitchen Orders','New accepted orders appear here after Cashier approval.',`<span class="subtle-label">${queue.length} kitchen tickets</span> &nbsp; ${soundSettingsControl()}`)+`<p class="note">Only accepted orders reach the kitchen. GCash orders cannot begin until cashier verification.</p>${queue.length?queue.map(o=>`<div class="kitchen-card"><div><small>ORDER #${esc(o.id)}</small><h3>${o.type==='delivery'?'Delivery':'Dine-In'} · ${esc(o.customer.name)}</h3>${tag(o.status)}<div class="kitchen-items">${o.items.map(fyiKitchenItem).join('')}</div><p class="help">${esc(o.customer.notes||'No special notes')}</p></div><div><button class="small-btn main" data-order="${esc(o.id)}">Open Ticket →</button></div></div>`).join(''):'<div class="panel empty">🍵 No accepted kitchen tickets yet. Waiting for cashier…</div>'}`;}
// Full Product Manager uses live Supabase catalog. Built-in images are preserved,
// while product edits/availability and newly created items come from the backend.
function products(){
 const cats=catalog.categories||[];
 const addons=catalog.menuAddons||[];
 const available=catalog.products.filter(p=>p.active!==false).length;
 const cards=catalog.products.map(x=>{
   const imageUrl=productImages[x.id]||x.imageUrl;
   const prices=(x.sizes||[]).map(s=>Number(s.price));
   const range=prices.length>1?pesos(Math.min(...prices))+' – '+pesos(Math.max(...prices)):pesos(prices[0]);
   return `<article class="product-card catalog-card" data-photo-name="${esc(x.name.toLowerCase())}" data-menu-category="${esc(x.category)}">
    ${imageUrl?`<img loading="lazy" src="${esc(imageUrl)}" alt="${esc(x.name)}">`:'<div class="no-photo">🍽️</div>'}
    <div class="product-body"><div class="catalog-head"><strong>${esc(x.name)}</strong><span class="catalog-pill ${x.active===false?'off':''}">${x.active===false?'Inactive':'● Active'}</span></div>
    <p>${esc(cats.find(c=>c.id===x.category)?.label||x.category)}</p>
    <b>${range}</b>
    <div class="catalog-actions">
      <button type="button" class="small-btn" data-product-edit="${esc(x.id)}">✎ Edit</button>
      <button type="button" class="small-btn danger" data-product-toggle="${esc(x.id)}">${x.active===false?'Activate':'Deactivate'}</button>
    </div></div></article>`;
 }).join('');
 return intro('Menu / Products','Manage items, prices and photos. Changes sync with Expo Go and QR Web.',
   '<div class="menu-top-actions"><button id="add-new-product" class="primary-btn">＋ Add Product</button><button id="add-new-category" class="primary-btn">＋ Add Category</button><button id="manage-addons" class="primary-btn">＋ Add Add-ons</button></div>')+
   `<div class="panel catalog-toolbar"><div><h3>Product Manager</h3><p class="help">${available} active · ${catalog.products.length} total · ${addons.filter(addon=>addon.active!==false).length} active add-ons</p></div>
   <div class="catalog-search"><input id="product-photo-search" class="search" placeholder="Search products..." aria-label="Search products">
   <select id="menu-category-filter" aria-label="Filter category"><option value="all">All categories</option>${cats.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('')}</select></div></div>
   <div class="product-grid">${cards}</div>
   <div id="product-editor" class="menu-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="product-editor-title">
     <div class="menu-editor"><div class="menu-editor-header"><div><h2 id="product-editor-title">Edit Product</h2><p class="help">Changes are saved in Supabase.</p></div></div>
     <form id="product-editor-form">
       <input name="id" type="hidden">
       <input name="addOns" type="hidden">
       <div class="form-grid">
         <label class="field">Product Name *<input name="name" required maxlength="100" placeholder="e.g. Blueberry Fruit Tea"></label>
         <label class="field">Category *<select name="category" required>${cats.filter(c=>c.id!=='all').map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('')}</select></label>
       </div>
       <label class="field">Description<textarea name="description" maxlength="500" rows="3" placeholder="Tell customers about this product"></textarea></label>
       <h3 class="size-heading">Sizes & Prices <button id="add-product-size" type="button" class="small-btn">＋ Add size</button></h3>
       <div id="size-rows"></div>
       <label class="field">Flavors / variants (comma separated)<input name="variants" placeholder="e.g. Chicken, Beef, Pork"></label>
       <div class="assigned-addons"><h3>Optional Add-ons</h3><p class="help">Saved add-ons are matched to this product by its selected category or product assignment. Customers can choose these extras in the mobile menu.</p><div id="product-addon-options"></div></div>
       <div class="photo-edit-row"><div id="product-photo-preview" class="photo-preview">🍽️</div><div><label class="field">Replace Food Photo<input id="product-photo-file" type="file" accept="image/jpeg,image/png,image/webp"></label><small class="help">JPG, PNG or WebP, up to 2 MB. Stored in Supabase Storage.</small></div></div>
       <label class="checkline catalog-active"><input name="active" type="checkbox" checked> Available to customers (Active)</label>
       <div class="menu-editor-footer"><button id="delete-product" type="button" class="small-btn danger-action hidden">Delete Food</button><button id="cancel-product-editor" type="button" class="small-btn">Cancel</button><button type="submit" class="primary-btn">Save Changes</button></div>
     </form>
     <div id="delete-product-confirm" class="modal-layer inner-modal hidden" role="dialog" aria-modal="true" aria-labelledby="delete-product-title"><section class="confirm-modal"><h2 id="delete-product-title">Delete Food</h2><p>Are you sure you want to delete this food product?</p><div class="modal-actions"><button id="cancel-product-delete" class="small-btn" type="button">Cancel</button><button id="confirm-product-delete" class="small-btn danger-action" type="button">Confirm Delete</button></div></section></div>
    </div></div>
   <div id="category-editor" class="menu-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="category-editor-title"><div class="menu-editor"><div class="menu-editor-header"><div><h2 id="category-editor-title">Add Category</h2><p class="help">New categories are saved in Supabase.</p></div></div><form id="category-editor-form"><label class="field">Category Name *<input name="label" required maxlength="60"></label><label class="field">Description (optional)<textarea name="description" maxlength="300" rows="3"></textarea></label><label class="field">Category Image (optional)<input name="image" type="file" accept="image/jpeg,image/png,image/webp"></label><small class="help">JPG, PNG or WebP, up to 2 MB.</small><div class="menu-editor-footer"><button id="cancel-category-editor" type="button" class="small-btn">Cancel</button><button type="submit" class="primary-btn">Save Category</button></div></form><section class="category-list"><h3>Saved Categories</h3>${cats.filter(category=>category.id!=='all').map(category=>`<div class="category-row"><strong>${esc(category.label)}</strong><small>${esc(category.description||category.id)}</small></div>`).join('')}</section></div></div>
   <div id="addon-editor" class="menu-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="addon-editor-title"><div class="menu-editor"><div class="menu-editor-header"><div><h2 id="addon-editor-title">Add Add-ons</h2><p class="help">Manage add-ons and product availability in Supabase.</p></div></div><form id="addon-editor-form"><input name="id" type="hidden"><div class="form-grid"><label class="field">Add-on Name *<input name="name" required maxlength="60"></label><label class="field">Additional Price (₱) *<input name="price" type="number" min="0" max="10000" step="0.01" required></label></div><div class="form-grid"><label class="field">Applicable Categories *<select name="categoryIds" multiple size="5">${cats.filter(category=>category.id!=='all').map(category=>`<option value="${esc(category.id)}">${esc(category.label)}</option>`).join('')}</select></label><label class="field">Or Applicable Products<select name="productIds" multiple size="5">${catalog.products.map(product=>`<option value="${esc(product.id)}">${esc(product.name)}</option>`).join('')}</select></label></div><label class="checkline"><input name="active" type="checkbox" checked> Add-on is available</label><div class="menu-editor-footer"><button id="clear-addon-form" type="button" class="small-btn">Cancel</button><button type="submit" class="primary-btn">Save Add-on</button></div></form><section class="addon-list"><h3>Existing Add-ons</h3>${addons.length?addons.map(addon=>`<div class="addon-row"><div><strong>${esc(addon.name)}</strong><small>${pesos(addon.price)} · ${addon.active===false?'Inactive':'Active'}</small></div><div class="actions"><button type="button" class="small-btn" data-addon-edit="${esc(addon.id)}">Edit</button><button type="button" class="small-btn danger" data-addon-toggle="${esc(addon.id)}">${addon.active===false?'Activate':'Deactivate'}</button></div></div>`).join(''):'<p class="empty">No add-ons saved yet.</p>'}</section></div></div>`;
}
function filterMenuCards(){
 const text=$('#product-photo-search')?.value.trim().toLowerCase()||'';
 const category=$('#menu-category-filter')?.value||'all';
 document.querySelectorAll('.catalog-card').forEach(card=>{
   card.hidden=!(card.dataset.photoName.includes(text)&&(category==='all'||card.dataset.menuCategory===category));
 });
}
function addSizeRow(label='Regular',price=''){
 const area=$('#size-rows');if(!area||area.children.length>=5)return;
 const row=document.createElement('div');row.className='size-price-row';
 row.innerHTML='<label class="field">Size label<input class="size-label" maxlength="35" required></label><label class="field">Price (₱)<input class="size-price" type="number" min="1" max="100000" step="0.01" required></label><button type="button" class="small-btn danger remove-size">Remove</button>';
 row.querySelector('.size-label').value=label;row.querySelector('.size-price').value=price;
 row.querySelector('.remove-size').onclick=()=>{if(area.children.length>1)row.remove();else alert('Keep at least one size.');};
 area.appendChild(row);
}
function openProductEditor(id=null){
 const item=id?catalog.products.find(p=>p.id===id):null;
 if(id&&!item)return alert('This product is no longer available. Refresh the page.');
 const f=$('#product-editor-form');f.reset();
 f.elements.namedItem('id').value=item?.id||'';f.elements.namedItem('name').value=item?.name||'';
 f.elements.namedItem('category').value=item?.category||catalog.categories.find(category=>category.id!=='all')?.id||'';
 f.elements.namedItem('description').value=item?.description||'';
 f.elements.namedItem('addOns').value=item?.addOns||'';
 f.elements.namedItem('variants').value=(item?.variants||[]).join(', ');
 f.elements.namedItem('active').checked=item?.active!==false;
 $('#size-rows').innerHTML='';
 (item?.sizes||[{label:'Regular',price:''}]).forEach(x=>addSizeRow(x.label,x.price));
 $('#product-addon-options').innerHTML=productAddonChoices(f.elements.namedItem('category').value,item);
 const imageUrl=productImages[item?.id]||item?.imageUrl||'';
 $('#product-photo-preview').innerHTML=imageUrl?`<img src="${esc(imageUrl)}" alt="Current product photo">`:'🍽️';
 $('#product-photo-file').value='';
 $('#delete-product').classList.toggle('hidden',!item);
 $('#product-editor-title').textContent=item?'Edit Product':'Add New Product';
 f.querySelector('[type="submit"]').textContent=item?'Save Changes':'Add Product';
 menuModalOpen=true;$('#product-editor').classList.remove('hidden');
 f.elements.namedItem('name').focus();
}
function closeProductEditor(){menuModalOpen=false;$('#product-editor')?.classList.add('hidden');}
async function confirmEditorClose(close){
 if(await requestConfirmation('Close this editor?','Are you sure you want to close it? Any unsaved changes will be lost.','Close'))close();
}
function productAddonChoices(category,item){
 const assigned=new Set(item?.addonIds||[]);
 const available=(catalog.menuAddons||[]).filter(addon=>{
  if(addon.active===false&&!assigned.has(addon.id))return false;
  const categories=Array.isArray(addon.categoryIds)?addon.categoryIds:[];
  const products=Array.isArray(addon.productIds)?addon.productIds:[];
  return (!categories.length&&!products.length)||categories.includes(category)||products.includes(item?.id);
 });
 return available.map(addon=>`<label class="addon-check"><input type="checkbox" name="productAddonIds" value="${esc(addon.id)}" ${assigned.has(addon.id)?'checked':''} ${addon.active===false?'disabled':''}><span>${esc(addon.name)} <b>${pesos(addon.price)}</b>${addon.active===false?' · inactive':''}</span></label>`).join('')||'<p class="empty">No applicable add-ons. Create one with Add Add-ons.</p>';
}
function openCategoryEditor(){menuModalOpen=true;$('#category-editor').classList.remove('hidden');$('#category-editor-form').reset();$('#category-editor-form').elements.label.focus();}
function closeCategoryEditor(){menuModalOpen=false;$('#category-editor')?.classList.add('hidden');}
function openAddonEditor(id=null){
 menuModalOpen=true;$('#addon-editor').classList.remove('hidden');
 const form=$('#addon-editor-form');form.reset();
 const item=(catalog.menuAddons||[]).find(addon=>addon.id===id);
 form.elements.namedItem('id').value=item?.id||'';
 form.elements.namedItem('name').value=item?.name||'';
 form.elements.namedItem('price').value=item?.price??'';
 form.elements.namedItem('active').checked=item?.active!==false;
 [...form.elements.namedItem('categoryIds').options].forEach(option=>option.selected=(item?.categoryIds||[]).includes(option.value));
 [...form.elements.namedItem('productIds').options].forEach(option=>option.selected=(item?.productIds||[]).includes(option.value));
 $('#addon-editor-title').textContent=item?'Edit Add-on':'Add Add-ons';
 form.querySelector('[type="submit"]').textContent=item?'Save Changes':'Save Add-on';
}
function closeAddonEditor(){menuModalOpen=false;$('#addon-editor')?.classList.add('hidden');}
async function reloadMenuCatalog(){
 catalog=await call('/api/staff/catalog');
 try{productImages=(await call('/api/public/product-images')).images||{};}
 catch(e){notice('Images unavailable: '+e.message);}
}
async function uploadSelectedPhoto(file,productId){
  if(!file)return;
  const dataUrl=await readMenuImage(file);
  const result=await call('/api/staff/product-image','POST',{productId,dataUrl});
  productImages[productId]=result.imageUrl;
  notice('Product image saved! Expo and QR will use the new photo.');
}
async function readMenuImage(file){
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Choose JPG, PNG or WebP.');
  if(file.size>2*1024*1024||file.size<100)throw Error('Photo must be under 2 MB.');
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>typeof reader.result==='string'?resolve(reader.result):reject(Error('Unable to read selected photo.'));
    reader.onerror=()=>reject(Error('Unable to read selected photo.'));
    reader.readAsDataURL(file);
  });
}

function customers(){return intro('Customer Accounts','Verified customer email addresses, usernames, and totals from confirmed paid orders.')+`<section class="panel"><div style="overflow:auto"><table class="rows"><thead><tr><th>Username</th><th>Email</th><th>Phone</th><th>Delivery Address</th><th>Orders</th><th>Paid Orders</th><th>Total Purchased</th><th>Account Created</th></tr></thead><tbody>${customerRows.map(x=>`<tr><td><b>${esc(x.username)}</b></td><td>${esc(x.email||'—')}</td><td>${esc(x.phone||'—')}</td><td>${esc(x.address||'—')}</td><td>${x.orders}</td><td>${x.paidOrders}</td><td><b>${pesos(x.totalSpent)}</b></td><td>${new Date(x.createdAt).toLocaleDateString('en-PH')}</td></tr>`).join('')||'<tr><td colspan="8" class="empty">No customer accounts yet.</td></tr>'}</tbody></table></div></section>`;}
function reviews(){return intro('Customer Reviews','Feedback shared by customers in the mobile app.')+`<section class="panel">${data.reviews.length?data.reviews.map(x=>`<div class="status-list item" style="border-bottom:1px solid var(--line);padding:15px 0"><strong>${esc(x.name)} &nbsp; <span style="color:#f5a000">${'★'.repeat(x.rating)}</span></strong>${x.productName?`<p><b>About:</b> ${esc(x.productName)}</p>`:''}<p>${esc(x.message)}</p><small>${new Date(x.at).toLocaleString('en-PH')}</small></div>`).join(''):'<div class="empty">No customer reviews yet.</div>'}</section>`;}
function reports(){const o=data.orders,completed=o.filter(x=>x.status==='delivered'),money=completed.reduce((n,x)=>n+x.total,0);const counts={};completed.forEach(x=>x.items.forEach(y=>counts[y.name]=(counts[y.name]||0)+y.qty));return intro('Sales Reports','Only completed orders are counted toward sales totals.')+`<div class="metrics">${metric('Total Sales',pesos(money),'₱')}${metric('Completed Orders',completed.length,'✓')}${metric('Average Order',completed.length?pesos(money/completed.length):'₱0','▧')}</div><section class="panel"><h3>Popular products</h3><div class="status-list" style="margin-top:17px">${Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([name,n])=>`<div class="item"><strong>${esc(name)}</strong><b>${n} sold</b></div>`).join('')||'<div class="empty">Complete an order to see sales insights.</div>'}</div></section>`;}
function staff(){return intro('Staff Accounts','Owner-only staff access overview.')+`<section class="panel"><div class="panel-head"><h3>Staff Members</h3></div><table class="rows"><thead><tr><th>Name</th><th>Role</th><th>Username</th><th>Status</th></tr></thead><tbody>${data.staff.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(roleNames[x.role])}</td><td>${esc(x.username)}</td><td>${x.active?'<span class="badge">Active</span>':'Inactive'}</td></tr>`).join('')}</tbody></table></section><section class="panel"><h3>Add Kitchen Staff</h3><p class="help">Only Kitchen accounts can be added here. Ask your owner to secure their credentials.</p><form id="create-staff" class="form-grid"><label class="field">Full Name<input name="name" maxlength="80" required></label><label class="field">Username<input name="username" maxlength="80" required></label><label class="field">Password (at least 12 characters)<input name="password" type="password" minlength="12" required></label><div style="display:flex;align-items:end"><button class="primary-btn" type="submit">Create Kitchen Account</button></div></form></section>`;}
function settings(){const s=data.settings;return intro('Store Settings','Control customer ordering and business operating hours.')+`<section class="panel"><h3>Store Hours · Philippines Time</h3><p class="help">Open or close ordering now, or follow the schedule. The customer app syncs from the shared backend within about 5 seconds.</p><form id="save-settings" class="form-grid" style="margin-top:18px"><label class="field">Opening Time (HH:MM)<input name="open" type="time" value="${esc(s.open)}" required></label><label class="field">Closing Time (HH:MM)<input name="close" type="time" value="${esc(s.close)}" required></label><label class="field">Manual Override<select name="override"><option value="auto" ${s.override==='auto'?'selected':''}>Follow business hours</option><option value="open" ${s.override==='open'?'selected':''}>Open now</option><option value="closed" ${s.override==='closed'?'selected':''}>Closed now</option></select></label><div style="display:flex;align-items:end;gap:8px;flex-wrap:wrap"><button class="primary-btn" type="submit">Save Hours</button><button class="small-btn" type="button" data-store-override="open">Open Now</button><button class="small-btn" type="button" data-store-override="closed">Close Now</button><button class="small-btn" type="button" data-store-override="auto">Follow Schedule</button></div></form></section><div class="note">Delivery service location: ${esc(s.location.name)}. Verify the business entrance and delivery coverage in server settings before accepting live delivery orders.</div>${ringtoneAdminPanel()}<section class="panel"><h3>QR Ordering URL</h3><p class="help">QR opens the same Expo customer design as on your iPhone. Use your laptop’s Wi-Fi IP when scanning from another phone. Run the Expo web build first (or keep Expo Web running in development).</p><button class="small-btn" id="copy-menu">Copy menu URL</button> &nbsp; <a class="small-btn" href="/menu" target="_blank" rel="noopener">Preview Customer Expo menu</a> &nbsp; <a class="small-btn" href="/qr" target="_blank" rel="noopener">Open printable QR poster</a><p class="help">For public customer access, deploy securely to an HTTPS server with an actual database and credentials. A LAN link only works while your laptop server is running.</p></section>`;}
function render(){if(!data||!user)return;$('#breadcrumb').textContent=activeOrder?'Order Details':({dashboard:'Dashboard',orders:'Orders',payments:'Payment Transactions',dispatch:'Dispatch',kitchen:'Kitchen',menu:'Menu',customers:'Customers',reviews:'Reviews',reports:'Sales Reports',staff:'Staff',settings:'Settings'})[section];
 let html=activeOrder?orderDetail():section==='dashboard'?dashboard():section==='dinein'&&user.role==='cashier'?dineinPOS():['orders','payments','dispatch'].includes(section)?ordersPage(section):section==='kitchen'?kitchen():section==='menu'?products():section==='customers'?customers():section==='reviews'?reviews():section==='reports'?reports():section==='staff'?staff():settings();$('#content').innerHTML=html;attach();if(section==='dinein'&&user.role==='cashier'){renderPosOptions();renderPosCart();}}
function attach(){
 if($('#pos-product')){$('#pos-product').onchange=renderPosOptions;$('#pos-add').onclick=()=>{const p=posProduct(),size=$('#pos-size')?.value,qty=Number($('#pos-qty')?.value||1),variant=$('#pos-variant')?.value||'',addOnIds=[...document.querySelectorAll('[data-pos-addon]:checked')].map(x=>x.value);if(!p||!size||!Number.isInteger(qty)||qty<1||qty>30){notice('Select a valid menu item, size, and quantity.');return;}dineCart.push({productId:p.id,name:p.name,size,variant,addOnIds,qty});renderPosCart();notice('Added to dine-in order.');};document.querySelectorAll('[data-pos-minus]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.posMinus);if(dineCart[i]){dineCart[i].qty=Math.max(1,dineCart[i].qty-1);renderPosCart();}});document.querySelectorAll('[data-pos-plus]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.posPlus);if(dineCart[i]&&dineCart[i].qty<30){dineCart[i].qty++;renderPosCart();}});document.querySelectorAll('[data-pos-remove]').forEach(b=>b.onclick=()=>{dineCart.splice(Number(b.dataset.posRemove),1);renderPosCart();});$('#pos-submit').onclick=async()=>{const table=$('#pos-table').value.trim();if(!table||!dineCart.length){notice('Enter the table number and add at least one item.');return;}if(!await requestConfirmation('Record dine-in payment?','Confirm payment was received at the cashier. This creates a paid dine-in order and sends the ticket to Kitchen.','Confirm & Send'))return;const payload={tableNumber:table,notes:$('#pos-notes').value.trim(),paymentMethod:$('#pos-payment').value,items:dineCart.map(({productId,size,variant,addOnIds,qty})=>({productId,size,variant,addOnIds,qty}))};try{const result=await call('/api/staff/dine-in-orders','POST',payload);dineCart=[];notice('Dine-in order '+result.order.id+' recorded and sent to Kitchen.');await refresh();section='orders';renderNav();render();}catch(e){notice('Dine-in order failed: '+e.message);}};}
 const soundToggle=$('#toggle-staff-sounds');if(soundToggle)soundToggle.onclick=()=>{staffSoundMuted=!staffSoundMuted;if(staffSoundMuted)stopStaffAudio();localStorage.setItem('fyi_staff_sounds_muted',staffSoundMuted?'1':'0');if(!staffSoundMuted)primeStaffAudio();render();notice(staffSoundMuted?'Notification sounds muted':'Notification sounds enabled');};
 const cashierUpload=$('#cashier-sound-upload');if(cashierUpload)cashierUpload.onchange=async()=>{const file=cashierUpload.files?.[0];if(!file)return;try{await uploadSharedSound('cashier',file);cashierUpload.value='';}catch(e){notice(e.message);cashierUpload.value='';}};
 const kitchenUpload=$('#kitchen-sound-upload');if(kitchenUpload)kitchenUpload.onchange=async()=>{const file=kitchenUpload.files?.[0];if(!file)return;try{await uploadSharedSound('kitchen',file);kitchenUpload.value='';}catch(e){notice(e.message);kitchenUpload.value='';}};
 const cashierPreview=$('#preview-cashier-sound');if(cashierPreview)cashierPreview.onclick=()=>previewAlertSound('cashier');const kitchenPreview=$('#preview-kitchen-sound');if(kitchenPreview)kitchenPreview.onclick=()=>previewAlertSound('kitchen');
  document.querySelectorAll('[data-chart-period]').forEach(button=>button.onclick=async()=>{const next=button.dataset.chartPeriod;if(!['today','week','month','year'].includes(next)||next===dashboardPeriod)return;dashboardPeriod=next;dashboardMetrics=null;dashboardFetchedAt=0;try{await loadDashboardMetrics(true);render();}catch(error){notice('Could not load '+next+' graph: '+error.message);}});
 document.querySelectorAll('[data-copy-rider]').forEach(button => {
    button.onclick = async () => {
      const order = data?.orders?.find(x => x.id === button.dataset.copyRider);
      if (!order) return;
      const details = fyiRiderDetails(order);
      try {
        if (!navigator.clipboard?.writeText) throw Error('Clipboard unavailable');
        await navigator.clipboard.writeText(details);
        notice('Rider details copied.');
      } catch {
        window.prompt('Copy rider delivery details:', details);
      }
    };
  });document.querySelectorAll('[data-go]').forEach(x=>x.onclick=()=>{section=x.dataset.go;activeOrder=null;renderNav();render()});document.querySelectorAll('[data-order]').forEach(x=>x.onclick=()=>{activeOrder=x.dataset.order;render()});if($('#back-orders'))$('#back-orders').onclick=()=>{activeOrder=null;render()};document.querySelectorAll('[data-filter]').forEach(x=>x.onclick=()=>{filter=x.dataset.filter;render()});const input=$('#order-search');if(input){input.oninput=e=>{const start=e.target.selectionStart;search=e.target.value;render();const i=$('#order-search');i.focus();i.setSelectionRange(start,start);};}
 document.querySelectorAll('[data-action]').forEach(x=>x.onclick=async()=>{const a=x.dataset.action;let confirmActualPayment=false;if(a==='verify'){confirmActualPayment=confirm('I have checked the REAL receiving GCash account and verified this exact payment amount and reference. Accept this order?');if(!confirmActualPayment)return;}else if(!confirm(`Continue with "${x.textContent.trim()}"?`))return;try{await call('/api/staff/orders/'+encodeURIComponent(activeOrder)+'/action','POST',{action:a,confirmActualPayment});notice('Order updated: '+a);await refresh();}catch(e){alert(e.message);}});
 const productSearch=$('#product-photo-search');
 if(productSearch)productSearch.oninput=filterMenuCards;
 if($('#menu-category-filter'))$('#menu-category-filter').onchange=filterMenuCards;
 if($('#add-new-product'))$('#add-new-product').onclick=()=>openProductEditor();
 if($('#add-new-category'))$('#add-new-category').onclick=openCategoryEditor;
 if($('#manage-addons'))$('#manage-addons').onclick=()=>openAddonEditor();
 if($('#cancel-category-editor'))$('#cancel-category-editor').onclick=()=>confirmEditorClose(closeCategoryEditor);
 if($('#clear-addon-form'))$('#clear-addon-form').onclick=()=>confirmEditorClose(()=>{closeAddonEditor();render();});
 if($('#product-editor-form')&&$('#product-editor-form').elements.category)
   $('#product-editor-form').elements.category.onchange=e=>{
     const item=catalog.products.find(product=>product.id===$('#product-editor-form').elements.namedItem('id').value);
     $('#product-addon-options').innerHTML=productAddonChoices(e.target.value,item);
   };
 if($('#product-photo-file'))$('#product-photo-file').onchange=e=>{
   const file=e.target.files?.[0];if(!file)return;
   if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>2*1024*1024||file.size<100){
     alert('Choose a JPG, PNG or WebP photo under 2 MB.');e.target.value='';return;
   }
   const reader=new FileReader();reader.onload=()=>{$('#product-photo-preview').innerHTML=`<img src="${esc(reader.result)}" alt="Selected product photo">`;};reader.onerror=()=>alert('Unable to preview selected photo.');reader.readAsDataURL(file);
 };
 document.querySelectorAll('[data-product-edit]').forEach(button=>button.onclick=()=>openProductEditor(button.dataset.productEdit));
 if($('#cancel-product-editor'))$('#cancel-product-editor').onclick=()=>confirmEditorClose(closeProductEditor);
 if($('#add-product-size'))$('#add-product-size').onclick=()=>addSizeRow('', '');
 const productForm=$('#product-editor-form');
 if(productForm)productForm.onsubmit=async e=>{
   e.preventDefault();
   const f=productForm;
   const editing=Boolean(f.elements.namedItem('id').value);
   if(editing&&!await requestConfirmation('Save changes?','Save the changes to this product?','Save Changes'))return;
   const sizes=[...document.querySelectorAll('.size-price-row')].map(row=>({
     label:row.querySelector('.size-label').value.trim(),price:Number(row.querySelector('.size-price').value)
   }));
   const payload={id:f.elements.namedItem('id').value||null,name:f.elements.namedItem('name').value,category:f.elements.namedItem('category').value,
     description:f.elements.namedItem('description').value,addOns:f.elements.namedItem('addOns').value,
     variants:f.elements.namedItem('variants').value.split(',').map(s=>s.trim()).filter(Boolean),
     addonIds:[...f.querySelectorAll('input[name="productAddonIds"]:checked')].map(input=>input.value),
     sizes,active:f.elements.namedItem('active').checked};
   const photo=$('#product-photo-file').files?.[0];
   const save=f.querySelector('[type="submit"]');save.disabled=true;
   try{
     const result=await call('/api/staff/product-save','POST',payload);
     if(photo){
       try{await uploadSelectedPhoto(photo,result.product.id);}
       catch(error){
         closeProductEditor();await reloadMenuCatalog();render();
         alert('Product saved, but its photo could not be uploaded: '+error.message);
         return;
       }
     }
     closeProductEditor();await reloadMenuCatalog();render();notice('Product saved. Customer menu will sync shortly.');
   }
   catch(error){alert('Could not save product: '+error.message);}
   finally{save.disabled=false;}
 };
 document.querySelectorAll('[data-product-toggle]').forEach(button=>button.onclick=async()=>{
   const old=catalog.products.find(p=>p.id===button.dataset.productToggle);if(!old)return;
   try{await call('/api/staff/product-save','POST',{...old,active:old.active===false});
     await reloadMenuCatalog();render();notice('Product availability updated.');}
   catch(error){alert('Could not update status: '+error.message);}
 });
 if($('#delete-product'))$('#delete-product').onclick=()=>$('#delete-product-confirm').classList.remove('hidden');
 if($('#cancel-product-delete'))$('#cancel-product-delete').onclick=()=>$('#delete-product-confirm').classList.add('hidden');
 if($('#confirm-product-delete'))$('#confirm-product-delete').onclick=async()=>{
   const id=$('#product-editor-form').elements.namedItem('id').value;
   const item=catalog.products.find(product=>product.id===id);if(!item)return;
   const button=$('#confirm-product-delete');button.disabled=true;
   try{await call('/api/staff/product-delete','POST',{id});await reloadMenuCatalog();closeProductEditor();render();notice('Food deleted. Historical orders remain saved.');}
   catch(error){alert('Could not delete food: '+error.message);}
   finally{button.disabled=false;}
 };
 if($('#category-editor-form'))$('#category-editor-form').onsubmit=async e=>{
   e.preventDefault();const form=e.target;const submit=form.querySelector('[type="submit"]');submit.disabled=true;
   try{
     const image=form.elements.namedItem('image').files?.[0];
     const imageDataUrl=image?await readMenuImage(image):undefined;
     await call('/api/staff/category-save','POST',{label:form.elements.namedItem('label').value,description:form.elements.namedItem('description').value,imageDataUrl});
     closeCategoryEditor();await reloadMenuCatalog();render();notice('Category saved to Supabase.');
   }catch(error){alert('Could not save category: '+error.message);}
   finally{submit.disabled=false;}
 };
 if($('#addon-editor-form'))$('#addon-editor-form').onsubmit=async e=>{
   e.preventDefault();const form=e.target;const submit=form.querySelector('[type="submit"]');submit.disabled=true;
   try{
     if(form.elements.namedItem('id').value&&!await requestConfirmation('Save changes?','Save the changes to this add-on?','Save Changes'))return;
     const payload={id:form.elements.namedItem('id').value||null,name:form.elements.namedItem('name').value,
       price:Number(form.elements.namedItem('price').value),
       categoryIds:[...form.elements.namedItem('categoryIds').selectedOptions].map(option=>option.value),
       productIds:[...form.elements.namedItem('productIds').selectedOptions].map(option=>option.value),
       active:form.elements.namedItem('active').checked};
     await call('/api/staff/addon-save','POST',payload);
     closeAddonEditor();await reloadMenuCatalog();render();notice('Add-on saved to Supabase.');
   }catch(error){alert('Could not save add-on: '+error.message);}
   finally{submit.disabled=false;}
 };
 document.querySelectorAll('[data-addon-edit]').forEach(button=>button.onclick=()=>openAddonEditor(button.dataset.addonEdit));
 document.querySelectorAll('[data-addon-toggle]').forEach(button=>button.onclick=async()=>{
   const item=(catalog.menuAddons||[]).find(addon=>addon.id===button.dataset.addonToggle);if(!item)return;
   try{await call('/api/staff/addon-save','POST',{...item,active:item.active===false});await reloadMenuCatalog();render();notice('Add-on availability updated.');}
   catch(error){alert('Could not update add-on: '+error.message);}
 });
 const saveStoreSettings=async(form,override)=>{const values=Object.fromEntries(new FormData(form));if(override)values.override=override;try{const result=await call('/api/staff/settings','POST',values);form.elements.override.value=result.settings.override;notice(result.isOpen?'Store is open · Customer app syncing':'Store is closed · Orders paused');await refresh();}catch(e){alert(e.message)}};
 if($('#save-settings'))$('#save-settings').onsubmit=async e=>{e.preventDefault();await saveStoreSettings(e.target);};
 document.querySelectorAll('[data-store-override]').forEach(button=>button.onclick=()=>saveStoreSettings($('#save-settings'),button.dataset.storeOverride));
 if($('#create-staff'))$('#create-staff').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await call('/api/staff/create','POST',{...Object.fromEntries(f),role:'kitchen'});notice('Kitchen account created');await refresh();}catch(e){alert(e.message)}};
 if($('#copy-menu'))$('#copy-menu').onclick=()=>{
  let url=location.origin+'/menu';
  // localhost cannot be opened on a different phone. Ask for the real Wi-Fi IP.
  if(['localhost','127.0.0.1'].includes(location.hostname)){
    const ip=window.prompt('Enter your laptop Wi-Fi IPv4 from ipconfig (example: 192.168.1.12). A phone cannot scan localhost:','');
    if(!ip)return;
    const octets=ip.trim().split('.').map(Number);
    if(octets.length!==4||!octets.every(n=>Number.isInteger(n)&&n>=0&&n<=255)){
      notice('Please enter a valid Wi-Fi IPv4 address.');return;
    }
    url='http://'+ip.trim()+':'+(location.port||'3333')+'/menu';
  }
  if(navigator.clipboard?.writeText)navigator.clipboard.writeText(url).then(()=>notice('Customer Expo QR URL copied'),()=>window.prompt('Copy the URL:',url));
  else window.prompt('Copy the URL:',url);
};}
selectLogin(loginRole);
if(storedStaffRole)boot().catch(e=>notice(e.message));
else{$("#login").classList.remove("hidden");$("#app").classList.add("hidden");}
