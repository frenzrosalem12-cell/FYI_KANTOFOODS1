// QR now points to the SAME Expo customer UI as the iPhone app.
const ipInput=document.getElementById('lan-ip');
const ipLabel=document.getElementById('ip-label');
const qr=document.getElementById('qr');
const local=['localhost','127.0.0.1'].includes(location.hostname);
if(local)ipLabel.style.display='block';
const allowedIPv4=s=>{
  const a=s.trim().split('.');
  return a.length===4&&a.every(x=>/^\d{1,3}$/.test(x)&&Number(x)<=255);
};
function renderQR(){
  let url=location.origin+'/menu';
  if(local){
    const ip=ipInput.value.trim();
    if(allowedIPv4(ip))url='http://'+ip+':'+(location.port||'3333')+'/menu';
  }
  document.getElementById('url').textContent=url;
  document.getElementById('warn').textContent=local&&!allowedIPv4(ipInput.value)
    ? 'Enter your laptop Wi-Fi IPv4 (run ipconfig in PowerShell) before printing. A QR using localhost will NOT open on another phone.'
    : 'Scan this QR while your laptop server is running and the phone is on the same Wi-Fi. The link is for local testing, not a public internet website.';
  qr.replaceChildren();
  if(window.QRCode){new QRCode(qr,{text:url,width:235,height:235,colorDark:'#00573e',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.H});}
  else qr.textContent='QR library unavailable: check your internet connection.';
}
ipInput.addEventListener('input',renderQR);
renderQR();
