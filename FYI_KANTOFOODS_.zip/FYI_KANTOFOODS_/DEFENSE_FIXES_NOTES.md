# FYI-KANTOFOODS staff fixes

## Included in this build
- PIN keypad delete control now displays an accessible × symbol.
- PIN login shows a Forgot PIN? recovery guidance link.
- Kitchen username/password login shows a Forgot password? recovery guidance link.
- Recovery guidance directs staff to the authorized Admin 1 account holder; no authentication bypass or unverified self-service reset was added.
- Cashier dashboard displays Total Orders and Order Activity only. It does not display sales totals or revenue charts.
- Admin retains the Sales chart and sales summary.
- Weekly dashboard series includes Monday through Sunday labels, including zero-activity days.
- Staff shell uses a fixed-height viewport layout with an independently scrollable sidebar and main content area.
- Removed the visible "Connected Demo" dashboard label and "Demo store pin" wording.

## Security and deployment notes
- No `.env`, `node_modules`, or `.git` directory is included.
- Keep your real `.env` file locally and never upload it publicly.
- Staff credential recovery is intentionally not an unauthenticated reset. Admin 1 must verify staff identity and update staff credentials using the authorized Staff Accounts workflow. Admin 1 recovery requires the project owner/developer to verify identity and reset it securely.
- The configured store location still needs to be verified against the actual shop entrance before live delivery operations. This build does not invent a real location.

## Verification
- `node --check` passed for the modified staff UI and backend modules.
- `npm test` passed all available offline tests, including syntax, catalog/RLS/API/workflow safeguards and mocked PayMongo checks.
- Live Supabase, real PayMongo, browser layout, Wi-Fi, and physical Android/iOS testing have not been performed in this environment.
