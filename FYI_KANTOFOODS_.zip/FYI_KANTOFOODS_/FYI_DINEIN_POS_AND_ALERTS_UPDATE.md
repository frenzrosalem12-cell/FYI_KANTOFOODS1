# FYI-KANTOFOODS: Dine-In POS + Alert Hardening

## Implemented in this update

- Added a **Cashier-only Dine-In POS** navigation item and page.
- POS supports active menu products, sizes, product variants, applicable add-ons, quantity, table number, order notes, cart quantity controls, and cart removal.
- POS totals are displayed client-side for convenience; the server independently validates products/options and recomputes the total using the live menu catalog.
- Cashier records Cash or GCash as received at the cashier. A confirmation dialog precedes submission.
- Dine-in orders are saved as `order_type='dine-in'`, `payment_status='paid'`, and `status='accepted'`; they appear directly in the Kitchen queue.
- Server route `/api/staff/dine-in-orders` is restricted to the **cashier** role (not owner or kitchen) and rate-limited.
- Customer delivery API continues to reject any order whose type is not `delivery`; the Expo customer app remains delivery-only.
- Cashier and Kitchen notification IDs are remembered in browser local storage to reduce repeat sounds for the same order across refresh/relogin.
- Notification sound setting now initializes/resumes the browser AudioContext from the user gesture when sounds are enabled.
- Staff refresh does not redraw the Dine-In POS every 5 seconds, protecting table/notes inputs from being reset while the cashier is entering an order.

## Verification

- `node --check server.mjs` passed.
- `node --check public/staff.js` passed.
- `npm test` passed, including added offline checks for cashier-only POS access, paid/accepted dine-in creation, alert deduplication, graph refresh safeguards, and delivery-only customer ordering.
- `npm run check` passed (offline integration checks).

## Live testing still required

- Supabase schema/RLS and live menu validation.
- Cashier/kitchen role behavior in real browser sessions.
- Cash/GCash recording and Kitchen ticket display on actual staff devices.
- Notification audio behavior in Chrome/mobile browsers and after tab backgrounding.
- Sales graph values with live paid order data.
- PayMongo production webhooks and Expo phone/network tests.

## Known limitation

Dine-in cash/GCash payment is recorded on the `fyi_orders` row with paid status, payment method, total, and cashier history. The existing `fyi_payment_transactions` table is constrained to PayMongo provider records, so dine-in manual payments do not appear in that PayMongo-specific transaction table unless a separate cash/manual-payment ledger is designed and migrated.
