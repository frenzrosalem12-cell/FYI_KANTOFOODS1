// FYI Smart Menu login/session repair. Run in FYI_KANTOFOODS_1: node fix_fyi_staff_login.cjs
const fs=require('fs'),path=require('path'),cp=require('child_process');
const serverFile=path.resolve('server.mjs'),staffFile=path.resolve('public/staff.js');
function replaceOnce(s,repl,replacement,label){
 const hits=[...s.matchAll(new RegExp(repl.source,repl.flags+'g'))];
 if(hits.length!==1)throw Error(`${label}: expected 1 match, found ${hits.length}. Nothing changed.`);
 return s.replace(repl,()=>replacement);
}
function patchServer(s){
 if(s.includes('FYI_STAFF_SESSION_FIX_V1'))throw Error('The server has already been patched.');
 const helper=`// FYI_STAFF_SESSION_FIX_V1: separate HttpOnly cookies for owner, cashier, kitchen.
const STAFF_ROLES=new Set(['owner','cashier','kitchen']);
function requestedStaffRole(req){
  let role=typeof req.headers['x-fyi-staff-role']==='string'
    ?req.headers['x-fyi-staff-role']:null;
  // Normal HTML image links cannot send custom headers.
  if(!role&&String(req.url||'').startsWith('/api/staff/proof/')){
    try{role=new URL(req.url,'http://localhost').searchParams.get('staff_role');}
    catch{}
  }
  return STAFF_ROLES.has(role)?role:null;
}
function sessionCookie(id,expire=false,role='owner'){
  if(!STAFF_ROLES.has(role))throw Error('Unknown staff role.');
  return 'fyi_session_'+role+'='+id+'; HttpOnly; SameSite=Lax; Path=/; Max-Age='+
    (expire?0:28800)+(process.env.NODE_ENV==='production'?'; Secure':'');
}
async function current(req){
  const role=requestedStaffRole(req);
  const sid=cookie(req,role?'fyi_session_'+role:'fyi_session');
  const s=sessions.get(sid);
  if(!s)return null;
  if(Date.now()>s.expires){sessions.delete(sid);return null;}
  if(role&&s.role!==role)return null;
  const staff=await database.staffById(s.id);
  if(!staff||(role&&staff.role!==role))return null;
  return staff;
}
`;
 s=replaceOnce(s,/function sessionCookie\(id,\s*expire\s*=\s*false\)\s*\{[\s\S]*?\n\}\s*\n\s*async function current\(req\)\s*\{[\s\S]*?\n\}\s*(?=\n\s*async function staffRole)/,helper,'Session helpers');
 const auth=`// Staff login: only failed attempts count toward lockout; role + IP are isolated.
  if(method==='POST'&&p==='/api/login'){
    const b=await body(req),role=safe(b.role,20);
    const username=role==='kitchen'?safe(b.username,120).toLowerCase():'';
    const windowMs=15*60*1000;
    const roleKey='login-role:'+ip+':'+role+':'+username;
    const ipKey='login-ip:'+ip;
    const failures=k=>(loginAttempts.get(k)||[]).filter(t=>t+windowMs>Date.now()).length;
    if(failures(roleKey)>=7||failures(ipKey)>=30)
      return bad(res,'Too many incorrect attempts. Try again after 15 minutes.',429);
    let staff=null,secret='';
    if(role==='owner'||role==='cashier'){
      staff=await database.staffByRole(role);secret=safe(b.pin,16);
    }else if(role==='kitchen'){
      staff=await database.staffByRole('kitchen',username);
      secret=String(b.password||'');
    }
    if(!staff||!secret||!database.passwordMatches(secret,staff)){
      checkRate(loginAttempts,roleKey,7,windowMs);
      checkRate(loginAttempts,ipKey,30,windowMs);
      return bad(res,'Incorrect credentials.',401);
    }
    loginAttempts.delete(roleKey);
    const prior=cookie(req,'fyi_session_'+role);
    if(prior)sessions.delete(prior);
    const sid=nonce()+nonce();
    sessions.set(sid,{id:staff.id,role:staff.role,expires:Date.now()+8*3600000});
    return json(res,{ok:true,role:staff.role,name:staff.name},200,{
      'Set-Cookie':sessionCookie(sid,false,role)
    });
  }
  // Logging out one role must not log out another role.
  if(method==='POST'&&p==='/api/logout'){
    const role=requestedStaffRole(req);
    if(!role)return bad(res,'Select a staff role to sign out.',400);
    sessions.delete(cookie(req,'fyi_session_'+role));
    return json(res,{ok:true},200,{'Set-Cookie':sessionCookie('',true,role)});
  }
  // Calculate delivery distance`;
 s=replaceOnce(s,/\/\/ Staff login\s*\n\s*if\s*\(\s*method\s*===\s*'POST'\s*&&\s*p\s*===\s*'\/api\/login'\s*\)\s*\{[\s\S]*?\n\s*\/\/ Calculate delivery distance/,auth,'Login/logout block');
 return s;
}
function patchStaff(s){
 if(s.includes('FYI_STAFF_SESSION_FIX_V1'))throw Error('Staff client already patched.');
 const remembered=`\n// FYI_STAFF_SESSION_FIX_V1: tab-specific selected role (never stores PIN/password).
const STAFF_TAB_ROLE_KEY='fyi_active_staff_role';
const storedStaffRole=sessionStorage.getItem(STAFF_TAB_ROLE_KEY);
if(Object.hasOwn(roleNames,storedStaffRole))loginRole=storedStaffRole;`;
 s=replaceOnce(s,/(?<=const roleNames=\{[^\n]*\};)/,remembered,'Remember role per tab');
 const call=`async function call(url,method='GET',payload){
  const headers={'X-FYI-Staff-Role':user?.role||loginRole};
  if(payload)headers['Content-Type']='application/json';
  const r=await fetch(url,{method,headers,credentials:'same-origin',
    body:payload?JSON.stringify(payload):undefined});
  let v;try{v=await r.json()}catch{v={error:'Unexpected response'}}
  if(!r.ok)throw Error(v.error||'Request failed');return v;
}`;
 s=replaceOnce(s,/async function call\(url,method='GET',payload\)\{[^\n]+\}/,call,'Staff fetch');
 s=replaceOnce(s,/function selectLogin\(role\)\{loginRole=role;pin='';/,
   "function selectLogin(role){loginRole=role;sessionStorage.setItem(STAFF_TAB_ROLE_KEY,role);pin='';",'Login picker');
 s=replaceOnce(s,/async function boot\(\)\{const me=await call\('\/api\/me'\);user=me.user;/,
   "async function boot(){const me=await call('/api/me');user=me.user;if(user){loginRole=user.role;sessionStorage.setItem(STAFF_TAB_ROLE_KEY,loginRole);}",'Boot current staff');
 s=replaceOnce(s,/href="\/api\/staff\/proof\/\$\{encodeURIComponent\(o.id\)\}"/,
   'href="/api/staff/proof/${encodeURIComponent(o.id)}?staff_role=${encodeURIComponent(user.role)}"', 'Payment proof link');
 s=replaceOnce(s,/boot\(\)\.catch\(e=>notice\(e.message\)\);\s*$/,
   'selectLogin(loginRole);\nif(storedStaffRole)boot().catch(e=>notice(e.message));\nelse{$("#login").classList.remove("hidden");$("#app").classList.add("hidden");}\n','Initialize staff role');
 return s;
}
try{
 for(const name of [serverFile,staffFile])if(!fs.existsSync(name))throw Error('Missing '+name+'. Run from FYI_KANTOFOODS_1 folder.');
 const server=patchServer(fs.readFileSync(serverFile,'utf8'));
 const staff=patchStaff(fs.readFileSync(staffFile,'utf8'));
 const suffix='.backup-'+new Date().toISOString().replace(/[:.]/g,'-');
 const copies=[[serverFile,serverFile+suffix],[staffFile,staffFile+suffix]];
 copies.forEach(([src,bak])=>fs.copyFileSync(src,bak,fs.constants.COPYFILE_EXCL));
 try{
   fs.writeFileSync(serverFile,server,'utf8');fs.writeFileSync(staffFile,staff,'utf8');
   cp.execFileSync(process.execPath,['--check',serverFile]);
   cp.execFileSync(process.execPath,['--check',staffFile]);
 }catch(e){
   copies.forEach(([src,bak])=>fs.copyFileSync(bak,src));
   throw Error('Syntax check failed, originals restored. '+e.message);
 }
 console.log('SUCCESS! Independent role sessions enabled. Syntax checks passed.');
 console.log('Original files backed up:');copies.forEach(([,bak])=>console.log('  '+bak));
 console.log('Restart npm start; refresh staff browser tabs; log in separately to each role.');
}catch(e){console.error('FIX NOT APPLIED: '+e.message);process.exitCode=1;}
