# FYI-KANTOFOODS Graph + Admin Ringtone Improvements

## Sales graph
- Added Today / Week / Month / Year graph period controls to the Admin sales chart.
- Admin dashboard analytics are force-refreshed during the existing 5-second polling cycle instead of being held by the 20-second client cache.
- The paid-payment transition still triggers an immediate analytics refresh.
- Database analytics now falls back to source order rows when the analytics views error or return an empty series.
- Sales graph is based on paid orders from the database analytics, so pending/unpaid orders are excluded.

## Shared ringtone configuration
- Cashier and Kitchen sound upload/preview controls moved to Admin > Settings.
- Admin uploads MP3, WAV, OGG, M4A/AAC audio (max 3.5 MB) to server storage.
- Staff devices fetch the shared sound from the server; uploads are not tied to the Admin browser's local storage.
- Cashier and Kitchen dashboards have their own Mute/Unmute control. The mute preference is local to each staff role/device.
- When no shared sound is uploaded, a distinct built-in alert tone is used.

## Alert lifecycle
- Cashier: loop alert for incoming delivery order while it remains pending payment/acceptance. It stops when the order is accepted. A separate Cashier alert loops when Kitchen marks an order ready; opening that ready ticket acknowledges it.
- Kitchen: loop alert for accepted tickets until Kitchen opens the ticket. Opening the ticket acknowledges the alert.
- Toast notification IDs are deduplicated across polling and reloads. Alert acknowledgment is saved per staff role/device.
- Customer app remains delivery-only.

## Verification
- `node --check public/staff.js`
- `node --check server.mjs`
- `node --check db.mjs`
- `npm test`
- `npm run check`

All are offline checks. Live Supabase, payment-provider events, browser autoplay behavior, and multi-device ringing need manual testing with credentials and actual devices.
