import readline from 'node:readline/promises';
import {stdin as input,stdout as output} from 'node:process';
import * as db from './db.mjs';

const rl=readline.createInterface({input,output});
const ask=async(label,kind)=>{while(true){const value=(await rl.question(label)).trim();if(kind==='pin'&&!/^\d{4,8}$/.test(value)){console.log('PIN must contain 4 to 8 digits. Avoid obvious combinations.');continue;}if(kind==='password'&&value.length<12){console.log('Use a kitchen password with at least 12 characters.');continue;}if(!value){console.log('This field is required.');continue;}return value;}};
try{
 console.log('\nFYI-KANTO · PostgreSQL account setup\n');
 await db.preflight();
 const existing=await db.listStaff();
 if(existing.length){console.log('Staff accounts already exist in Supabase. Setup will not overwrite them.');process.exitCode=0;}
 else{
  const owner=await ask('Owner (Admin 1) PIN (4-8 digits): ','pin');
  const cashier=await ask('Cashier (Admin 2) PIN (different PIN): ','pin');
  if(owner===cashier)throw Error('Owner and cashier PINs must be different.');
  const kitchenUsername=(await ask('Kitchen username (4+ characters): ')).toLowerCase();
  if(!/^[a-z0-9._@-]{4,80}$/.test(kitchenUsername))throw Error('Username: 4+ letters/numbers or . _ @ -');
  const kitchenPass=await ask('Kitchen password (12+ characters): ','password');
  const wrap=(password)=>{const salt=db.nonce();return {salt,password_hash:db.hashPassword(password,salt)}};
  await db.insertStaffBatch([
    {id:db.newId(),role:'owner',name:'Admin Owner',username:'owner',active:true,...wrap(owner)},
    {id:db.newId(),role:'cashier',name:'Cashier',username:'cashier',active:true,...wrap(cashier)},
    {id:db.newId(),role:'kitchen',name:'Kitchen Staff',username:kitchenUsername,active:true,...wrap(kitchenPass)}
  ]);
  console.log('\nStaff accounts stored in Supabase as salted scrypt hashes.');
  console.log('Your PINs and passwords are not shown in the staff website. Start the server using: npm start');
 }
}catch(e){console.error('Setup failed:',e.message);process.exitCode=1;}
finally{rl.close();}
