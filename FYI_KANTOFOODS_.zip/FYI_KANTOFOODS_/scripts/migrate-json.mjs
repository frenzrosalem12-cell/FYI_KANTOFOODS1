// Optional migration of previous FYI classroom demo JSON data into Supabase.
// Run: npm run migrate:json -- "C:\\...\\FYI_KANTO_Connected_Demo\\private\\database.json"
// Run ONLY for your own old data in a test environment. Never share the private JSON file online.
import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {supabase,unwrap,sha256,newId,uploadProof,preflight,listStaff} from '../db.mjs';

const oldPath=process.argv[2];
if(!oldPath||!fs.existsSync(oldPath)){
 console.error('Provide an existing local old database.json path. Nothing has been changed.');process.exit(1);
}
const old=JSON.parse(fs.readFileSync(oldPath,'utf8'));
if(!Array.isArray(old.staff)||!Array.isArray(old.orders)||!Array.isArray(old.reviews)||!old.settings){throw Error('Unrecognized legacy FYI database.json.');}
await preflight();
const existing=await listStaff();
if(existing.length){console.error('ABORT: Remote Supabase already has staff. Migration only runs into an empty FYI schema to avoid conflicts.');process.exit(1);}
const check=unwrap(await supabase.from('fyi_orders').select('id').limit(1));
if(check.length){console.error('ABORT: Remote Supabase already contains orders. Migration requires an empty FYI schema.');process.exit(1);}
console.log('Migrating staff, order history, reviews, and settings to your configured Supabase project.');
for(const s of old.staff){
 if(!s.secret?.salt||!s.secret?.hash)throw Error('Legacy staff secret hash missing.');
 unwrap(await supabase.from('fyi_staff').insert({id:s.id,role:s.role,name:s.name,username:s.username,active:s.active!==false,salt:s.secret.salt,password_hash:s.secret.hash}));
}
unwrap(await supabase.from('fyi_store_settings').update({open_time:old.settings.open||'08:00',close_time:old.settings.close||'20:00',override:old.settings.override||'auto',location:old.settings.location,updated_at:new Date().toISOString()}).eq('id',1));
let completed=0;
for(const o of old.orders){
 if(!o.trackingToken)throw Error('A legacy order is missing its tracking token.');
 let pathRemote=null;
 if(o.proofFile){const proofPath=path.join(path.dirname(oldPath),'proofs',o.proofFile);if(fs.existsSync(proofPath)){
   const bytes=fs.readFileSync(proofPath),ext=path.extname(proofPath).slice(1).toLowerCase();
   const mime=ext==='jpg'?'image/jpeg':`image/${ext}`;
   pathRemote=await uploadProof(bytes,ext,mime,o.id);
 }else console.warn('Missing payment proof:',o.id);}
 const row={id:o.id,tracking_hash:sha256(o.trackingToken),order_type:o.type,status:o.status,payment_status:o.paymentStatus,payment_method:o.paymentMethod,customer:o.customer,items:o.items,subtotal:o.subtotal,delivery_fee:o.deliveryFee||0,road_km:o.roadKm??null,total:o.total,gcash_reference:o.gcashReference||'',proof_path:pathRemote,proof_mime:o.proofMime||null,history:o.history||[],reviewed:!!o.reviewed,created_at:o.createdAt,updated_at:o.updatedAt};
 unwrap(await supabase.from('fyi_orders').insert(row));completed++;
}
for(const r of old.reviews){
 const id=/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(r.id)?r.id:newId();
 unwrap(await supabase.from('fyi_reviews').insert({id,order_id:r.orderId,name:r.name,rating:r.rating,message:r.message,approved:r.approved!==false,created_at:r.at||new Date().toISOString()}));
}
console.log(`Migration finished. ${old.staff.length} staff, ${completed} orders, ${old.reviews.length} reviews. Legacy JSON file was NOT modified.`);
