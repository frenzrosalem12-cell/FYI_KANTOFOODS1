# FYI-KANTOFOODS Improvement Status

Based on FYI_KANTOFOODS_FINAL.zip; this is the consolidated main project.

## Applied in this working update
- Staff browser notification tones: two short, distinct tone patterns for Cashier and Kitchen alerts.
- Cashier and Kitchen dashboard buttons to enable/mute notification tones. Preference saved per browser.
- Cashier new-order detection triggers alert sound and toast while the staff dashboard is open.
- Kitchen ticket alert detects newly added or newly accepted/preparing/ready tickets and plays its distinct tone.
- Admin sales analytics are force-refreshed after payment transitions to paid, rather than waiting for the dashboard analytics cache to expire.
- Extracted bundled Customer_Expo.zip into Customer_Expo folder so the project and offline test suite can be run in-place.

## Not yet implemented / live-tested
- Cashier-only Dine-In POS entry form and server-side creation workflow are still pending. Existing order cards support displaying dine-in-type orders, but this update does not add the POS.
- Chart behavior with live Supabase payment data needs verification in the deployed environment.
- Sound behavior needs browser/device testing, including audio permission/user interaction behavior.
- PayMongo real payments, Supabase live database/RLS, email, network and Expo phone tests were not run (secrets not included).

## Offline checks
- `node --check public/staff.js`, `server.mjs`, `db.mjs` pass.
- `npm test` passes after unpacking the nested Expo project archive.
