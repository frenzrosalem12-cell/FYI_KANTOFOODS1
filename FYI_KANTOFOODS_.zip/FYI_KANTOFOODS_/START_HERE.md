# FYI-KANTO Customer App and Staff Backend Setup

The Expo customer app and the Owner/Cashier/Kitchen website use the same Node API and Supabase database. Customers must create an account or sign in before ordering. Customer orders are delivery-only and appear in the staff website.

## 1. Configure Supabase

1. Create a Supabase project and open its SQL Editor.
2. For a new project, run the complete `supabase/schema.sql` file. For an existing project, run the required additive migrations listed below.
3. Keep the Supabase project URL and public anon/publishable key for the Expo app. Use a separate Supabase secret/service-role key only in the backend `.env`.

Customer accounts require a unique username, real email, password, phone number, and delivery address. Configure email delivery for password recovery. In Authentication → URL Configuration, allow your deployed website's `/reset-password` URL and the native app redirects `fyikanto://` and `fyikanto://reset-password`. The app sends a recovery code to the registered email; new passwords must be at least 8 characters. New accounts and profile details are stored in Supabase Auth and `profiles`.

## 2. Configure and run the backend

Copy `.env.example` to `.env`. Set `SUPABASE_URL` and `SUPABASE_SECRET_KEY` using your own project credentials. Keep that secret key out of Expo, browser code, and source control.

For PayMongo GCash Payment Intents, also set:

- `PAYMONGO_SECRET_KEY` — a test-mode `sk_test_...` key (the public key is not used by this server-side integration).
- `PAYMONGO_WEBHOOK_SECRET` — the signing secret from the PayMongo webhook configuration.
- `PAYMONGO_SUCCESS_URL` — `https://YOUR_PUBLIC_DOMAIN/payment/success`.

In the PayMongo dashboard, register `https://YOUR_PUBLIC_DOMAIN/webhooks/paymongo` and subscribe to `payment.paid`. Payment is confirmed by the signed webhook and server-to-server Payment Intent status checks, not by a client redirect or screenshot. PayMongo cannot reach a laptop-only `localhost` webhook or HTTPS return page; use a public HTTPS staging backend to test end-to-end. The backend must be restarted after editing `.env`.

Run these commands from the repository root:

```powershell
npm install
npm run setup
npm start
```

The staff site is at `http://localhost:3333/staff`. The Expo customer web build is served at `/menu` and `/reset-password` after running `npm run build:customer-web`. Staff and app orders share `fyi_orders`; PayMongo-paid orders move into the cashier acceptance queue. Admin 1 can see verified customer emails, usernames, order counts, and totals for paid orders in Customers. Admin 1 and Admin 2 can see the PayMongo transaction list. On an existing database, run `supabase/customer-payment-admin.sql` and `supabase/customer-app-enhancements.sql` in the Supabase SQL Editor. The latter enables customer profile photos, saved favorites, popularity counts, and paid-order reviews.

For staff sales/order dashboards and editable menu categories/add-ons on an existing database, also run `supabase/staff-website-enhancements.sql` in the Supabase SQL Editor. It adds the staff analytics views and menu configuration fields, and safely changes one legacy `Admin 2` role to `cashier` only when no cashier account already exists; if the migration reports a role conflict, review staff rows manually and do not delete or merge accounts. Do not edit or recreate staff credentials as part of this migration.

## 3. Connect the Expo customer app

Copy `Customer_Expo/.env.example` to `Customer_Expo/.env` and set:

```dotenv
EXPO_PUBLIC_API_URL=http://YOUR_LAPTOP_WIFI_IP:3333
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Only the Supabase public anon/publishable key belongs in Expo. Never add `SUPABASE_SECRET_KEY`, `PAYMONGO_SECRET_KEY`, or `PAYMONGO_WEBHOOK_SECRET` to `EXPO_PUBLIC_` variables.

Keep the backend running, then start Expo:

```powershell
cd Customer_Expo
npx expo start -c
```

On a physical phone, use the laptop's Wi-Fi IPv4 address in `EXPO_PUBLIC_API_URL`; both devices must be on the same network. Reload Expo after changing `.env`.

Customers create an account with their real email and can then sign in. The first screen links to email-code password recovery; reset links open the app's recovery screen or the hosted website's `/reset-password` screen. After sign-in the app loads the delivery menu. The profile screen lets customers edit their email, username, phone, address, and profile photo, and includes the account creation date and a confirmed logout action.

The owner can open **Settings** in the staff website to set opening/closing times or use **Open Now**, **Close Now**, and **Follow Schedule**. These changes save to Supabase through the shared backend, which immediately pushes the new status to connected staff browsers and customer apps over WebSocket. The app also refreshes when it returns to the foreground, reconnects automatically if the network drops, and the backend rejects new orders whenever the store is closed.

## 4. Delivery and payment flow

1. Add menu items, enter the delivery contact/address, then pin the drop-off location.
2. The app requests the route and delivery fee from the backend. The backend recalculates both before creating the order.
3. The backend creates a PayMongo Payment Intent, creates and attaches a GCash payment method, and opens the returned secure GCash authorization page.
4. PayMongo's signed `payment.paid` webhook marks successful payment. The order is then available for cashier acceptance and kitchen processing.

Delivery pricing is currently under 1 km free, 1–1.99 km ₱15, with ₱10 per additional full-kilometer bracket. The routing provider is the public OSRM demo service; replace it with a supported production routing service before commercial use.

The starting store coordinates in the current demo project are **not verified business coordinates**. Update `fyi_store_settings.location` in Supabase to the exact restaurant entrance before quoting or accepting real deliveries.

## 5. Production limitations

Source code is not connected to your Supabase or PayMongo accounts until you set the environment values and apply the SQL. This implementation has not been tested against your live accounts. Local HTTP, demo routing, and prototype staff authentication are not production-ready. Use HTTPS hosting, verified store coordinates and delivery pricing, PayMongo test-mode checks, backups, monitoring, and a reviewed operational/payment process before using real customer data or accepting real money.
