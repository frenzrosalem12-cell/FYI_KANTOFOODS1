# FYI-KANTO Customer App (Expo)

The customer app offers free accounts with a required email, username, phone number, and delivery address. Customers must verify their email before placing orders. Forgot-password requests start with the customer username and send a reset link only to that account's verified email.

## Configuration

Copy `.env.example` to `.env` and set your values:

```dotenv
EXPO_PUBLIC_API_URL=http://YOUR_LAPTOP_WIFI_IP:3333
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
```

Only the public Supabase anon/publishable key belongs in this app. Keep the Supabase secret/service-role key and all PayMongo keys in the repository-root backend `.env`.

Run the SQL in `../supabase/schema.sql` before creating accounts. On an existing database with a missing `profiles.email` column, run the entire `../supabase/customer-profile-fix.sql` in the Supabase SQL Editor. For payment transaction reporting, also run `../supabase/customer-payment-admin.sql`. For open customer reviews using the existing reviews table, run `../supabase/customer-reviews.sql` on existing databases.

Customer signup is handled by the Node backend using the Supabase Admin API. In development/test, the backend confirms new test accounts automatically, writes username, phone, and address to `public.profiles`, and the app then signs the customer in. The email remains the Supabase Auth account email. In production, set `CUSTOMER_SIGNUP_AUTO_CONFIRM=true` explicitly only if you intend to disable email verification. Keep `SUPABASE_SECRET_KEY` only in the backend `.env`; never put it in Expo. The backend must be running and connected to Supabase for signup. Normal password reset still uses Supabase email delivery and the configured redirects; allow the production website origin and its `/reset-password` path, plus `fyikanto://` and `fyikanto://reset-password` for native app links.

Passwords have no app-imposed length limit; Supabase enforces its configured password policy. Customer account details are written to `public.profiles` and shown on the owner admin site's Customer Accounts page. The customer/payment migration (`../supabase/customer-payment-admin.sql`) supplies the customer and payment reporting views. Phone numbers must be 11 digits starting with `09`. Accounts stay authenticated for secure ordering, but test signup does not require email confirmation.

## Run

Start the backend from the repository root (`npm start`), then start Expo:

```powershell
npx expo start -c
```

For a physical phone, use the computer's Wi-Fi IPv4 address for `EXPO_PUBLIC_API_URL`; the phone and computer must be on the same network. Reload Expo after editing `.env`.

## Delivery and payment

The customer app calculates delivery routes through the shared Node backend. The backend verifies order pricing and creates and attaches a GCash Payment Intent using its server-only test secret key. The public key is not used by this server-side integration and must not be added to the app. Payment is confirmed server-to-server through a signed PayMongo webhook at `/webhooks/paymongo`; the `/payment/success` page and order tracker also check the PayMongo intent directly and confirm only a matching succeeded payment. The order tracker shows backend road distance, an approximate 20-minute kitchen estimate from preparation start, and a rough travel estimate of four minutes per kilometer after dispatch. Travel time is not live GPS.

On an existing Supabase database, run `../supabase/customer-payment-admin.sql` in the SQL Editor. It creates `fyi_payment_transactions` and the protected `customerfyi_list` and `paymentfyi_list` views. Admin 1 sees verified customer emails, usernames, and paid purchase totals; Admin 1 and Admin 2 see payment transaction records.

On an existing Supabase database, run `../supabase/customer-reviews.sql` in the SQL Editor before using open reviews. It updates the existing `fyi_reviews` table to allow reviews without an order. Customers can post feedback without placing an order; reviews are saved through the backend and displayed in both the admin website and customer app. Checkout contact details are loaded from the signed-in customer profile; only delivery landmark and notes are editable at checkout.

Configure `PAYMONGO_SECRET_KEY=sk_test_...` and `PAYMONGO_SUCCESS_URL=https://YOUR_PUBLIC_DOMAIN/payment/success` in the repository-root `.env`. Register `https://YOUR_PUBLIC_DOMAIN/webhooks/paymongo` as a PayMongo webhook and store its signing secret in `PAYMONGO_WEBHOOK_SECRET`. Without a real public HTTPS deployment and return URL, PayMongo cannot complete the redirect flow or send webhook notifications; a laptop-only local server is not reachable by PayMongo. No credentials are included in this project.
